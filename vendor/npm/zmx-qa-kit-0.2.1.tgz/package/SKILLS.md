# @zmx/qa-kit — aibundle discoverable components

> Discovery manifest consumed by `@zmx/aibundle`. The `@zmx/qa-kit` package ships a complete AI-native QA workflow toolkit (skills / slash commands / rules / MCP server) that `aibundle` distributes to the native locations of each supported IDE (Claude Code / Cursor / GitHub Copilot / OpenAI Codex / Gemini).
>
> For architecture details and maintainer-level information see [`README.md`](./README.md); for hands-on usage see [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md); for the full component architecture see [`docs/OVERVIEW.md`](./docs/OVERVIEW.md) and [`docs/ai-workflow/components-architecture.md`](./docs/ai-workflow/components-architecture.md).

## Contract layer (stable, breaking-change controlled)

Two code-level contracts anchor the entire toolkit. Everything else is prompt-layer markdown and iterates freely.

### 1. `case.md` contract — design pipeline

- **Stable test-case ID**: regex `/TC-\d{3,4}/`
- **HTML trailing-comment tag syntax**: `<!-- id:TC-xxx | 分类:yyy | 维度:k=v,k=v | TBD:... -->`
  - Chinese tokens `分类` / `维度` / `TBD` are **literal contract tokens** the parser matches on. Do not translate them in emitted markdown.
- **YAML frontmatter**: requires `schemaVersion: '2.0'` and `feature: <name>`

Enforced by `src/core/case-md-parser.ts` + `src/core/case-md-validator.ts`. Consumed by three MCP tools (`qa.reviewCoverage` / `qa.draftE2ESpec` / `qa.draftK6Scenario`) via the `caseMdPath` branch; legacy natural-language branches are preserved for backward compatibility. Full spec: [`rules/qa-case-md.md`](./rules/qa-case-md.md).

### 2. `perf-spec.yaml` contract — perf pipeline

- `meta.id` — baseline identity key
- `scenarios[].executor` — enum `constant-vus` / `ramping-vus` / `per-vu-iterations` / ...
- `thresholds.<metric>[]` — k6 threshold string list with sub-metric syntax
- `hooks.pre_flight` / `hooks.post_run` — typed hook entries (`shell` / `http` / `wait` / `sql`) with optional `as_metric` capture
- `observability.prometheus.queries[]` — optional server-side metric snapshots
- `custom_metrics[]` — declared metrics must be referenced by some `thresholds.<metric>[]` entry (v0.2.0 dead-metric gate — `--strict` escalates warn → error)
- `runtime.protocol: grpc` + `runtime.endpoint` — auto-triggers `qa-kit validate --proto-reflection` schema drift check (v0.2.0)
- Fixtures schema (sibling `<dir>/_schema/<basename>.schema.json`) supports the `_qaKit.uniqueBy` extension for strict cross-row uniqueness; `_qaKit.pairBinding` is parsed and surfaced as `info` (full enforcement in v0.2.1)

Enforced by `src/core/perf/spec-schema.ts` + `src/core/perf/spec-schema-v2.ts` (dead-metric) + `src/core/perf/fixtures-schema.ts` (fixtures gate); gated by `qa-kit validate` (the `scenario-schema` / `dead-metric` / `fixtures-schema` / `proto-drift` gates, all enabled automatically when `k6-perf` preset is on). Full spec: [`rules/qa-perf-spec.md`](./rules/qa-perf-spec.md).

---

## Three workflows at a glance

### 1. Design — PRD to XMind

```
PRD ──/qa:design──→ case.md ──/qa:review-coverage──→ case.md (final)
                                                         │
                                                  /qa:author-xmind
                                                         │
                                                    xmind.md
                                                         │
                                      qa-kit report xmind  →  .xmind (native ZIP)
```

### 2. E2E — from spec to regression automation

```
case.md + xmind.md + design assets ──/qa:draft-e2e──→ draft.spec.ts
                                                             │
                                         [Playwright MCP: live DOM probing]
                                                             │
                                                   /qa:heal  + manual refinement
                                                             │
                                                  regression .spec.ts
```

### 3. Perf — from spec to verdict

```
perf-spec.yaml (declarative contract) / case.md (TC-3xx) / natural language
           │
           ├── qa-kit proto fetch ──→ qa-perf/proto/*.proto   (gRPC reflection, v0.2.0)
           │
           ├──/qa:draft-perf──→ .k6.ts (options + scenarios + thresholds + handleSummary)
           │
           ├── qa-kit test run ──→ qa-results/perf/summary.json
           │
           ├── qa-kit perf baseline save | accumulate --runs N
           │                              ──→ samples[] (≥5 → bootstrap 95% CI)
           │
           ├── qa.runHooks (pre_flight / post_run + as_metric capture)
           │
           ├── qa-kit perf prom-fetch ──→ prom-snapshot.json (server-side)
           │
           ├──/qa:analyze-perf [--output json] ──→ 7-class perf verdict + bootstrap CI
           │
           └── qa-kit report {decode-dashboard | perf-run | long-tail}
                                          ──→ md/json reports (v0.2.0)

Mutating ops (HMAC dual-sign, v0.2.0):
  qa-kit perf baseline reset --request --reason "..." → token
  qa-kit perf baseline reset --confirm-token <token>
  qa-kit eval promote --preset <p> --request --reason "..." → token
  qa-kit eval promote --preset <p> --confirm-token <token>
```

---

## Component inventory

- **Skills (10)** — folder mode, each skill has its own directory with `SKILL.md` + `references/`
- **Slash commands (13)** — `commands/qa/*.md`, cross-IDE slash entry source
- **Rules (7)** — `rules/qa-*.md`, always-on or glob/description-gated
- **MCP tools (18)** — 17 implemented + 1 stub, exposed via stdio `npx @zmx/qa-kit mcp`

### Discovery declaration (dual-mode)

`aibundle` supports both **flat mode** (the manifest block below) and **folder mode** (`skills/<name>/SKILL.md`). qa-kit provides both so every version of the discovery scanner can resolve components.

```yaml
skills:
  - qa-design-test-cases      # PRD → case.md (4-quadrant rubric, TC-NNN, 分类/维度 tags)
  - qa-review-coverage        # case.md → coverage matrix + gap suggestions
  - qa-author-xmind-md        # case.md → xmind.md (tree mindmap)
  - qa-draft-e2e-spec         # case.md / NL → Playwright spec.ts (annotation v1.0)
  - qa-codegen                # Playwright GUI recording → raw TS (cleanup via qa-draft-e2e-spec)
  - qa-heal-spec              # failure class → heal prompt → diff (selector-drift / assertion-mismatch probe live DOM)
  - qa-explain-failure        # trace + error → classification report (no code changes)
  - qa-draft-k6-scenario      # perf-spec / case.md / NL → k6 scenario; v0.2.0 references include async-convergence-pattern + error-class-bucketing
  - qa-analyze-perf           # k6 summary + baseline → bootstrap CI + verdict; v0.2.0 fixes k6 v1.7 handleSummary threshold parsing (P0)
  - qa-lease-account          # account pool lease/release (multi-role; v0.2.0 hardened with structured input-guard errors)

commands:
  - qa/design                 # /qa:design
  - qa/review-coverage        # /qa:review-coverage
  - qa/author-xmind           # /qa:author-xmind
  - qa/draft-e2e              # /qa:draft-e2e
  - qa/codegen                # /qa:codegen
  - qa/heal                   # /qa:heal
  - qa/explain                # /qa:explain
  - qa/draft-perf             # /qa:draft-perf
  - qa/analyze-perf           # /qa:analyze-perf
  - qa/test                   # /qa:test   (infers preset by .spec.ts / .k6.ts)
  - qa/report                 # /qa:report (--kind xmind emits native .xmind ZIP)
  - qa/doctor                 # /qa:doctor
  - qa/validate               # /qa:validate (v0.2.0: dead-metric + fixtures-schema + proto-drift gates)

rules:
  - qa-conventions            # always-on: output-language policy + slash/MCP quick reference
  - qa-case-md                # glob qa-design/cases/**/*.md: anti-fabrication + TBD lifecycle + HTML-tag contract
  - qa-perf-spec              # glob qa-perf/perf-spec.yaml: declarative perf contract; v0.2.0 adds traffic-model decision tree
  - qa-runner-web             # glob qa-e2e/tests/**/*.spec.ts: spec.ts conventions + Playwright rules
  - qa-runner-k6              # glob qa-perf/scenarios/**/*.k6.ts: k6 scenario conventions; v0.2.0 adds gRPC field naming (snake_case → lowerCamelCase) + int64 string-passing rule
  - qa-failure-class          # glob qa-e2e/tests/**/*.spec.ts + trace: failure-class rubric
  - qa-preset-types           # description-gated: preset cheatsheet (on-demand, not always-on)

mcp:
  - qa-kit                    # stdio: npx @zmx/qa-kit mcp (18 tools; v0.2.0 hardens applyHealDiff / poolRelease / releaseAccount with structured MISSING_INPUT errors)
  - playwright                # @playwright/mcp, web-e2e preset only: live DOM probing while drafting specs
```

> **CLI surface 不进本 yaml**：`aibundle` 只分发 AI 组件（skills / commands / rules / MCP）；CLI 子命令（如 v0.2.0 新增的 `qa-kit proto fetch` / `qa-kit report decode-dashboard|perf-run|long-tail` / `qa-kit perf analyze --output` / `qa-kit perf baseline accumulate|reset` / `qa-kit eval promote` 双签）通过 `npx @zmx/qa-kit <cmd>` 直接调用。完整 CLI 参考见 [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md)。

---

## Skills

### Design pipeline (preset: `test-case-design`)

| Skill | Purpose | Entry |
|---|---|---|
| `qa-design-test-cases` | Convert PRD to `case.md`: four-quadrant (client/server × happy/edge) rubric, TC-NNN IDs as HTML trailing comments, `分类` / `维度` tags | [skills/qa-design-test-cases/SKILL.md](./skills/qa-design-test-cases/SKILL.md) |
| `qa-review-coverage` | Parse `case.md` dimension tags, compute cartesian coverage matrix, report gaps, propose backfill test cases | [skills/qa-review-coverage/SKILL.md](./skills/qa-review-coverage/SKILL.md) |
| `qa-author-xmind-md` | Convert final `case.md` into a tree-shaped `xmind.md` ready for XMind ZIP packaging (pure LLM read/write; no MCP tool) | [skills/qa-author-xmind-md/SKILL.md](./skills/qa-author-xmind-md/SKILL.md) |

### E2E pipeline (preset: `web-e2e`)

| Skill | Purpose | Entry |
|---|---|---|
| `qa-draft-e2e-spec` | Draft Playwright `spec.ts` from `case.md` + `xmind.md` + design assets, or from natural language; optionally probes the real DOM through the Playwright MCP | [skills/qa-draft-e2e-spec/SKILL.md](./skills/qa-draft-e2e-spec/SKILL.md) |
| `qa-codegen` | Orchestrate `playwright codegen` GUI recording, then hand the raw TS over to `qa-draft-e2e-spec` for contract-compliant cleanup | [skills/qa-codegen/SKILL.md](./skills/qa-codegen/SKILL.md) |
| `qa-heal-spec` | Render a failure-class-specific heal prompt; for `selector-drift` / `assertion-mismatch` it probes the live DOM via the Playwright MCP before proposing a diff | [skills/qa-heal-spec/SKILL.md](./skills/qa-heal-spec/SKILL.md) |
| `qa-explain-failure` | Read trace + error message, output `failureClass` + confidence + evidence + recommended next action (escalate-human vs. heal) | [skills/qa-explain-failure/SKILL.md](./skills/qa-explain-failure/SKILL.md) |

### Perf pipeline (preset: `k6-perf`)

| Skill | Purpose | Entry |
|---|---|---|
| `qa-draft-k6-scenario` | Three-branch drafter: (1) **spec-driven** — compile `perf-spec.yaml` into a multi-exec k6 script with options/scenarios/thresholds; (2) **case.md** — pull TC-3xx interface contracts into scenarios; (3) **simple** — scenario + vu + duration → single-scenario skeleton | [skills/qa-draft-k6-scenario/SKILL.md](./skills/qa-draft-k6-scenario/SKILL.md) |
| `qa-analyze-perf` | Read `summary.json` + optional `perf-spec` + optional baseline history; emit per-scenario p95, threshold breaches, error rate, bootstrap 95% CI (≥5 samples) or fixed tolerance (<5), and a 7-class perf verdict with natural-language summary | [skills/qa-analyze-perf/SKILL.md](./skills/qa-analyze-perf/SKILL.md) |

### Core-reserved (cross-preset)

| Skill | Purpose | Entry |
|---|---|---|
| `qa-lease-account` | Atomic account-pool lease with `proper-lockfile`, tag + role matching, release on teardown; prevents parallel workers from colliding on the same test account | [skills/qa-lease-account/SKILL.md](./skills/qa-lease-account/SKILL.md) |

---

## Slash commands

### Design workflow
- [`commands/qa/design.md`](./commands/qa/design.md) — `/qa:design` PRD → case.md
- [`commands/qa/review-coverage.md`](./commands/qa/review-coverage.md) — `/qa:review-coverage` coverage audit + gap backfill
- [`commands/qa/author-xmind.md`](./commands/qa/author-xmind.md) — `/qa:author-xmind` case.md → xmind.md

### E2E workflow
- [`commands/qa/draft-e2e.md`](./commands/qa/draft-e2e.md) — `/qa:draft-e2e` draft spec.ts
- [`commands/qa/codegen.md`](./commands/qa/codegen.md) — `/qa:codegen` Playwright GUI recording
- [`commands/qa/heal.md`](./commands/qa/heal.md) — `/qa:heal` failure healing loop
- [`commands/qa/explain.md`](./commands/qa/explain.md) — `/qa:explain` failure diagnosis

### Perf workflow
- [`commands/qa/draft-perf.md`](./commands/qa/draft-perf.md) — `/qa:draft-perf` k6 scenario drafter
- [`commands/qa/analyze-perf.md`](./commands/qa/analyze-perf.md) — `/qa:analyze-perf` k6 report analysis

### Cross-workflow utilities
- [`commands/qa/test.md`](./commands/qa/test.md) — `/qa:test` run tests (preset inferred from file suffix)
- [`commands/qa/report.md`](./commands/qa/report.md) — `/qa:report` produce reports (including `--kind xmind` → native `.xmind`)
- [`commands/qa/doctor.md`](./commands/qa/doctor.md) — `/qa:doctor` environment self-check
- [`commands/qa/validate.md`](./commands/qa/validate.md) — `/qa:validate` validate components and artifacts

---

## Rules

### Always-on global
- [`rules/qa-conventions.md`](./rules/qa-conventions.md) — consolidated convention set: spec.ts single-source-of-truth, annotation metadata, Page Object pattern, naming conventions, anti-fabrication hard constraints, TBD four-state lifecycle, final-output language policy, slash / MCP quick reference

### Contract rules (glob-triggered)
- [`rules/qa-case-md.md`](./rules/qa-case-md.md) — `case.md` contract: frontmatter schema + TC-NNN regex + HTML tag syntax
- [`rules/qa-perf-spec.md`](./rules/qa-perf-spec.md) — `perf-spec.yaml` contract: meta / scenarios / thresholds / hooks / observability

### Runner rules (preset-triggered)
- [`rules/qa-runner-web.md`](./rules/qa-runner-web.md) — Playwright / web runner conventions (`web-e2e` preset)
- [`rules/qa-runner-k6.md`](./rules/qa-runner-k6.md) — k6 runner conventions: scenario / threshold / tag (`k6-perf` preset)

### Reference rules
- [`rules/qa-failure-class.md`](./rules/qa-failure-class.md) — 7-class failure rubric + routing (glob: `.spec.ts` + trace)
- [`rules/qa-preset-types.md`](./rules/qa-preset-types.md) — preset cheatsheet (description-gated, on-demand)

---

## MCP server

- [`mcp/qa-kit.yaml`](./mcp/qa-kit.yaml) — stdio subprocess declaration: `npx @zmx/qa-kit mcp`

### Tool catalogue (18 tools)

#### Health & capability
- `qa.ping` — no-op health probe, returns `{ok, version, timestamp}`
- `qa.capabilities` — list registered tools, split into `implemented` / `stubs`

#### Design pipeline
- `qa.designTestCases` — PRD → case.md rubric prompt (consumer writes the file)
- `qa.reviewCoverage` — `caseMdPath` branch: parser-driven dimension matrix + gap report; legacy NL branch preserved

#### E2E pipeline
- `qa.draftE2ESpec` — `caseMdPath` + `xmindMdPath` + `designAssets` branch, or legacy NL branch; emits draft `spec.ts`
- `qa.validateSpec` — true annotation-schema validator (ts-morph AST) for `.spec.ts`; shares code with the CI `qa-kit validate` gate
- `qa.runTest` — invoke test run with `grep` / `testPath`, return summary
- `qa.heal` *(mutating)* — failure classification → heal prompt → diff proposal
- `qa.applyHealDiff` *(mutating)* — apply unified diff with Verify Loop gating; v0.2.0 hardened with `MISSING_INPUT` structured error when `patches` is missing (was a stack-trace previously)

#### Perf pipeline
- `qa.draftK6Scenario` — three-branch drafter (spec / case.md / simple), auto-detects `qa-perf/perf-spec.yaml`; v0.2.0 input v2 schema accepts `prdPaths` / `existingFixtures` / `existingProto` for explicit context injection (no business-domain heuristics)
- `qa.runK6` — invoke k6 run, emit `summary.json`
- `qa.analyzePerf` — per-scenario p95 + threshold breaches + error rate + bootstrap 95% CI + 7-class verdict + natural-language summary. **v0.2.0 critical fix**: correctly reads k6 v1.7 `handleSummary` per-metric threshold status (bare-boolean + legacy `{ok}` shapes) with stderr fallback; v0.1.x reported every threshold as `ok:true` regardless of actual outcome — upgrade required.
- `qa.runHooks` *(mutating)* — execute `perf-spec.hooks.pre_flight` / `post_run` with `shell` / `http` / `wait` / `sql`; captures `as_metric` output for analyzer

#### Account pool (cross-preset)
- `qa.poolLease` *(mutating, recommended)* — domain-neutral lease: `{record_id, run_id, leased_at, release_token}`
- `qa.poolRelease` *(mutating, recommended)* — release via `release_token`; v0.2.0 hardened with `MISSING_INPUT` / `LEASE_NOT_FOUND` structured errors
- `qa.leaseAccount` *(mutating, deprecated shim)* — kept for backward compatibility; emits a deprecation warning to stderr
- `qa.releaseAccount` *(mutating, deprecated shim)* — kept for backward compatibility; v0.2.0 hardened with `MISSING_INPUT` / `ACCOUNT_NOT_FOUND` structured errors

#### Stubs (P1)
- `qa.exportToTestRail` — returns `NOT_IMPLEMENTED_P1` by design

### Mutating tool idempotency contract

Tools marked *(mutating)* **require** `params._meta.runId` and `params._meta.idempotencyKey`, otherwise they return `IDEMPOTENCY_REQUIRED`. IDE MCP clients (Claude Code, Cursor) inject these automatically; raw shell `stdio` callers must provide them explicitly. Example:

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "qa.poolLease",
    "arguments": { "pool_name": "demo-pool", "presetName": "k6-perf" },
    "_meta": { "runId": "r1", "idempotencyKey": "k1" }
  }
}
```

Design rationale: mutating operations live on MCP (not CLI) because (1) idempotency context is agent-native and (2) CI healing/reconciliation flows are AI-agent-driven. Read-only flows (e.g. `accounts list/scan`, `perf baseline list/show`) have CLI equivalents for convenience.

---

## Consumer onboarding

```bash
# 1. install
pnpm add -D @zmx/qa-kit @zmx/aibundle

# 2. discovery (scans node_modules/@zmx/qa-kit/SKILLS.md and skills/*/SKILL.md)
pnpm exec aibundle discover

# 3. scaffold consumer project (injects .aibundle/ commands/rules/mcp mappings;
#    skills are referenced in-place from the installed package)
qa-kit init --preset web-e2e,test-case-design,k6-perf

# 4. aibundle's own config (schema owned by aibundle, not mirrored by qa-kit)
pnpm exec aibundle init --project

# 5. sync to IDE-native locations
#    (.claude/ / .cursor/ / .github/ / .gemini/ / AGENTS.md)
pnpm exec aibundle sync
```

After sync the consumer can invoke `/qa:design <prd.md>`, `/qa:draft-e2e`, `/qa:draft-perf`, etc. directly from any supported IDE. Component distribution is handled entirely by `aibundle`; qa-kit's responsibility is to **produce** components. See [`docs/distribution/COMPONENTS.md`](./docs/distribution/COMPONENTS.md) for the distribution contract.

---

## Versioning & compatibility

- **Contract changes** (case.md regex / HTML tag syntax / frontmatter / perf-spec schema) bump `schemaVersion` and the package minor version
- **Prompt-layer changes** (skills / rules / commands markdown) may ship in any patch release; AI components iterate freely with zero code cost
- **MCP tool signature changes** follow the same rule: mutating-contract changes are breaking, schema-additive changes are not

### v0.2.0 highlights (schema-additive, no contract break)

- 🚨 Critical analyzer fix — k6 v1.7 `handleSummary` threshold parsing (false-positive `ok:true` regression in v0.1.x). Verified on real testnet data (617 400 iterations, 5/8 breaches correctly flagged across 3 independent drills).
- New CLI surface: `qa-kit proto fetch`, `qa-kit perf analyze --output`, `qa-kit perf baseline accumulate`, `qa-kit report decode-dashboard / perf-run / long-tail`.
- New gates: `dead-metric` (C1), `fixtures-schema` (C2), `proto-reflection` (auto-triggered when `runtime.protocol: grpc`).
- HMAC dual-sign for mutating ops (`baseline reset`, `eval promote`) — secret resolved from `QA_KIT_BASELINE_SECRET` env or auto-generated `.qa-kit/baseline-secret`.
- MCP input-guard hardening on `applyHealDiff` / `poolRelease` / `releaseAccount` (was stack-traces, now structured `MISSING_INPUT` / `LEASE_NOT_FOUND` / `ACCOUNT_NOT_FOUND`).

Full feature list: [`CHANGELOG.md`](./CHANGELOG.md). Hands-on walkthrough with drill evidence: [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md).

For the full regression matrix — "if I touch X, which steps do I re-run" — see the bottom of [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md).
