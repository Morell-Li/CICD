---
name: qa-runner-web
description: Playwright / Web runner 约定 —— spec.ts 单一真源 / `test()` annotation schema / PO 复用模式 / 文件命名；selector 四层优先级；storageState 复用；trace policy；常见反模式。qa-e2e/tests 下任何 spec.ts / playwright.config.ts / po 文件都加载本规则。
globs: "qa-e2e/tests/**/*.spec.ts,qa-e2e/playwright.config.ts,qa-e2e/tests/po/**/*.ts"
priority: 30
category: scoped
---

# qa-runner-web — Playwright Conventions

## Runner Adapter (ADR-032 / ADR-036)

- NEVER `import { test, expect } from '@playwright/test'`
- ALWAYS `import { test, expect } from '@zmx/qa-kit/runners/web'`
- Why: the runner adapter injects fixtures (`useAccount` / `qaReporter`), enforces a unified trace policy, and insulates Core from Playwright version drift (ADR-032 `peerDependencies: ">=1.55 <2"`)

## Four-Layer Selector Priority

1. `getByRole('button', { name: '限价买入' })` — a11y semantics, most stable
2. `getByTestId('limit-buy-submit')` — requires the frontend to add `data-testid`
3. `getByLabel(...)` / `getByPlaceholder(...)` — form controls
4. `locator('css')` — last-resort fallback

NEVER use XPath, long CSS chains, `nth-child(n)`, or `:has-text` concatenated with business copy as the sole locator.

## storageState Reuse

- Logged-in state is obtained via the `useAccount({ tags, project })` fixture, which returns a storageState path
- The Playwright `project` chain combined with `parallelIndex` provides worker isolation (see `core/storage-state.md`)
- NEVER inline `storageState: { cookies: [...] }` in config — always use the fixture

## Trace Policy

- CI: `trace: 'retain-on-failure'` (retain on failure + upload blob)
- Local debug: `trace: 'on'` (turn on manually when developing)
- NEVER `trace: 'off'` — it deprives Doctor of classification input

## Default Timeouts (provided by preset; spec MUST NOT override)

- `expect.timeout`: 10_000
- `actionTimeout`: 15_000
- `navigationTimeout`: 30_000
- NEVER `waitForTimeout(<fixed ms>)` — flakiness amplifier

## Common Anti-Patterns

- Hard-coding business copy: `page.click('text=限价买入')` (breaks on i18n or copy change)
- Using `setTimeout` / `sleep` instead of `waitForResponse`
- `expect(condition).toBe(true)` instead of Playwright's retrying matchers (`toBeVisible` / `toHaveText`)
- Logging in via `beforeAll` outside `test.describe` (use the storageState fixture instead)

## Playwright Annotation Alignment

The `test()` annotation is qa-kit's source of truth for metadata (see `qa-conventions`); NEVER put business metadata in the test title.

Source of truth: `docs/runners/web.md` / ADR-032 / ADR-036

---

## Spec.ts Conventions

### 1 spec.md vs spec.ts (ADR-016)

- **`spec.ts` is the single source of truth**：tools only parse `spec.ts`；所有 metadata lives in the `test()` annotation（a JSON object）。
- **`spec.md` is the business narrative and AI prompt input**：it may drift or go missing，and tools **do NOT parse its frontmatter**。
- **No hashing / no auto-sync**：edits to `spec.md` are NEVER auto-propagated back to `spec.ts`。

### 2 Required `test()` Annotation Fields

```ts
test('<标题>', { annotation: [
  { type: 'jira', description: 'ZMX-123' },          // or null
  { type: 'productVersion', description: '2.45.0' },
  { type: 'runOn', description: 'staging' },         // or JSON.stringify(['staging','prod-mirror'])
  { type: 'dataCleaner', description: 'enabled' },   // enabled | disabled | inherit
  { type: 'tags', description: '@feature-limit-buy,@smoke' },
] }, async ({ page }) => { /* ... */ });
```

- `jira` may be `null`（must be back-filled at PR review；doctor warns otherwise）
- `tags` are comma-separated；MUST include at least one `@feature-<name>`

### 3 Page Object Pattern (mandatory)

- NEVER hard-code selector strings in `spec.ts`（exception: stable attributes like `data-testid="..."`）
- ALWAYS check `presets/<preset>/po/` and `tests/po/` first；if missing，add the PO before writing the spec
- PO naming：`<FeatureName>Page` / `<FeatureName>Panel`；methods use action verbs（`placeLimitBuyOrder`）

### 4 Selector Priority

1. `getByRole(...)`（a11y semantics）
2. `getByTestId(...)`（`data-testid`）
3. `getByLabel` / `getByPlaceholder`
4. `locator('css')` — last-resort fallback only

NEVER use：XPath、long CSS chains、`nth-child` index-based selectors。

### 5 Waits and Timeouts

- NEVER `page.waitForTimeout(<fixed ms>)` — it amplifies flakiness
- Wait for UI → `locator.waitFor({ state: ... })` or `expect.poll()`
- Wait for network → `page.waitForResponse(urlMatcher)`，combined with `expect(response.status()).toBe(200)`

### 6 Accounts and storageState

- NEVER read `.qa-kit/accounts.json` directly；always go through the `useAccount({ tags: [...] })` fixture（which calls `qa.leaseAccount` under the hood）
- NEVER commit plaintext storageState；rely on gitignore + pre-commit（ADR-010）

### 7 Naming

- Spec files：`<feature>.spec.ts`（kebab-case）
- PO classes：`<Feature>Page`（PascalCase）
- Fixtures：`qa` prefix or `<biz>` prefix（avoid colliding with native Playwright fixtures）

### 8 Import Constraints

- NEVER `import '@playwright/test'` directly
- ALWAYS `import { test, expect } from '@zmx/qa-kit/runners/web'`（goes through the runner adapter）
- Core / Preset / Project dependency is unidirectional（`eslint-plugin-boundaries` blocks reverse imports）

Source of truth：ADR-016 / ADR-032 / ADR-036 / `docs/core/core-runtime-guide.md`

---

