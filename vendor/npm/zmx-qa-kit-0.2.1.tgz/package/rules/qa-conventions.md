---
name: qa-conventions
description: qa-kit 通用约定 —— 最终产物输出语言策略；slash / MCP 速查。规模小、始终加载。专题规则（case md 硬约束、failureClass、preset cheatsheet、spec.ts runner 约定）已分别拆到 qa-case-md / qa-failure-class / qa-preset-types / qa-runner-web 以按需加载。
alwaysApply: true
priority: 20
category: global
---

# qa-kit Conventions (always-on core)

本文件只放**每次对话都该知道**的最小核心：输出语言策略 + slash/MCP 速查。
其余规则按场景拆开，见：

| 文件 | 生效场景 |
|---|---|
| `qa-case-md` | 编辑 `qa-design/cases/**/*.md`（反编造 / TBD 生命周期 / HTML 标签契约） |
| `qa-runner-web` | 编辑 `qa-e2e/tests/**/*.spec.ts` / playwright config（spec.ts 规范 + selector 优先级） |
| `qa-runner-k6` | 编辑 `qa-perf/scenarios/**/*.k6.ts` |
| `qa-failure-class` | 处理 E2E 失败 / trace（分类 rubric） |
| `qa-preset-types` | 讨论 preset 选择 / 初始化 / 三类工作流区别（按需） |

---

## 1. Output Language Policy

### 4.1 Why This Rule Exists

- qa-kit rules and skill prose are written in English because they are prompt input — English is token-efficient and yields stable instruction-following。
- Every user-facing artifact that qa-kit produces is read by 中文 QA / PM / dev stakeholders and MUST be in 简体中文。
- This rule decouples the two：prompt language is English，artifact language is Chinese，with no ambiguity。
- When skill prose and this rule disagree，this rule wins。

### 4.2 What Counts as a Final Artifact (Chinese, MUST)

- `specs/**/test-cases.md`（和任何 module-split `specs/<feature>/test-cases/*.md`）— body content、case titles、leaf bullet values、TBD answers、quadrant copy
- `specs/**/case.md` body content（titles、leaf values）
- Xmind / mindmap exports — node labels
- Coverage review reports — `missingItems`、rationale、human-readable explanations
- Spec test names passed to `test('<name>', ...)` when that name is designed to be read by humans（Jira / Allure）
- k6 scenario descriptions in dashboards / handoff cards
- Failure handoff cards — title、reproduction steps、suggested owner rationale
- Any chat reply that explains a failure、a coverage gap、or a plan to the user

### 4.3 What Stays English (technical surface)

- All code（TypeScript、Python、shell）including identifiers and variable names
- File paths、directory names、package names、import specifiers
- Frontmatter field names（`schemaVersion`、`feature`、`productVersion`、...）and enum values that are identifiers（`enabled` / `disabled` / `inherit`、`es` / `cjs`）
- Annotation `type` values（`jira`、`runOn`、`dataCleaner`、`tags`）
- Tag strings that are routing keys（`@feature-*`、`@smoke`、`perf-maker`）
- Error codes and classifier class names（`PARAM_MISSING`、`selector-drift`、`real-bug`）
- JSON keys、schema field names、CLI flag names

### 4.4 What Stays Verbatim Chinese (golden-template literals)

These strings are part of the downstream contract；AI MUST emit them character-for-character as-is。See `qa-case-md` rule (HTML Tag Contract section) for the full list；examples：

- Leaf key names：`前置条件：` `步骤：` `预期结果：` `触发方式：`
- Quadrant names：`C端` `B端` `前端功能交互测试` `后端业务逻辑测试`
- Fixed walkthrough name：`页面UI整体走查`
- Category values：`等价类` / `边界值` / `异常路径` / `契约`
- TBD statuses：`未问` / `已问待回` / `已回待回填` / `已闭环`
- The 10-point API contract names：`请求方式` `登录态` `请求体` `预期状态码` `预期响应` `必填参数缺失验证` `错误码验证` `边界条件验证` `未登录状态验证` `异常展示验证`
- Placeholders：`（本模块无 …）` `（文档未明确，需确认）` `（含义需确认）` `（占位）`

### 4.5 Precedence

- This rule OVERRIDES any instruction in skill prose that appears to request an English artifact。
- If a skill example happens to be in English for brevity，the actual artifact MUST still be in 简体中文。
- If unsure whether a given string is "artifact" or "identifier"，default to Chinese for artifact content and English for anything referenced by code or tooling。

最终产物必须简体中文；如有歧义以本规则为准。

---


## 2. qa-kit Quick Reference

One page to answer "which command do I type right now？"。Detailed semantics live in each linked doc。

### 5.1 The 10 Slash Commands

| Slash | What it does | Matching Skill / MCP tool | Preset |
|---|---|---|---|
| `/qa:draft-e2e <需求>` | Draft spec.ts + Verify Loop | `qa-draft-e2e-spec` / `qa.draftE2ESpec` | web-e2e |
| `/qa:test [--grep ...]` | Run Playwright / k6 tests | `qa.runTest` / `qa.runK6` | all executable |
| `/qa:heal <spec>` | Healer auto-fixes failing cases | `qa-heal-spec` / `qa.heal` + `qa.applyHealDiff` | web-e2e |
| `/qa:explain <spec>` | Human-readable failure translation + handoff card | `qa-explain-failure` | web-e2e |
| `/qa:doctor` | Environment / config self-check | CLI `qa-kit doctor`（no MCP） | all |
| `/qa:codegen <url>` | Record and draft initial spec.ts | `qa.record` | web-e2e |
| `/qa:design <prd>` | PRD → test-cases.md | `qa-design-test-cases` / `qa.designTestCases` | test-case-design |
| `/qa:review-coverage <feature>` | Audit test-case coverage | `qa-review-coverage` / `qa.reviewCoverage` | test-case-design |
| `/qa:draft-perf <描述>` | Draft k6 scenario | `qa-draft-k6-scenario` / `qa.draftK6Scenario` | k6-perf |
| `/qa:analyze <summary>` | Analyze k6 report + regression verdict | `qa-analyze-perf` / `qa.analyzePerf` | k6-perf |

### 5.2 MCP Tools by Category

**Core-reserved（cross-preset）**：`qa.leaseAccount` / `qa.releaseAccount` / `qa.validateSpec` / `qa.runTest`

**Type 1（web-e2e）**：`qa.draftE2ESpec` / `qa.heal` / `qa.applyHealDiff` / `qa.record`

**Type 2（k6-perf）**：`qa.draftK6Scenario` / `qa.runK6` / `qa.analyzePerf`

**Type 3（test-case-design）**：`qa.designTestCases` / `qa.reviewCoverage` / `qa.exportToTestRail`

### 5.3 Typical Journeys

**New Feature, Zero to One**
```
PRD.md
  → /qa:design          → test-cases.md
  → /qa:review-coverage        → gap analysis（→ /qa:design --overwrite to fill）
  → /qa:draft-e2e           → spec.ts
  → /qa:test            → run；on failure → /qa:explain or /qa:heal
```

**Failure Diagnosis Decision Tree**
```
failure
  → /qa:explain first translates it
    ├─ selector-drift / assertion-mismatch(spec-side) / network-flake / data-race / env
    │     → /qa:heal（Healer propose patch）
    ├─ real-bug / unknown / low confidence
    │     → handoff card（Lark / Jira）
    └─ perf failure（perf-class）
          → /qa:analyze for regression verdict → route to SRE
```

**Establishing a Perf Baseline**
```
/qa:draft-perf  → tests/perf/<name>.k6.ts
/qa:test         → qa.runK6 → summary.json
/qa:analyze      → bootstrap-CI → perf-class verdict
```

### 5.4 One-Liner: Can vs Cannot

| AI can | AI cannot |
|---|---|
| Draft spec / test-cases / k6 scenario | Infer failureClass freely（MUST go through classifier） |
| Render heal prompts by class | Edit annotation / test title / jira |
| Translate classifier output / emit handoff card | Edit k6 load scripts（forbidden in Type 2） |
| Assess coverage gaps | Auto-edit test-cases.md（human-approved via `/qa:design --overwrite`） |
| Fill selectors / waitForResponse by pattern | Fall back to `waitForTimeout` / XPath |

### 5.5 Invariants (ADR-021 at a glance)

1. `qa.applyHealDiff` MUST be invoked by the IDE LLM；MCP NEVER pushes in reverse
2. Verify Loop（tsc / playwright list / k6 inspect）is **LLM-free**
3. Classifiers（failureClass / coverage-class / perf-class）are **LLM-free**
4. Prompt templates live in `skills/**/references/`；**docs MUST NOT duplicate their body**

Source of truth：`docs/ai-workflow/qa-workflow.md` / `docs/ai-workflow/components-architecture.md` / `docs/ai-workflow/failure-class.md`

---

