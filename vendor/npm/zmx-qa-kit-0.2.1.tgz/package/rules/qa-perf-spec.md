---
name: qa-perf-spec
description: Declarative contract for a k6 load-test activity — scenarios, data pools, thresholds, pre/post hooks, analysis strategy. AI authoring guide for perf-spec.yaml; qa-kit scenario-schema gate enforces it. 压测活动声明契约 / perf-spec 编写规范 / 多 scenario 组合 / 阈值与基线.
globs: "qa-perf/perf-spec.yaml,qa-perf/perf-spec.yml,qa-perf/perf-spec.json,qa-perf/**/*.perf-spec.yaml"
priority: 45
category: scoped
---

# qa-perf-spec — 压测活动声明契约

## Scope

`qa-perf/perf-spec.yaml` 是一次**压测活动**的单一 source-of-truth。AI 起草压测时，先写这份 spec，再由 spec 驱动脚本生成 / runner 执行 / analyzer 判定。

**业务中性铁律**：spec 字段名与取值绝不含业务词（account/order/balance/...）。业务语义由 `meta.id`、`data_pools[].name`、`hooks[].ref` 指向的文件填入。

## 顶层字段

| 字段 | 必填 | 作用 |
|---|---|---|
| `version` | ✅ | 固定 `1`；schema 演进用 |
| `meta.id` | ✅ | slug；baseline 查找 key |
| `meta.description` / `meta.owner` | — | 人类元信息 |
| `runtime.script` | ✅ | k6 入口脚本路径（相对 spec 文件） |
| `runtime.warmup_duration` | — | 热身期；判定时剔除 |
| `runtime.measured_duration` / `cooldown_drain` | — | 信息性 / VU 停后等待 |
| `scenarios[]` | ✅ | 非空，并发跑的 k6 scenario 组合 |
| `data_pools[]` | — | 数据池声明 |
| `thresholds[]` | — | k6 threshold（支持 per-scenario） |
| `custom_metrics[]` | — | 自定义 Trend/Counter/Gauge/Rate 声明 |
| `hooks.pre_flight[]` / `hooks.post_run[]` | — | 前后置钩子 |
| `observability` | — | P1；Prometheus 抓取声明 |
| `analysis` | — | 判定策略（baseline / bootstrap-CI / tolerance） |
| `extensions` | — | 平台仓 / 业务自由扩展字段 |

## Scenario

```yaml
scenarios:
  - name: steady               # slug，将作为 tag { scenario: steady } 自动注入
    executor: constant-vus     # 或 ramping-vus / constant-arrival-rate / ...
    vus: 5                     # constant-vus 专用
    duration: 2m
    exec: steadyFlow           # 指向脚本里导出的函数名
    tags: { tier: baseline }   # 额外 tag（非必需）
    abort_on_threshold_fail: false
```

不同 executor 的必填字段：
- `ramping-vus` → `stages[]`（`{ duration, target }`）
- `constant-vus` → `vus`
- `constant-arrival-rate` → `rate`

多个 scenario 名必须唯一。

## Data Pool

```yaml
data_pools:
  - name: primary              # slug，helper 脚本用名字引用
    source: file               # file | sql | api（P0 只跑 file；sql/api 走 pre_flight 物化）
    ref: ./fixtures/items.json # JSON 数组
    lease_strategy: exclusive  # exclusive（每 VU 独占）| shared（VU 间随机采样）
    on_exhaust: skip           # skip（iteration 跳过）| fail（抛错）
```

## Threshold

```yaml
thresholds:
  - metric: http_req_duration
    scenario: steady          # 可选；限定到该 scenario 的子指标
    expr: "p(95)<500"         # k6 threshold 表达式
  - metric: http_req_failed
    expr: "rate<0.01"
```

scenario 过滤会生成 k6 子指标语法 `http_req_duration{scenario:steady}`。

## Hook

```yaml
hooks:
  pre_flight:                  # 活动启动前；失败即中止
    - { type: http, ref: https://svc/health, expect_status: 200, timeout: 5s }
    - { type: sql,  ref: ./hooks/seed.sql,   timeout: 30s }
    - { type: shell, ref: ./hooks/warmup.sh }

  post_run:                    # VU 停止 + cooldown_drain 之后
    - { type: wait, duration: 30s }            # 等异步收敛
    - { type: sql, ref: ./hooks/check.sql, as_metric: post_check }  # 结果并入 analyzer
```

hook `type` 枚举：`shell` / `sql` / `http` / `wait`。业务中性——ref 指向的脚本才包含业务语义。

## Analysis

```yaml
analysis:
  baseline: ./baseline.json   # 由 qa-kit perf baseline save 写入
  strategy: bootstrap-ci-p95  # bootstrap-ci-p95 | naive-p95 | raw
  regression_tolerance: 0.10  # samples < 5 时作为 fallback 固定容忍
```

baseline 文件格式：
```json
{ "schemaVersion": 1, "metric": "http_req_duration", "stat": "p(95)", "samples": [450, 462, 455, 470, 448] }
```
- `samples.length >= 5` → 触发 bootstrap CI（95% 置信）
- `samples.length < 5` → 退化到 `regression_tolerance` 固定判定

## 不写什么（避免 spec 污染）

- ❌ 部署配置（Dockerfile / k8s yaml）—— 平台仓的事
- ❌ 调度（cron）—— 平台仓 GitLab schedule 管
- ❌ 看板配置 —— 观测仓管
- ❌ 业务对账规则 —— 放 `hooks[].ref` 指向的 SQL，不放 spec 里
- ❌ 告警路由 —— 观测仓管

## 校验与反馈

- `scenario-schema` gate（qa-kit verify）会调 `validatePerfSpec`，错误 path+message 明确
- `qa.draftK6Scenario` Branch A 以此为输入生成脚本骨架
- `qa.analyzePerf` 读它知道该看哪些 threshold、哪些 scenario、用什么 analysis strategy

## Traffic model selection decision tree

PRD 经常用业务语言描述压力（"小时 N 笔"、"X 个并发用户"、"秒级峰值 + 滑窗均值"），
而 k6 executor 的语义边界是吞吐速率 vs 并发度。下表把常见 PRD 表述映射到 executor：

| PRD wording | Signal | k6 executor |
|---|---|---|
| "X TPS"、"N requests per hour" | Throughput rate (arrival side) | `constant-arrival-rate` 或 `ramping-arrival-rate` |
| "X concurrent users" | Concurrency (in-flight side) | `constant-vus` 或 `ramping-vus` |
| "second-level peak + sliding-window mean" | Bursty spike | `ramping-arrival-rate` + 多 stage |
| "0 → X gradual ramp" | Saturation curve | `ramping-*` stages |

**铁律：given a TPS number, never pick a VU model**。VU 数与 TPS 不等价——
单 VU 在 50 ms RTT 下能产生 ~20 TPS，在 5 ms RTT 下能产生 ~200 TPS。把 PRD
"300 TPS" 翻成 `vus: 300` 就丢失了到达速率约束，跑出来的曲线无法映射回需求。

### Bursty profile example

PRD 说 "1 秒突刺到 300 TPS、之后 4 秒回落到 25 TPS、5 秒滑窗均值约 80"，
对应的 spec scenario 配置：

```yaml
- name: spike_pattern
  executor: ramping-arrival-rate
  startRate: 25
  timeUnit: 1s
  preAllocatedVUs: 100
  maxVUs: 400
  stages:
    - { duration: 1s, target: 300 }   # spike
    - { duration: 4s, target: 25 }    # cool down
    # repeat — sliding-window mean ≈ (300 + 25*4)/5 = 80
```

`startRate` 是窗口起点，`stages[].target` 是该 stage 结束时的目标速率，k6
在 stage 内线性插值。把同一对 stages 重复 N 次即得到稳定的阵发画像；用单
段 `constant-arrival-rate: 80` 会丢失瞬时峰值压力，无法暴露 server 的突刺
处理能力。
