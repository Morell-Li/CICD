---
name: qa-preset-types
description: 三类 preset cheatsheet —— exec-correctness (web-e2e) / exec-non-correctness (k6-perf) / design (test-case-design) 行为差异，何时选哪个，Heal 是否挂，哪些工具有哪些。仅在讨论 preset 选择 / init / 项目启动 / 跨 preset 差异时加载（description-gated；默认不常驻）。
alwaysApply: false
priority: 15
category: on-demand
---

# qa-preset-types — preset selection cheatsheet

> 仅在"选 preset / init 新项目 / 解释 preset 差异"场景加载。日常写 spec / 修 heal 不用。

---

## Three Preset Categories

Per ADR-041，qa-kit groups every preset into one of three categories with sharply different behavior。**Picking the wrong category means every AI action downstream will be wrong**。

### 1 Side-by-Side Table

| Dimension | Type 1 exec-correctness | Type 2 exec-non-correctness | Type 3 design |
|---|---|---|---|
| **Representative preset** | `web-e2e` / `flutter-maestro` | `k6-perf`（visual-regression / a11y possible later） | `test-case-design` |
| **Artifact** | executable spec.ts | executable k6 script | markdown test-cases.md |
| **Runner** | Playwright / Maestro | k6 | `null`（nothing executes） |
| **Draft harness** | yes | yes | yes（TestCaseDraftHarness） |
| **Heal harness** | yes | no（AI must not edit scripts） | no（no "fix" concept，only "fill-in"） |
| **Doctor harness** | yes（7-class classifier） | yes（perf-class classifier） | yes（CoverageDoctor / coverage-class） |
| **failureClassifier** | `default-7class` | `perf-class` | `coverage-class` |
| **Write-back protocol** | two-step dry-run + apply（`qa.applyHealDiff`） | two-step dry-run + apply | **single-step direct write**（LLM Write tool） |
| **Eval strategy** | patch-shape + judge | `bootstrap-ci-p95` | `coverage-diff` |
| **G7 / G8 metrics** | applicable | not applicable | not applicable |

### 2 Decision Tree — Which to Pick

```
Is this an "executable" scenario?
├─ No（produces docs / matrix only）→ Type 3（test-case-design）
└─ Yes: do you care about "whether the result is correct" or "whether the system holds up"?
     ├─ Correctness（functional）→ Type 1（web-e2e / flutter-maestro）
     └─ Load / capacity / visual regression → Type 2（k6-perf / future visual-regression）
```

### 3 What AI Can Do (by category)

**Type 1**
- Draft spec.ts and POs；fix failures via the 5 heal prompts keyed by class：`selector-drift` / `assertion-mismatch` / `network-flake` / `data-race` / `env`
- Translate failures into human-readable form and emit handoff cards

**Type 2**
- Draft k6 scenarios；**analyze** `summary.json`（bootstrap-CI + p95-delta）
- Determine `perf-class` and emit handoff cards
- **MUST NOT edit the script**（`test-infra-issue` class allows manual human fixes，but AI NEVER edits）

**Type 3**
- Draft test-cases.md
- Audit coverage，emit `missingItems`
- **MUST NOT auto-edit test-cases.md**（gap-filling goes through `/qa:design --overwrite` with human approval）

### 4 What AI Does When It Fails (by category)

| Category | When class ∈ `real-bug` / `unknown` | Other classes |
|---|---|---|
| 1 | handoff card（Lark / Jira） | heal propose + apply + Verify |
| 2 | handoff card（SRE / dev） | **always** handoff card（no propose） |
| 3 | handoff card + requester confirmation | report missingItems + suggest `/qa:design --overwrite` |

### 5 Stacking Multiple Presets

A project may declare `qaKit.presets = ['web-e2e', 'test-case-design']`（the default bundle）。Multiple runners and classifiers are attached simultaneously；routing is by directory / runner context：

- `tests/**/*.spec.ts` → web-e2e（Type 1）
- `tests/perf/**/*.k6.ts` → k6-perf（Type 2）
- `specs/**/test-cases.md` → test-case-design（Type 3）

`/qa:design` 和 `/qa:draft-perf` 通过后缀显式消歧，避免 slash 歧义。

### 6 Anti-Patterns

- NEVER let AI edit k6 scripts under a Type 2 preset（forbidden）
- NEVER route Type 3 failures through `qa.heal`（that tool is not in its mcpTools list）
- NEVER use the Type 1 7-class classifier to interpret k6 failures（use `perf-class` instead）
- NEVER call `qa.*` tools without declaring a preset（MCP will reject）

Source of truth：`docs/presets/README.md` / `docs/presets/web-e2e.md` / `docs/presets/k6-perf.md` / `docs/presets/test-case-design.md` / ADR-041

---

