---
name: qa-runner-k6
description: k6 runner conventions — scenario naming, mandatory thresholds, tag spec, p95 assertions. k6 压测运行器约定 / scenario 命名 / threshold 必填.
globs: "tests/perf/**/*.k6.ts,tests/perf/**/*.k6.js"
priority: 50
category: scoped
---

# qa-runner-k6 — k6 Load Test Conventions

## Goal

Every `tests/perf/**/*.k6.ts` MUST satisfy the structural constraints below; the `k6-perf` preset's `scenario-schema` gate enforces them.

## File Layout

- Path: `tests/perf/<feature>.k6.ts` (`.ts` preferred; `.js` only for legacy compatibility)
- One file = one business scenario; multiple patterns within one file must live in distinct `scenarios` keys
- NEVER mix functional tests (`.spec.ts`) with load tests (`.k6.ts`) in the same tree

## Mandatory `options`

```ts
export const options = {
  scenarios: { /* at least 1 */ },
  thresholds: {
    http_req_duration: ['p(95)<N'],      // required
    http_req_failed:   ['rate<N'],        // required
    checks:            ['rate>N'],        // recommended
  },
  tags: { product: 'zmx' },               // global tag
};
```

NEVER omit `thresholds`; a scenario without thresholds cannot be classified as `threshold-breach`.

## Scenario Naming

- Key in kebab-case: `place_cancel` / `market_snapshot` / `capacity_ramp`
- Every scenario carries `tags: { scenario: '<name>' }` (same string as the key)
- NEVER let multiple scenarios share one `exec` function without distinct tags — the blob reporter's aggregation will collide

## Executor Choice

| Executor | Typical Use |
|---|---|
| `constant-vus` | constant VU steady-state load |
| `ramping-vus` | ramp-up + steady + ramp-down |
| `ramping-arrival-rate` | RPS-driven (closer to real traffic) |
| `per-vu-iterations` | fixed iterations per VU (coverage-style) |

NEVER use `shared-iterations` for "concurrent throughput" testing (VU pacing is not controlled, results are not comparable).

## Choosing Threshold Values

- p95 / p99 MUST align with the PRD performance target or the previous baseline
- Arbitrary values = meaningless baseline; if a new scenario has no target, collect first, set threshold later
- Industry rules of thumb (write `p95 < 300ms`, read `p95 < 150ms`) are heuristics, NOT business requirements

## Tag Spec

Three fixed layers:

- `product`: 'zmx' (top level)
- `scenario`: '<kebab-case>' (scenario layer)
- `name`: '<endpoint-label>' (request layer, set manually via `http.get(url, { tags: { name } })`)

The `blob` reporter / `k6-summary` reporter aggregate by these three layers; any missing layer breaks aggregation.

## Account Pool

- Load-test accounts use `perf-<role>` tags (`perf-maker` / `perf-taker`) to separate them from functional accounts
- NEVER hard-code username / token in the script; use `qa.leaseAccount` or the env var `__ENV.TOKEN`
- Multi-role scenarios (e.g. maker + taker matching) lease as a group via `qa.leaseAccount({ roles })`

## Forbidden Actions

- AI editing k6 scripts (ADR-041 Type 2 principle) — a perf failure = system issue; editing the script masks it
- Omitting thresholds
- Treating `checks` as a threshold (checks count success rate only; they do not affect exit code)
- Falling back to localhost when `__ENV` is missing (CI runs against prod-mirror)
- One file with multiple scenarios sharing the `default export` instead of distinct `exec`

## Artifacts and Baseline

- `summary.json` is uploaded to the blob reporter
- `baseline-k6-perf.json` stores p95 samples for the next `qa.analyzePerf` bootstrap-CI
- Baseline update policy: manual only (`qa-kit perf bless`); NEVER auto-overwrite baseline with the current run (that masks regressions)

Source of truth: `docs/presets/k6-perf.md` / `docs/runners/k6.md` (if present; post-P0)

## k6 gRPC field naming convention

k6 v1.7 uses `protobuf-js` underneath its gRPC client, which **auto-converts proto
`snake_case` field names to `lowerCamelCase`** at the JS boundary. This is silent
and easy to miss: response objects look fine for fields that happen to be a
single word, while every multi-word field is silently `undefined` if you read it
in `snake_case`.

Generic field-name mapping table:

| proto field | accessed as in JS |
|---|---|
| `error_code` | `errorCode` |
| `request_id` | `requestId` |
| `metric_value` | `metricValue` |

**Rule**: every TS interface declaration, request payload object, and response
field read in a k6 scenario MUST use `lowerCamelCase`. Do not type interfaces in
`snake_case` "to match the proto" — the wire format is unaffected; only the JS
view changes.

### int64 / uint64 / sint64 fields must be passed as `string`

JavaScript `number` cannot represent the full 64-bit integer range. If you
inline a numeric literal for an int64 request field, k6 may silently lose
precision. Pass these fields as `string`:

```ts
// good
client.invoke('/pkg.Svc/Method', { destinationId: '1234567890123456789' });

// bad — precision loss for large values
client.invoke('/pkg.Svc/Method', { destinationId: 1234567890123456789 });
```

The `defineGrpcClient` helper in `qa-perf/lib/protocols/grpc.ts` provides
**explicit opt-in** for this conversion via two parameters; there is no implicit
naming-convention magic:

- `int64Fields: string[]` — list the camelCase field names that must be
  stringified before invocation.
- `int64Suffix: string[]` — declare suffix sets (e.g. `['Id', 'No', 'Seq']`)
  that the helper should treat as int64-like for the project.

Both are user-supplied. The helper does **not** infer "any field ending in `Id`
is int64" on its own. If neither option is supplied, the helper passes the
request unchanged.

### `timeout` parameter must be conditional

k6's gRPC `params.timeout` accepts a Go-style duration string (`'5s'`,
`'500ms'`). Passing `timeout: undefined` triggers a runtime error
`nil duration value`. Always include the key only when you have a real value:

```ts
const params: Record<string, unknown> = { metadata, tags };
if (callOpts?.timeout) params.timeout = callOpts.timeout;
return client.invoke(method, request, params);
```

Never spread an options object that may contain `timeout: undefined` directly
into the params.
