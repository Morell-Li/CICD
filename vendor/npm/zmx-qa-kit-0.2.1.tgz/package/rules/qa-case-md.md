---
name: qa-case-md
description: case md 硬约束合集 —— 反编造（无源头 PRD 不许无中生有）/ TBD 注释四态生命周期 / HTML 标签契约（TC-NNN / 分类 / 维度 的尾标注解格式，供下游 parseCaseMd 消费）。仅在编辑 qa-design/cases/**/*.md 时加载，避免污染非 case 上下文。
globs: "qa-design/cases/**/*.md"
priority: 25
category: scoped
---

# qa-case-md — case md authoring hard constraints

> 本文件只在 AI 编辑 `qa-design/cases/**/*.md`（或同路径下的 `*.xmind.md`）时加载。
> 通用约定见 `qa-conventions`；spec.ts 规范见 `qa-runner-web`。

---

## 1. QA Anti-Fabrication Hard Rules

> 作用域：`qa-design/cases/**/*.md`（authoring time）

### 1.1 Why

- Test cases are a contract that aligns facts across 产品 / 研发 / 风控；fabricating a "plausible-looking" field or interface launders fake info into "spec"
- LLMs naturally tend to fill gaps and self-consistency；fabrication MUST be blocked at authoring time，not caught in post-hoc review
- When stakeholders see `（文档未明确，需确认）` it signals they need to answer；a fabricated rule just slips past them

### 1.2 Hard Rules

The following MUST NOT appear unless written verbatim in the source doc. 写下即违反硬规，立刻删除。

- **Page elements**：page names、button labels、input placeholders、copy、tabs、cards、modal titles
- **Business rules**：formulas、thresholds、state-machine transitions、validation logic、sort rules
- **Interfaces**：URL paths、HTTP methods、request fields、response fields、error codes
- **Roles and permissions**：role names、permission granularity（do NOT assume a default binary like "admin/user"）
- **Flows**：step order、branch conditions、trigger events
- **Error copy**：specific prompt text（the doc saying "prompt the user" does NOT imply any concrete wording exists）
- **Data ranges**：length limits、value ranges、precision、time windows

Avoidance actions：

- Leave blank and mark `（文档未明确，需确认）`（fullwidth parens and comma）
- If a PM follow-up is required，use `<!-- TBD:#X | 对接人 | 状态 | 日期 | 回答 -->`（see §2 TBD Lifecycle）

### 1.3 English Identifiers MUST Be Annotated With Chinese Meaning

**First occurrence** of any English identifier（field name、enum value、status value、config key、header name、error code）MUST be annotated with its Chinese meaning in parens：

- Correct：`status（订单状态）` / `traderLevel（交易员等级）` / `X-Request-Id（请求追踪 ID）`
- Wrong：bare `status` / `订单状态` without keeping the English original

Meaning-source priority：

1. Doc has an explicit definition → quote it directly
2. Doc is silent but semantics are clear → translate yourself，faithful to business context
3. Doc is silent and semantics are ambiguous → mark `（含义需确认）`，do NOT guess

### 1.4 Redis / Middleware Skip

- Redis caching、Redis read/write、message queues、cron schedulers 等 **implementation-layer** concerns are NOT tested
- Only test the **business-observable outcomes** these middlewares ultimately produce（UI rendering、API response、DB state）
- When the doc says things like "写入 Redis"，ignore it；do NOT convert it into a test case

### 1.5 Source Conflict: UI Mockup Wins

- When PRD prose conflicts with UI mockup recognition，**UI mockup takes precedence**
- Mark the divergence in the expected result as `（来源：UI 设计稿）`
- Aggregate all conflicts in the requirements-analysis section `## ⚠️ 文档中不清楚或缺失的内容`

### 1.6 Self-Check

Before delivery，answer three questions：

1. For every field name / interface / button in the file，can it be grep'd in the PRD source？If not，it's fabricated
2. Does every first occurrence of an English identifier carry a Chinese meaning annotation？
3. Are there any Redis / cache-related test cases？If yes，delete them

> Rather leave 10 `（文档未明确，需确认）` placeholders than write 1 fabricated line.

---


## 2. TBD Annotation Lifecycle

> 作用域：`qa-design/cases/**/*.md`

### 2.1 Why

- "待 PM 确认"散落在口头备忘从不闭环
- A single grep-able anchor makes the four states（未问 / 已问待回 / 已回待回填 / 已闭环）scannable directly from the file
- Keeps TBD distinct from the inline soft hint `（文档未明确，需确认）`：TBD MUST carry a contact、ask date、and answer

### 2.2 Unified Annotation Format

```
<!-- TBD:#X | 询问对象 | 状态 | 问日期 | 回答 -->
```

| Field | Value | Example |
|---|---|---|
| `#X` | Open-question ID（required，unique within file） | `#G01` / `#Q02` |
| 询问对象 | Contact；write `TBA` if unassigned | `PM: @zhang` / `风控: @ruby` |
| 状态 | One of four（see below） | `未问` |
| 问日期 | `YYYY-MM-DD`；write `-` if not yet asked | `2026-04-22` |
| 回答 | ≤ 30-char summary；write `-` if not yet answered | `A(top 30)` |

HTML comments are invisible in rendered Markdown but `rg` / `grep` finds them。MUST 占用独立一行 or sit **on the same line as a heading**；do NOT wedge them between leaf bullets。

### 2.3 Four States

| State | Meaning | Trigger |
|---|---|---|
| `未问` | Question identified，not yet sent | 询问对象 = `TBA` or empty |
| `已问待回` | Sent，waiting for reply | 问日期 ≠ `-` and 回答 = `-` |
| `已回待回填` | Answer received，placeholder not yet replaced | 回答 ≠ `-` but comment still present |
| `已闭环` | Placeholder replaced + comment deleted + tracker checked | `grep` finds nothing |

### 2.4 Closure: Three Actions (strict order)

1. **Replace placeholder**：swap the TBD's placeholder constant in the test case with the final answer（e.g. `TOP_N = 30`）
2. **Delete comment**：remove the entire `<!-- TBD:#X ... -->` line adjacent to the placeholder
3. **Check tracker**：tick ☑ in `specs/<feature>/tbd-tracker.md`（optional）

> Replace value → delete comment → check tracker. At any interruption point，`rg 'TBD:#'` recovers the open items.

### 2.5 Full Example

**Initial (未问)**:

```markdown
- 预期结果：榜单仅包含排名前 **TOP_N = 50** 的合约币对
<!-- TBD:#G01 | TBA | 未问 | - | - -->
```

**已问待回**：

```markdown
<!-- TBD:#G01 | PM: @zhang | 已问待回 | 2026-04-22 | - -->
```

**已回待回填**（PM chose: top 30）：

```markdown
<!-- TBD:#G01 | PM: @zhang | 已回待回填 | 2026-04-22 | A(top 30) -->
```

**已闭环**：

```markdown
- 预期结果：榜单仅包含排名前 **30** 的合约币对
```

Comment deleted；tracker checked。`rg 'TBD:#G01' specs/` returns empty。

### 2.6 Bulk-Check Commands

```bash
rg 'TBD:#' -n specs/                       # all unclosed TBDs
rg 'TBD:#.+\bTBA\b' -n specs/              # 未问 only
rg 'TBD:#.+已问待回' -n specs/              # 已问待回 only
rg 'TBD:#.+已回待回填' -n specs/            # back-fill reminders
```

### 2.7 Difference vs Inline `（文档未明确，需确认）`

| Usage | Scenario | Goes through closure? |
|---|---|---|
| `（文档未明确，需确认）` inline | Soft hint inside 前置条件 / 步骤 / 预期结果，shown to the executor | No |
| `<!-- TBD:#X ... -->` HTML comment | Hard open question requiring PM / contact answer | Yes，via three-action closure |

The two **may coexist**：the same expected result can carry both an inline soft hint and a TBD comment for tracker follow-up。

### 2.8 Optional Tracker File

- Lives at `specs/<feature>/tbd-tracker.md`
- One row per open question：`| #X | 询问对象 | 状态 | 问日期 | 回答 | 用例回填 |`
- Multi-module projects can aggregate a global tracker at `specs/` root
- Small projects can skip it；`rg` over `qa-design/cases/**/*.md` is enough

---


## 3. case.md HTML Tag Contract

> This section is a **cross-skill stable contract**。Every skill that produces or consumes case.md（design / coverage / e2e / perf ...）must respect this format strictly。Downstream code（`parseCaseMd` / `validateCaseMd` in `@zmx/qa-kit`）parses by this contract and **does not depend on outer structure**。
>
> 作用域：`qa-design/cases/**/*.md`

### 3.1 Why IDs and Metadata Live in HTML Comments

- Titles stay pure Chinese and human-readable：`##### 正常取消 active 状态订单` is both the case name and a doc outline entry
- Stable `TC-NNN` IDs do not pollute titles — rendering、TOC、review all stay clean
- HTML comments are invisible in rendered Markdown but `rg` and parsers still pick them up
- Downstream tools only honor the comment contract，so **upper-layer prompt / skill structure is free to iterate**（C/B quadrants、equivalence-class H2、the 10-point API block、...）

### 3.2 TC-NNN Format

- Shape：`TC-\d{3,4}`；3- or 4-digit is controlled by frontmatter `idWidth`（default 3）
- MUST be unique within a single file；cross-file uniqueness is guaranteed by `project + module`
- Legal：`TC-001` / `TC-100` / `TC-0999`
- Illegal：`TC-1`（too few digits） / `TC001`（missing hyphen） / `TC-01A`（contains letters）

### 3.3 Trailing Comment Syntax

```
<!-- id:TC-001 | 分类:等价类 | 维度:status=active,role=owner -->
```

| Key | Optional | Values |
|---|---|---|
| `id` | No（required to be recognized as a case） | `TC-NNN` or `TC-NNNN` |
| `分类` | Yes（recommended when `id` is present） | `等价类` / `边界值` / `异常路径` / `契约`，combinable via `,` |
| `维度` | Yes | `k=v`，multiple keys separated by `,` |

**Position Rules**

- **Same line, immediately after the title** is the preferred form；a standalone comment on the **line immediately following the title** is also accepted（tolerant form）
- Keys are separated by ` | `（space + pipe + space）；`key:value` accepts either full-width `：` or half-width `:`
- MUST NOT be inserted between leaf bullets（e.g. `- 前置条件:...`）
- MUST NOT use `TC-001` as a title prefix（IDs live only in comments）

### 3.4 Frontmatter Fields

```yaml
schemaVersion: '2.0'      # required, fixed as '2.0'
feature: 'order-cancel'   # required
idWidth: 3                # default 3
idRange:
  equivalence: [1, 99]
  boundary: [100, 199]
  exception: [200, 299]
  contract: [300, 399]
```

- Missing `schemaVersion` / value != `'2.0'` → validator `error`
- Missing `feature` → validator `error`
- Missing `idRange` falls back to the defaults above
- Out-of-range ID（e.g. `TC-150` tagged `分类:等价类`）→ validator `warn: ID_OUT_OF_RANGE`

### 3.5 TBD Comment

```
<!-- TBD:#X | 询问对象 | 状态 | 问日期 | 回答 -->
```

- Status ∈ `未问` / `已问待回` / `已回待回填` / `已闭环`
- MUST occupy its own line；the three closure actions are documented in §2 (TBD Lifecycle)

### 3.6 Legal Examples

```markdown
##### 正常取消 active 状态订单 <!-- id:TC-001 | 分类:等价类 | 维度:status=active,role=owner -->
- 前置条件：用户已登录；订单状态 = `active`
- 步骤：进入订单详情页 → 点击"取消订单" → 确认弹窗
- 预期结果：订单状态变为 `canceled`

##### 边界：订单 ID 长度 = 32 <!-- id:TC-100 | 分类:边界值 | 维度:orderId.len=32 -->
- 步骤：…
- 预期结果：…

###### 请求方式 <!-- id:TC-300 | 分类:契约 -->
- POST，Content-Type: application/json

##### 组合分类示例 <!-- id:TC-307 | 分类:契约,边界值 -->
- …

##### 容错：注释放下一行
<!-- id:TC-002 | 分类:等价类 -->
- 步骤：…
- 预期结果：…

<!-- TBD:#G01 | PM: @wang | 未问 | - | - -->
```

### 3.7 Illegal Examples (rejected by validator)

```markdown
<!-- id:TC-1 -->                     # too few digits; ID_FORMAT_INVALID
<!-- id:TC-001 | 分类:等价类 -->     # same id twice in one file: DUPLICATE_ID
<!-- TC-001 -->                      # missing `id:` prefix: MALFORMED_COMMENT（not recognized）
##### TC-001 取消订单                # TC-xxx as title prefix（forbidden）
- **优先级**：P0                     # writing priority is forbidden
<!-- id:TC-001 | 分类:紧急 -->       # non-standard category: CATEGORY_UNKNOWN（warn）
```

### 3.8 Hard Rules for AI

- When generating case.md，AI MUST emit `id` / `分类` / `维度` strictly in the comment syntax defined here
- When consuming case.md，AI MUST use `parseCaseMd` from `@zmx/qa-kit` — NEVER regex-parse the Markdown structure yourself
- Changes to heading depth / quadrant names / leaf key names are NOT contract violations；**as long as the TC comment contract holds，the change is backward-compatible**
- Record open questions via TBD comments，NEVER as inline TODOs

---

