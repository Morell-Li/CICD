---
name: qa-failure-class
description: failureClass 分类 rubric —— selector-drift / assertion-mismatch / network-flake / data-race / env / real-bug / unknown 七类定义 + 程序化分类边界（LLM 不自判）。仅在 E2E 失败 / heal / explain 场景加载。
globs: "qa-e2e/tests/**/*.spec.ts,qa-results/e2e/**/*.json,qa-results/e2e/**/*.zip"
priority: 25
category: scoped
---

# qa-failure-class — failureClass rubric

> 仅在处理 E2E 失败 / trace / heal prompt 时加载。编辑普通 spec 不需要。

---

## failureClass Classification Rubric

### 1 Core Principle (ADR-021 / ADR-033)

- NEVER let the LLM infer `failureClass` from free-text error messages；classification is a programmatic action performed by MCP `qa.heal` or `skills/qa-explain-failure/scripts/classifier.ts`。
- The LLM does exactly two things：(1) translate the classifier result into human-readable form / handoff card，(2) route the next action based on the class。
- **Class costs are asymmetric**：`real-bug` threshold **0.50**，`selector-drift` threshold **0.75**。Prefer false-positive human review over missing a production regression。

### 2 Seven-Class Quick Reference

| Class | Typical Semantics | Routing |
|---|---|---|
| `selector-drift` | Locator not found / DOM structure changed | `/qa:heal` propose（Healer） |
| `assertion-mismatch` | `expect()` fails but surrounding steps pass | Depends on semantics：spec-side drift → propose；business assertion → escalate to real-bug |
| `network-flake` | Specific request timeout / 5xx，passes on retry | Suggest rerun（`--retries=2`） |
| `data-race` | Dirty account / dataCleaner did not run / concurrent conflict | Check `dataCleaner` annotation + account-pool GC |
| `env` | storageState expired / target service unreachable | Notify Ops + `qa-kit doctor` |
| `real-bug` | Business assertion fails + recent code changes touch the path | **REFUSE propose；emit handoff card** |
| `unknown` | No class reaches threshold | Human review + handoff card；if share > 15%，trigger ADR to extend classes |

### 3 Routing Hard Rules

- `real-bug` / `unknown` → **Healer MUST refuse propose**，route directly through `qa-explain-failure`'s handoff-card path
- `selector-drift` / `assertion-mismatch (spec-side)` → Healer propose → `qa.applyHealDiff`
- `network-flake` → do NOT edit code；suggest rerun or isolate via `@quarantine`
- `env` → do NOT edit code；notify Ops / SRE
- `data-race` → first verify `dataCleaner: enabled` actually ran；then decide whether to fix spec or cleaner implementation

### 4 Handoff Card (real-bug / unknown)

Required fields，fixed order：

1. Title（single sentence，copy-friendly for Jira）
2. Affected version（`productVersion` annotation）
3. Reproduction steps（3–5 key steps extracted from trace）
4. trace.zip / Allure link
5. `failureClass + confidence + evidence`
6. Suggested Owner（P0: manual；P1: auto-routed via CODEOWNERS）

### 5 Anti-Patterns

- LLM skimming an error message and declaring "this is probably selector-drift" then editing code
- Misclassifying `real-bug` as `selector-drift` and masking a production regression
- Using `network-flake` as a catch-all for anything unclassifiable（it should be `unknown`）

Source of truth：`docs/ai-workflow/failure-class.md` / ADR-033
