/**
 * Business-neutral think-time helpers — jittered sleep 避免 VU 锁步打点。
 *
 * 平铺 sleep(1) 会让所有 VU 每秒同一毫秒同时发请求，服务端看到"尖脉冲"而非
 * 平稳流量，指标失真。接入任意 scenario 都应用 thinkTime 代替 raw sleep。
 */

import { sleep } from 'k6';

/** 均匀分布：[minSec, maxSec] 之间一个 float 秒数。 */
export function uniformThinkTime(minSec: number, maxSec: number): void {
  if (maxSec <= minSec) {
    sleep(minSec);
    return;
  }
  const span = maxSec - minSec;
  sleep(minSec + Math.random() * span);
}

/**
 * 高斯抖动（Box–Muller）：均值 meanSec，标准差 sdSec；结果夹逼到 [min, max]。
 * 适合"大多数请求集中在平均间隔附近、少数偏长尾"的真实用户行为建模。
 */
export function gaussianThinkTime(
  meanSec: number,
  sdSec: number,
  minSec = 0,
  maxSec = Number.POSITIVE_INFINITY,
): void {
  const u1 = Math.random() || Number.EPSILON;
  const u2 = Math.random();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  const raw = meanSec + z * sdSec;
  const clamped = Math.min(Math.max(raw, minSec), maxSec);
  sleep(clamped);
}

/**
 * Poisson 到达间隔（Exp 分布）：给定目标 rate (req/sec)，计算下一次等待。
 * 常用于 arrival-rate 场景内部对齐真实 Poisson 到达。
 */
export function poissonInterval(ratePerSec: number): void {
  if (ratePerSec <= 0) return;
  const u = Math.random() || Number.EPSILON;
  const seconds = -Math.log(u) / ratePerSec;
  sleep(seconds);
}
