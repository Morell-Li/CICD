/**
 * Token pool prefetch helper — designed to run inside k6 `setup()`.
 *
 * Many auth schemes issue one-time tokens (OAuth challenge / nonce / signed
 * one-shot credentials). Such systems require a pre-generated pool that VUs
 * draw from via `SharedArray`. This helper performs `count` parallel POSTs
 * during setup() (which is allowed to block) and returns the token list.
 *
 * Business-neutral: the helper does not know what a "token" is — callers
 * supply `body` per index and an `extractToken` projection.
 *
 * Failure semantics: individual POST failures are tolerated (partial fill);
 * the helper throws only when zero tokens were retrieved.
 */

import http from 'k6/http';
import type { RefinedResponse, ResponseType } from 'k6/http';

export interface PrefetchTokenPoolOptions<TBody = unknown, TResp = unknown> {
  /** Endpoint that issues a single token per call (POST). */
  readonly url: string;
  /** Number of tokens to prefetch. */
  readonly count: number;
  /** Concurrency for the prefetch batch. Default 5. */
  readonly parallelism?: number;
  /** Static body or a per-index factory. */
  readonly body: TBody | ((i: number) => TBody);
  /**
   * Extract the token string from one HTTP response body.
   * Default: `r => (r as any).token ?? String(r)`.
   */
  readonly extractToken?: (resp: TResp) => string;
  /** Optional headers shared by every POST. */
  readonly headers?: Record<string, string>;
}

/** Internal seam — overridable for unit tests; production uses k6 http.post. */
export interface PrefetchTokenPoolDeps {
  post: (
    url: string,
    body: string,
    headers: Record<string, string> | undefined,
  ) => RefinedResponse<ResponseType | undefined> | { status: number; body?: string | null };
}

const defaultDeps: PrefetchTokenPoolDeps = {
  post(url, body, headers) {
    return http.post(url, body, headers ? { headers } : undefined);
  },
};

function defaultExtract<TResp>(resp: TResp): string {
  if (resp && typeof resp === 'object' && 'token' in (resp as Record<string, unknown>)) {
    const t = (resp as Record<string, unknown>).token;
    if (typeof t === 'string') return t;
  }
  return String(resp);
}

function resolveBody<TBody>(body: TBody | ((i: number) => TBody), i: number): TBody {
  return typeof body === 'function' ? (body as (n: number) => TBody)(i) : body;
}

/**
 * Run `count` POSTs (in batches of `parallelism`, sequential between batches
 * because k6 `http.post` is synchronous per call) and return the resolved
 * token list. Suitable as a k6 setup() return value feeding a SharedArray.
 *
 * @throws when zero tokens were retrieved.
 */
export function prefetchTokenPool<TBody = unknown, TResp = unknown>(
  opts: PrefetchTokenPoolOptions<TBody, TResp>,
  depsOverride?: PrefetchTokenPoolDeps,
): string[] {
  const deps = depsOverride ?? defaultDeps;
  const extract = opts.extractToken ?? (defaultExtract as (resp: TResp) => string);
  const tokens: string[] = [];
  // k6 http.post is blocking — "parallelism" semantics here mean batch size
  // before logging progress; iteration order remains sequential. Kept as a
  // parameter so the API is forward-compatible with a future async runner.
  const batch = Math.max(1, opts.parallelism ?? 5);
  let processed = 0;
  for (let i = 0; i < opts.count; i++) {
    try {
      const payload = JSON.stringify(resolveBody(opts.body, i));
      const res = deps.post(opts.url, payload, opts.headers);
      const status = res.status;
      if (typeof status === 'number' && status >= 200 && status < 300) {
        const raw = (res as { body?: string | null }).body ?? '';
        let parsed: unknown;
        try {
          parsed = raw ? JSON.parse(raw) : raw;
        } catch {
          parsed = raw;
        }
        const t = extract(parsed as TResp);
        if (typeof t === 'string' && t.length > 0) {
          tokens.push(t);
        }
      }
    } catch {
      // partial-fill tolerated
    }
    processed++;
    if (processed % batch === 0) {
      // eslint-disable-next-line no-console
      console.log(`[token-pool] prefetched ${tokens.length}/${opts.count}`);
    }
  }
  if (tokens.length === 0) {
    throw new Error(
      `prefetchTokenPool: failed to retrieve any token (requested=${opts.count})`,
    );
  }
  return tokens;
}
