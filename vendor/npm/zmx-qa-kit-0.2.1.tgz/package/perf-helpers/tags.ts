/**
 * Scenario tag discipline — 让 k6 metrics 能 per-scenario 拆分。
 *
 * k6 默认把所有 scenario 的指标合并到一个 p95。分析阶段想拆（normal vs burst）
 * 必须在发请求前贴 { scenario: name } tag。qa-kit 的 analyzePerf 依赖这个
 * 约定做 per-scenario 分组。
 */

import exec from 'k6/execution';

/**
 * 返回当前 scenario 名（来自 k6 exec.scenario.name）。在 scenario 外调用会抛。
 */
export function currentScenario(): string {
  return exec.scenario.name;
}

/**
 * 生成统一 tag map：scenario + 调用方附加。
 * 用法：http.get(url, { tags: scenarioTags({ endpoint: 'items' }) })
 */
export function scenarioTags(
  extra: Record<string, string> = {},
): Record<string, string> {
  return { ...extra, scenario: currentScenario() };
}
