/**
 * Correlation / trace IDs — 为每个 VU × iteration 生成唯一 id，注入请求头。
 *
 * 用途：服务端日志/追踪反查某一次请求为何慢。qa-kit analyze 报告中
 * 每条失败都会带 trace id，定位时 QA 直接贴给后端查。
 *
 * Id 形态：<runId>-<VU>-<ITER>，不引入 crypto 依赖，足够用于一次压测窗口。
 */

import exec from 'k6/execution';

/** 当前 run 唯一 id（k6 本次执行的 unique seed；多机分布式跑可由 env 注入）。 */
function runId(): string {
  return (
    (globalThis as { __QA_RUN_ID__?: string }).__QA_RUN_ID__ ??
    __ENV.QA_RUN_ID ??
    String(exec.test.iterationsStarted)
  );
}

/**
 * 返回当前 VU × iter 的 trace id。同一 iter 内多次调用返回同一 id（避免一个
 * 业务动作拆成多个 trace，服务端看起来是断的）。
 */
export function traceId(): string {
  return `${runId()}-${exec.vu.idInTest}-${exec.vu.iterationInScenario}`;
}

/**
 * 把 trace header 合进已有 headers。推荐 header 名走 W3C traceparent 家族或
 * 业务服务已识别的头（由调用方选择 key）。
 */
export function withTraceHeader(
  headers: Record<string, string> = {},
  headerName = 'x-qa-trace-id',
): Record<string, string> {
  return { ...headers, [headerName]: traceId() };
}
