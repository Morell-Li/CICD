/**
 * Standardized k6 debug logging — opt-in via `QA_K6_DEBUG=1`.
 *
 * Convention: helpers across protocols (grpc / http / future ones) call
 * `k6DebugLog(prefix, payload)` to emit a single structured line on the very
 * first iteration of each VU only. Production runs pay zero cost when the
 * env flag is not set.
 *
 * Non-k6 environments (unit tests, build-time imports) are tolerated — the
 * helpers guard `__ENV` access via `typeof` checks and read iteration through
 * a lazy import that may be `undefined` outside k6.
 */

import exec from 'k6/execution';

declare const __ENV: Record<string, string> | undefined;

/** Whether `QA_K6_DEBUG=1` is set in the current k6 env. */
export function isK6DebugEnabled(): boolean {
  if (typeof __ENV === 'undefined') return false;
  return __ENV.QA_K6_DEBUG === '1';
}

function currentIteration(): number | undefined {
  try {
    // exec.vu is only populated inside a VU context; reading in init / tests
    // can throw — treat as "no VU context" and skip the iteration gate.
    const it = exec?.vu?.iterationInScenario;
    return typeof it === 'number' ? it : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Emit a single structured debug line on the first iteration of the current VU.
 *
 * Output format: `[<prefix>] key1=<json> key2=<json> ...`
 *
 * No-op when `QA_K6_DEBUG !== '1'`.
 * No-op when running on iterations other than the first (per VU).
 */
export function k6DebugLog(prefix: string, payload: Record<string, unknown>): void {
  if (!isK6DebugEnabled()) return;
  const it = currentIteration();
  if (it !== undefined && it !== 0) return;
  const parts: string[] = [];
  for (const k of Object.keys(payload)) {
    let s: string;
    try {
      s = JSON.stringify(payload[k]);
    } catch {
      s = String(payload[k]);
    }
    parts.push(`${k}=${s}`);
  }
  // eslint-disable-next-line no-console
  console.log(`[${prefix}] ${parts.join(' ')}`);
}
