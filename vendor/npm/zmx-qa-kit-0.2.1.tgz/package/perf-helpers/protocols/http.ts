/**
 * HTTP helper — 通用 wrapper：自动 trace header + scenario tag + 可选一次重试。
 *
 * 业务中性：不知道任何业务端点。业务仓在 scenario 里声明 baseURL 和 path 后
 * 这个 helper 把横切关注点（tracing、tagging、timeout）统一处理。
 *
 * 不追求覆盖所有 k6/http 能力：scenario 可以直接用 k6/http，helper 只是建议
 * 默认的工业化姿势，业务侧用 raw http 也完全允许。
 */

import http from 'k6/http';
import type { Params, RefinedResponse, ResponseType } from 'k6/http';

import { scenarioTags } from '../tags.ts';
import { withTraceHeader } from '../correlation.ts';

export interface HttpOptions extends Params {
  /** 附加业务 tag（不必包含 scenario，会自动注入）。 */
  bizTags?: Record<string, string>;
  /** 遇网络/5xx 时是否重试一次（默认 false）。 */
  retryOnce?: boolean;
}

function compose(opts?: HttpOptions): Params {
  const tags = scenarioTags(opts?.bizTags);
  const headers = withTraceHeader(opts?.headers as Record<string, string> | undefined);
  return {
    ...(opts ?? {}),
    tags: { ...tags, ...(opts?.tags ?? {}) },
    headers,
  };
}

function shouldRetry(res: RefinedResponse<ResponseType | undefined>): boolean {
  if (res.error) return true;
  if (typeof res.status === 'number' && res.status >= 500) return true;
  return false;
}

export function get(url: string, opts?: HttpOptions): RefinedResponse<ResponseType | undefined> {
  const params = compose(opts);
  const res = http.get(url, params);
  if (opts?.retryOnce && shouldRetry(res)) return http.get(url, params);
  return res;
}

export function post(
  url: string,
  body: string | object,
  opts?: HttpOptions,
): RefinedResponse<ResponseType | undefined> {
  const params = compose(opts);
  const payload = typeof body === 'string' ? body : JSON.stringify(body);
  const res = http.post(url, payload, params);
  if (opts?.retryOnce && shouldRetry(res)) return http.post(url, payload, params);
  return res;
}

export function put(
  url: string,
  body: string | object,
  opts?: HttpOptions,
): RefinedResponse<ResponseType | undefined> {
  const params = compose(opts);
  const payload = typeof body === 'string' ? body : JSON.stringify(body);
  return http.put(url, payload, params);
}

export function del(url: string, opts?: HttpOptions): RefinedResponse<ResponseType | undefined> {
  return http.del(url, null, compose(opts));
}
