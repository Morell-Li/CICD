/**
 * Pure helpers for explicit int64 / uint64 / sint64 field stringification.
 *
 * k6's protobuf-js integration requires 64-bit numeric fields to be sent as
 * strings (otherwise JS Number precision corrupts large values). qa-kit does
 * NOT auto-detect such fields by naming convention — callers must declare
 * them explicitly via `int64Fields` (exact key list) or `int64Suffix` (list
 * of suffixes the caller chose to opt in).
 *
 * Default behavior: pass through unchanged.
 */

export interface Int64TransformConfig {
  /** Exact field names that must be String()'d. Takes precedence over suffixes. */
  readonly int64Fields?: readonly string[];
  /** Suffixes (e.g. `['Seq']`) — fields whose key ends with any are String()'d. */
  readonly int64Suffix?: readonly string[];
}

function shouldTransformKey(
  key: string,
  fields: ReadonlySet<string>,
  suffixes: readonly string[],
): boolean {
  if (fields.has(key)) return true;
  for (const sfx of suffixes) {
    if (sfx.length > 0 && key.endsWith(sfx)) return true;
  }
  return false;
}

function transformObject(
  input: Record<string, unknown>,
  fields: ReadonlySet<string>,
  suffixes: readonly string[],
  depth: number,
): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const k of Object.keys(input)) {
    const v = input[k];
    if (shouldTransformKey(k, fields, suffixes) && v !== undefined && v !== null) {
      out[k] = String(v);
      continue;
    }
    if (
      depth > 0 &&
      v !== null &&
      typeof v === 'object' &&
      !Array.isArray(v)
    ) {
      out[k] = transformObject(
        v as Record<string, unknown>,
        fields,
        suffixes,
        depth - 1,
      );
      continue;
    }
    out[k] = v;
  }
  return out;
}

/**
 * Build a request transformer function according to explicit config.
 *
 * - If neither `int64Fields` nor `int64Suffix` is provided (or both empty),
 *   returns an identity function (request passes through untouched).
 * - Otherwise walks top-level keys plus one level into nested plain objects;
 *   matching keys are stringified via `String(value)`.
 * - Arrays and primitives are not descended into.
 */
export function buildInt64Transformer(
  cfg: Int64TransformConfig,
): <T>(req: T) => T {
  const fieldList = cfg.int64Fields ?? [];
  const suffixList = cfg.int64Suffix ?? [];
  if (fieldList.length === 0 && suffixList.length === 0) {
    return <T>(req: T): T => req;
  }
  const fields = new Set<string>(fieldList);
  return <T>(req: T): T => {
    if (req === null || req === undefined) return req;
    if (typeof req !== 'object' || Array.isArray(req)) return req;
    return transformObject(
      req as Record<string, unknown>,
      fields,
      suffixList,
      1,
    ) as unknown as T;
  };
}
