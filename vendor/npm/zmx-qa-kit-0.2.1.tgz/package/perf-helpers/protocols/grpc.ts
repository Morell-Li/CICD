/**
 * gRPC helper — unary 调用通用 wrapper。
 *
 * 覆盖：proto 加载（init 上下文一次）、连接复用、metadata 注入 trace id 与 scenario tag、
 * 显式 int64 字段 stringify、QA_K6_DEBUG 标准调试。
 * 不覆盖：streaming（k6 client-streaming / bidi-streaming 支持有限，业务场景需要时
 * 走 ghz 或自研 runner，不归 qa-kit 压测基建管）。
 *
 * 业务中性：不认识任何 service。业务仓提供 .proto 路径 + 服务方法名。
 *
 * k6 protobuf-js 行为提示（仅文档，本 helper 不做隐式转换）：
 *   - response 字段会被 k6 内部转成 lowerCamelCase（proto `error_code` → `errorCode`）
 *   - 64 位整型字段（int64 / uint64 / sint64）必须以 string 形式发送，否则 JS Number
 *     精度会损坏大值。请通过 `int64Fields` 显式列出，或 `int64Suffix` 提供后缀集合。
 *     默认行为：不做任何字段转换。
 */

import grpc from 'k6/net/grpc';

import { scenarioTags } from '../tags.ts';
import { traceId } from '../correlation.ts';
import { k6DebugLog } from '../debug.ts';
import { buildInt64Transformer } from './grpc-int64.ts';

export interface GrpcClientOptions {
  /** proto import 路径集合（k6/net/grpc `load`）。 */
  readonly importPaths?: readonly string[];
  /** proto 文件名列表，相对 importPaths 解析。 */
  readonly protoFiles?: readonly string[];
  /** 目标 host:port，如 "svc.local:9090"。 */
  readonly address: string;
  /** 是否 plaintext（默认 false，即 TLS）。 */
  readonly plaintext?: boolean;
  /** 默认附加 metadata（trace id / scenario 会自动合入；invoke 级 metadata 会覆盖）。 */
  readonly metadata?: Record<string, string>;
  /**
   * 显式列出需要 String() 化的请求字段名（int64 / uint64 / sint64 字段）。
   * 优先级高于 `int64Suffix`。空 / 未设 = 不做转换。
   */
  readonly int64Fields?: readonly string[];
  /**
   * 用户自定义后缀集合，请求字段名 endsWith 任一时 String() 化。
   * 空 / 未设 = 不做转换。本 helper 不预置任何启发式（如 `*Id` 后缀）。
   */
  readonly int64Suffix?: readonly string[];
}

export interface GrpcInvokeOptions {
  /** 附加业务 tag（不必包含 scenario，会自动注入）。 */
  readonly bizTags?: Record<string, string>;
  /**
   * gRPC 调用超时，如 "3s"、"500ms"。**仅在显式给出时**透传给 k6；
   * 传 `undefined` 不会出现在 k6 invoke params 中（避免 `nil duration value` 错误）。
   */
  readonly timeout?: string;
  /** 单次调用级 metadata（与 client 级合并，单次值覆盖 client 级）。 */
  readonly metadata?: Record<string, string>;
}

export interface GrpcInvokeResult<TResp> {
  readonly status: number;
  readonly message?: TResp;
  readonly error?: unknown;
}

export interface GrpcClient {
  invoke<TReq, TResp = unknown>(
    method: string,
    req: TReq,
    opts?: GrpcInvokeOptions,
  ): GrpcInvokeResult<TResp>;
  close(): void;
}

/**
 * 创建一个 gRPC client。proto 加载发生在 init 上下文（VU 外），连接在每个 VU 首次
 * 调用时建立并复用（k6/net/grpc 内部按 VU 管连接）。
 */
export function defineGrpcClient(opts: GrpcClientOptions): GrpcClient {
  const client = new grpc.Client();
  const protoFiles = opts.protoFiles ?? [];
  if (protoFiles.length > 0) {
    client.load(opts.importPaths ?? [], ...protoFiles);
  }

  const transformReq = buildInt64Transformer({
    int64Fields: opts.int64Fields,
    int64Suffix: opts.int64Suffix,
  });

  let connected = false;

  function ensureConnected(): void {
    if (connected) return;
    client.connect(opts.address, { plaintext: opts.plaintext ?? false });
    connected = true;
  }

  return {
    invoke<TReq, TResp = unknown>(
      method: string,
      req: TReq,
      callOpts?: GrpcInvokeOptions,
    ): GrpcInvokeResult<TResp> {
      ensureConnected();
      const tags = scenarioTags(callOpts?.bizTags);
      const metadata: Record<string, string> = {
        'x-qa-trace-id': traceId(),
        ...(opts.metadata ?? {}),
        ...(callOpts?.metadata ?? {}),
      };
      const safeReq = transformReq(req);
      const invokeParams: Record<string, unknown> = { metadata, tags };
      if (callOpts?.timeout !== undefined) {
        invokeParams.timeout = callOpts.timeout;
      }
      const res = client.invoke(method, safeReq as object, invokeParams);
      const result: GrpcInvokeResult<TResp> = {
        status: res.status,
        message: (res.message ?? undefined) as TResp | undefined,
        error: res.error,
      };
      k6DebugLog('grpc-debug', {
        method,
        req: safeReq,
        status: result.status,
        message: result.message,
        error: result.error,
      });
      return result;
    },
    close(): void {
      if (connected) {
        client.close();
        connected = false;
      }
    },
  };
}
