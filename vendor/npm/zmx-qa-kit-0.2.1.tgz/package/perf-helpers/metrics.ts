/**
 * Custom metrics helpers — 按 perf-spec.custom_metrics 声明注册一次。
 *
 * qa-kit analyzePerf 消费 summary.json 时会根据 perf-spec.custom_metrics 找到
 * 这些指标并纳入判定。helper 保证 k6 Metric 构造只发生在 init 上下文一次
 * （多次构造同名 metric 会被 k6 警告且数据不可靠）。
 */

import { Counter, Gauge, Rate, Trend } from 'k6/metrics';

export interface CustomMetricSpec {
  readonly name: string;
  readonly type: 'trend' | 'counter' | 'gauge' | 'rate';
  readonly isTime?: boolean; // Trend 可选：声明为时间指标（ms）
}

type AnyMetric =
  | InstanceType<typeof Trend>
  | InstanceType<typeof Counter>
  | InstanceType<typeof Gauge>
  | InstanceType<typeof Rate>;

const registry = new Map<string, AnyMetric>();

/** 注册一批自定义指标；重复注册返回同一 instance。 */
export function registerMetrics(specs: readonly CustomMetricSpec[]): void {
  for (const s of specs) {
    if (registry.has(s.name)) continue;
    let m: AnyMetric;
    switch (s.type) {
      case 'trend':
        m = new Trend(s.name, s.isTime ?? false);
        break;
      case 'counter':
        m = new Counter(s.name);
        break;
      case 'gauge':
        m = new Gauge(s.name);
        break;
      case 'rate':
        m = new Rate(s.name);
        break;
    }
    registry.set(s.name, m);
  }
}

export function metric(name: string): AnyMetric {
  const m = registry.get(name);
  if (!m) {
    throw new Error(
      `metric "${name}" not registered — call registerMetrics() in init context first`,
    );
  }
  return m;
}
