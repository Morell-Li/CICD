/**
 * @qa-perf/* — 压测脚本共享 helper。
 *
 * 业务仓在 scenario 脚本里 `import { ... } from '@qa-perf/...'`。所有 helper
 * 业务中性，由 qa-kit init 拷贝进本 lib 目录。
 *
 * ⚠️ 升级路径：qa-kit 发布新版本后，重跑 `qa-kit init --merge --force` 会把
 * 此目录下的 helper 拉到新版本；业务自定义的 helper 请单独放子目录避免覆盖。
 */

export * from './thinkTime.ts';
export * from './tags.ts';
export * from './correlation.ts';
export * from './pool.ts';
export * from './token-pool.ts';
export * from './metrics.ts';
export * from './debug.ts';
export * as http from './protocols/http.ts';
export * as grpc from './protocols/grpc.ts';
