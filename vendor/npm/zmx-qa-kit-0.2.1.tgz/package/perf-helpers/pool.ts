/**
 * Data pool helper — 读取业务仓 fixture 文件，按策略分发给 VU。
 *
 * 业务中性：pool "里"装什么（账号/订单/任意 id）由业务仓自己决定。helper 只负责：
 *   - 文件加载（SharedArray 内存单例，不重复 parse）
 *   - 按 VU 分片（exclusive：每 VU 独占一块）或共享采样（shared：随机挑）
 *   - on_exhaust 策略（exclusive 模式下若 VU 数超过池子大小）
 *
 * P0 仅支持 source=file（JSON 数组）。sql/api 走 pre_flight hook 物化成 file 即可。
 */

import exec from 'k6/execution';
import { SharedArray } from 'k6/data';

export type PoolStrategy = 'exclusive' | 'shared';
export type OnExhaust = 'skip' | 'fail';

interface PoolOptions<T> {
  /** 池名（和 perf-spec.data_pools[].name 对齐，用于日志）。 */
  readonly name: string;
  /** 相对 scenario 脚本的 JSON 文件路径（必须是数组）。 */
  readonly filePath: string;
  readonly strategy?: PoolStrategy;
  readonly onExhaust?: OnExhaust;
  /** 可选 transform：每条记录反序列化后的加工。 */
  readonly transform?: (raw: unknown) => T;
}

export interface Pool<T> {
  /**
   * 为当前 VU × iter 返回一条记录。
   * - exclusive：VU idx % poolSize
   * - shared：每次随机
   * Exhaust 时按 onExhaust 返回 null（skip）或抛（fail）。
   */
  acquire(): T | null;
  size(): number;
}

export function definePool<T = unknown>(opts: PoolOptions<T>): Pool<T> {
  const strategy: PoolStrategy = opts.strategy ?? 'exclusive';
  const onExhaust: OnExhaust = opts.onExhaust ?? 'fail';

  // SharedArray: 所有 VU 共用内存里的一份解析结果，不 per-VU 重复解析。
  const records = new SharedArray<T>(`qa-pool-${opts.name}`, () => {
    // k6 的 SharedArray 在 init 上下文里跑；open() 从 cwd 相对读文件。
    // 业务侧 scenario 脚本和 fixture 在同一仓，相对路径稳定。
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const open = (globalThis as { open: (p: string) => string }).open;
    const raw = JSON.parse(open(opts.filePath)) as unknown;
    if (!Array.isArray(raw)) {
      throw new Error(`pool "${opts.name}" file ${opts.filePath} is not a JSON array`);
    }
    return opts.transform ? raw.map(opts.transform) : (raw as T[]);
  });

  return {
    size() {
      return records.length;
    },
    acquire() {
      const total = records.length;
      if (total === 0) {
        if (onExhaust === 'fail') {
          throw new Error(`pool "${opts.name}" is empty`);
        }
        return null;
      }
      if (strategy === 'shared') {
        return records[Math.floor(Math.random() * total)];
      }
      // exclusive: VU idx 映射到池索引
      const vuIdx = exec.vu.idInTest - 1; // idInTest is 1-based
      if (vuIdx >= total && onExhaust === 'fail') {
        throw new Error(
          `pool "${opts.name}" exhausted (VU=${vuIdx + 1} > poolSize=${total})`,
        );
      }
      if (vuIdx >= total && onExhaust === 'skip') {
        return null;
      }
      return records[vuIdx % total];
    },
  };
}
