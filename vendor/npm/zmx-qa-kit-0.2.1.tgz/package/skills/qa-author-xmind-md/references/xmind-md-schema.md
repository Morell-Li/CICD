# xmind.md schema (case.md → XMind tree-shaped markdown intermediate)

> Machine-readable definition. LLMs align to this file; downstream external tool `xmindmd` also parses per this file. Full sample: `xmind-md-golden-template.md`.

## 1. File-Level Overview

```text
# {项目}｜{模块} 测试脑图            ← root node, unique top heading

- 需求分析                           ← second-level branch 1
  - C 端（用户端）
    - 前端部分
      - ...
    - 后端部分
      - 业务逻辑
      - 接口信息
  - B 端（管理后台）
  - 纯后端
  - 文档不清楚或缺失的内容
- 测试用例                           ← second-level branch 2
  - 时间轴                           ← optional
  - C端
    - 前端功能交互测试
      - 页面UI整体走查
      - {用例标题} [TC-xxx]
    - 后端业务逻辑测试
      - {用例标题} [TC-xxx]
      - 接口描述：METHOD /path
        - 请求方式 [TC-300]
        - 登录态 [TC-301]
        - ...（10 leaves）
  - B端
    - 前端功能交互测试
    - 后端业务逻辑测试
```

## 2. Hard Constraints

- Root is **unique**: `# {项目}｜{模块} 测试脑图`; NEVER a second `#` top heading
- Every node except the root uses markdown unordered-list `-`, indented 2 spaces per level
- NO intermediate `##` / `###` headings (xmindmd does not recognize mixed hierarchy)
- NO markdown tables, code blocks, images, frontmatter
- NO HTML comments (TC-NNN does NOT use `<!-- -->`; it uses the `[TC-xxx]` bracket trailing tag)

## 3. Node Syntax

### 3.1 Plain Node

```
- {节点文字}
```

Plain-text node; no TC association. Used for mid-level hierarchy nodes (e.g. `C端`, `前端功能交互测试`) and leaves without TC (`页面UI整体走查`, timeline entries).

### 3.2 Leaf with TC Trailing Tag

```
- {用例标题} [TC-xxx]
```

- Brackets sit tight after the title, with exactly **one space** before them
- `TC-xxx` digit width matches case.md frontmatter `idWidth` (3 or 4 digits)
- The xmindmd tool parses `[TC-xxx]` into node label / note

### 3.3 Interface Contract Block

```
- 接口描述：POST /order/cancel
  - 请求方式 [TC-300]
  - 登录态 [TC-301]
  - 请求体 [TC-302]
  - 预期状态码 [TC-303]
  - 预期响应 [TC-304]
  - 必填参数缺失验证 [TC-305]
  - 错误码验证 [TC-306]
  - 边界条件验证 [TC-307]
  - 未登录状态验证 [TC-308]
  - 异常展示验证 [TC-309]
```

10 sub-leaves flat, no further drilling; names exact, matching case.md schema §5.4.

### 3.4 Placeholder Case

```
- （占位）本模块无 B 端 前端功能
```

Keep the hierarchy shell; `（占位）` prefix uses fullwidth parens, so humans can grep-and-prune in the xmind view.

### 3.5 Timeline

```
- 时间轴
  - T0 订单创建，状态 active
  - T0+24h 未支付订单被 orderCloseJob 置为 closed
  - 用户主动取消：T0~T0+24h 内任意时点
```

Timeline node has no TC; each entry is a plain sub-item.

## 4. TC-NNN Parsing Rules

- Regex: `/\[TC-(\d{3,4})\]$/` (line end)
- One-to-one mapping with case.md TC-NNN; NEVER add, NEVER omit
- In multi-end / multi-module scenarios, TC uniqueness is guaranteed by upstream case.md; xmind.md does NOT do ID-conflict checks

## 5. Hard Prohibitions

- NEVER `<!-- id:TC-xxx | 分类:... -->` (HTML comment syntax is case.md-only)
- NEVER `【原文 L…】` anchors
- NEVER priority markers like `P0 / P1 / [高]` (matches case.md prohibition)
- NEVER embed metadata beyond case.md frontmatter (Jira ID / PM names etc.)
- NEVER duplicate case.md leaf content (前置 / 步骤 / 预期) in xmind.md; xmind keeps only title hierarchy

## 6. Anti-Pattern Table

| ❌ Wrong | ✅ Correct |
|---|---|
| `## 需求分析` | `- 需求分析` (no `##` at top) |
| `- TC-001 取消订单` | `- 取消订单 [TC-001]` |
| `- [TC-001]取消订单` | `- 取消订单 [TC-001]` |
| `- 取消订单 (TC-001)` | `- 取消订单 [TC-001]` |
| Interface contract with only 5 points | 10 points flat, full coverage |
| Delete placeholder node outright | Keep `- （占位）...` shell |
| Node body writes `前置条件: ...` | Keep only the title; leaf content stays in case.md |
