<!-- Golden template: all content below is verbatim Chinese artifact shape and MUST NOT be translated. -->

# xmind.md 黄金模板（order-cancel · 对照 case.md 黄金模板）

> **形状权威**。与 `../../qa-design-test-cases/references/module-golden-template.md` 的 order-cancel case.md 一一对应。LLM 起稿前读一遍做结构对齐。

---

## 输入 case.md 摘要（完整内容见上游模板）

```yaml
schemaVersion: '2.0'
project: 'order-system'
module: 'order-cancel'
feature: 'order-cancel'
```

TC 清单：TC-001 / TC-002 / TC-003 / TC-100 / TC-050 / TC-300~TC-309 / TC-004。

## 对应 xmind.md 完整产物

```markdown
# 订单系统｜订单取消 测试脑图

- 需求分析
  - C 端（用户端）
    - 前端部分
      - 页面/入口：订单列表页、订单详情页
      - 页面元素：订单卡片 / 详情页操作区 / 确认弹窗
      - 用户交互：点击取消订单 → 确认弹窗 → 调用取消接口
      - 展示规则：取消成功后状态标签变为已取消
      - 输入校验：无输入字段
      - 异常展示：500 时 Toast 系统繁忙
      - 弹窗清单：确认取消弹窗
    - 后端部分
      - 业务逻辑
        - 触发条件：C 端用户确认取消
        - 执行动作：校验归属 → 校验状态 → 更新 canceled → 触发退款
        - 数据变化：orders.status active → canceled；写审计表
      - 接口信息
        - POST /order/cancel
  - B 端（管理后台）
    - 前端部分
      - 页面/入口：订单管理页
      - 页面元素：列表表格 + 强制取消按钮
    - 后端部分
      - 业务逻辑
        - B 端强制取消复用 C 端接口，admin 角色放行
        - 写入 operator_id 到审计表
  - 纯后端
    - 业务逻辑
      - 定时任务 orderCloseJob：扫描未支付 > 24h 订单置 closed
  - 文档不清楚或缺失的内容
    - 退款到账时效：24 小时 SLA 还是硬性约束未明确
    - 部分退款场景未描述
    - reason 字段敏感词过滤未提及
    - B 端强制取消二次确认口径不一致
    - 跨时区订单时间判定口径未明确
- 测试用例
  - 时间轴
    - T0 订单创建，状态 active，24 小时倒计时
    - T0+24h 未支付订单被 orderCloseJob 置为 closed
    - 用户主动取消：T0~T0+24h 内任意时点
  - C端
    - 前端功能交互测试
      - 页面UI整体走查
      - 正常取消 active 状态订单 [TC-001]
      - 取消弹窗再想想按钮回退 [TC-002]
      - 重复点击确认取消幂等 [TC-003]
      - 订单 ID 长度 = 32（上界） [TC-100]
    - 后端业务逻辑测试
      - 24 小时未支付订单自动关闭 [TC-050]
      - 接口描述：POST /order/cancel
        - 请求方式 [TC-300]
        - 登录态 [TC-301]
        - 请求体 [TC-302]
        - 预期状态码 [TC-303]
        - 预期响应 [TC-304]
        - 必填参数缺失验证 [TC-305]
        - 错误码验证 [TC-306]
        - 边界条件验证 [TC-307]
        - 未登录状态验证 [TC-308]
        - 异常展示验证 [TC-309]
  - B端
    - 前端功能交互测试
      - （占位）本模块 B 端前端功能仅限 admin 角色强制取消按钮
    - 后端业务逻辑测试
      - admin 角色强制取消他人订单 [TC-004]
```

---

## 模板使用说明

### 覆盖的转换形态

| case.md 形态 | xmind.md 位置 |
|---|---|
| frontmatter project / module 组根 | 第 1 行根节点 |
| 上段需求分析 C/B/纯后端 | `- 需求分析` 分支完整镜像 |
| 上段 `## ⚠️` 必选节 | `- 文档不清楚或缺失的内容` 叶子 |
| `### 时间轴` | `- 时间轴` 分支 + 3 条无 TC 子项 |
| 普通三行用例（TC-001 等） | `- 标题 [TC-xxx]` 单行叶子 |
| 边界值用例（TC-100） | 同上，TC-NNN 段号保留 |
| 触发方式代步骤用例（TC-050） | 同上 |
| 接口 10 点契约块 | 父节点 `接口描述：...` + 10 个平铺子叶 |
| 占位用例 | `- （占位）...` 前缀 |
| B 端真实用例（TC-004） | `B端 → 后端业务逻辑测试` 下常规叶子 |

### 起稿步骤

1. Read case.md，抽 frontmatter + 全部 TC-NNN
2. 写根节点 `# {project}｜{module} 测试脑图`
3. 镜像上段结构到 `- 需求分析` 分支（层级名对齐 schema §1 表）
4. 镜像下段结构到 `- 测试用例` 分支
5. 每个 `#####` / `######` 标题转一条 `- ...`，有 TC 注释的追加 `[TC-xxx]`
6. 跑 SKILL.md 自检清单

### 不在本模板但允许

- 纯后端节存在时对应 `- 纯后端` 分支保留；无则可省
- `idWidth: 4` 对应 `[TC-NNNN]`（方括号内位数跟随 case.md frontmatter）
- 多模块 case 拆多文件时，每模块独立 xmind.md，各自唯一根

### 即使模板里没示例也不允许

- 在 xmind.md 里重复写 case.md 的 `前置 / 步骤 / 预期` 三行叶子内容
- 在节点里嵌 `<!-- TBD -->` 或 `【原文 L…】` 锚点
- 把接口 10 点合并成一个叶子（如 `- 接口契约全套 [TC-300~309]`）
- 给 `页面UI整体走查` 硬塞一个 TC
