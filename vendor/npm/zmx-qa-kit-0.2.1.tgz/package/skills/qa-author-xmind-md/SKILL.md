---
name: qa-author-xmind-md
description: Convert a finalized case.md into an xmind-ready tree-shaped markdown (xmind.md) for downstream xmindmd tool conversion. Flattens v5 four-grid structure into XMind node tree, preserving TC-NNN labels as node annotations for bidirectional traceability. Use when user runs /qa:author-xmind, asks "转 xmind", "生成 xmind.md", or "案例定稿后出脑图". case.md → xmind.md 树形转换 / 保留 TC-NNN 双向溯源.
priority: 30
allowed-tools: "Read Write"
metadata:
  preset: test-case-design
  category: qa-authoring
---

# qa-author-xmind-md — case.md → xmind.md tree conversion

## Responsibility

Flatten a finalized `case.md` (v2.0 four-grid + engineering labels) into a **tree-shaped markdown** (`xmind.md`) for the downstream external tool `xmindmd` to convert into an actual `.xmind` file. The artifact preserves TC-NNN as the node trailing tag `[TC-xxx]`, enabling case ↔ xmind bidirectional traceability.

## When to Use

- User runs `/qa:author-xmind <case.md>`, or says "转 xmind" / "生成 xmind.md" / "案例定稿后出脑图"
- Before review meeting, produce a mind-map view with requirements-analysis + test-cases flattened by reading hierarchy
- case.md updated, re-export a synced mind map

**Do NOT use for**:

- Generating `.xmind` binaries directly (that's the external `xmindmd` tool's job; this skill only emits the intermediate md)
- Drafting TC from zero (that's `qa-design-test-cases`)
- Coverage review (that's `qa-review-coverage`)

## Input Contract

```ts
type AuthorXmindInput = {
  caseMdPath: string;        // qa-design/cases/<feature>.md（扁平，单模块）
                             // 或 qa-design/cases/<feature>/{module}.md（嵌套，多模块）
  outputPath?: string;       // 默认：同目录 + 同基名 + .xmind.md 后缀
                             //   qa-design/cases/trade-area.md     → qa-design/cases/trade-area.xmind.md
                             //   qa-design/cases/login/buyer.md   → qa-design/cases/login/buyer.xmind.md
};
```

## Output Contract

- Single file `{同名基名}.xmind.md`（同目录下紧贴源文件，便于文件树区分；绝不产出含混的 `xmind.md`）
- Unique root: `# {项目}｜{模块} 测试脑图`
- Each test-case leaf format: `- {标题} [TC-xxx]` (TC-xxx is a bracketed trailing tag; xmindmd parses it into node label/note)
- Interface 10-point contract flattens to 10 leaves, each keeping its TC-NNN
- Schema / node syntax definition: `references/xmind-md-schema.md`
- Full sample: `references/xmind-md-golden-template.md`

## Steps (rubric)

### 1. Read case.md

Read `caseMdPath` and extract:

- frontmatter (pull `project` / `module` for root heading)
- all `#####` / `######` headings + same-line HTML comment trailing tag (`<!-- id:TC-xxx | 分类:X | 维度:k=v -->`)
- Two-section boundary: upper requirements analysis + `---` + lower test cases

### 2. Establish Root Node

`# {frontmatter.project}｜{frontmatter.module} 测试脑图`. Single module = single root; when multi-module case splits into files, each xmind.md has its own unique root.

### 3. Rebuild Tree by Natural Reading Hierarchy

Trunk order (matches case.md, do NOT invent):

```text
# {项目}｜{模块} 测试脑图
├── - 需求分析
│   ├── - C 端（用户端）
│   │   ├── - 前端部分
│   │   └── - 后端部分
│   │       ├── - 业务逻辑
│   │       └── - 接口信息
│   ├── - B 端（管理后台）
│   ├── - 纯后端
│   └── - 文档不清楚或缺失的内容
└── - 测试用例
    ├── - 时间轴              ← optional
    ├── - C端
    │   ├── - 前端功能交互测试
    │   │   ├── - 页面UI整体走查
    │   │   └── - {用例标题} [TC-xxx]
    │   └── - 后端业务逻辑测试
    │       ├── - {用例标题} [TC-xxx]
    │       └── - 接口描述：POST /xxx
    │           ├── - 请求方式 [TC-300]
    │           ├── - 登录态 [TC-301]
    │           └── ...（10 leaves）
    └── - B端
        ├── - 前端功能交互测试
        └── - 后端业务逻辑测试
```

### 4. Leaf Node Format

- Normal case: `- {中文标题} [TC-xxx]`
- Interface 10-point contract: `- {契约点名称} [TC-3xx]` (10 flat, no further sub-drilling)
- Nodes without TC-NNN (e.g. `页面UI整体走查` / placeholder cases): `- {标题}`, no bracket suffix
- Timeline 3 entries: verbatim as non-TC leaves `- T0 订单创建...`
- TBD comments / 【原文 L…】 anchors are NOT preserved in xmind (noise for mind-map; they stay in case.md proper)

### 5. Placeholder Cases

`##### （本模块无 X 端 Y 功能）` → `- （占位）{省略的功能描述}`. The hierarchy shell is kept, but the node gets the `(占位)` prefix so reviewers can quickly prune it from the xmind view.

### 6. Empty Dimensions / Empty Classes

When a case.md leaf has only `id` without `维度` or `分类`, xmind does NOT add a node and does NOT add filler text; preserve tree information density.

### 7. Write

Write to `outputPath`。默认：**紧挨源文件同目录 + 同基名 + `.xmind.md` 后缀**：
- `qa-design/cases/trade-area.md` → `qa-design/cases/trade-area.xmind.md`
- `qa-design/cases/login/buyer.md` → `qa-design/cases/login/buyer.xmind.md`

原子覆盖；不保留旧内容。**不要写成统一的 `xmind.md`** —— 多个 feature 平铺时无法区分。

## Conversion Quick-Reference Table

| case.md node | xmind.md node |
|---|---|
| frontmatter `project` + `module` | Root `# {project}｜{module} 测试脑图` |
| Upper `## {模块}` | `- 需求分析` branch |
| Upper `### C 端（用户端）` | `- C 端（用户端）` |
| Upper `#### 前端部分` / `#### 后端部分` | same-named leaves |
| Upper `##### 业务逻辑` / `##### 接口信息` | same-named leaves |
| Upper `## ⚠️ 文档中不清楚或缺失的内容` | `- 文档不清楚或缺失的内容` |
| `---` separator | switch to `- 测试用例` main branch |
| Lower `## {模块}` | (absorbed under "测试用例", do NOT duplicate hierarchy) |
| `### 时间轴` | `- 时间轴` + unordered list children |
| `### C端` / `### B端` | `- C端` / `- B端` |
| `#### 前端功能交互测试` / `#### 后端业务逻辑测试` | same-named leaves |
| `##### 用例标题 <!-- id:TC-xxx ... -->` | `- 用例标题 [TC-xxx]` |
| `##### 页面UI整体走查` | `- 页面UI整体走查` (no TC) |
| `##### 接口描述：METHOD /path` | `- 接口描述：METHOD /path` |
| `###### 请求方式 <!-- id:TC-300 -->` | `- 请求方式 [TC-300]` |
| `##### （本模块无 X 端 Y 功能）` | `- （占位）...` |

## Human + AI Touch-Up Points

This skill produces an **AI draft**, not a mechanical final version. After delivery, a human should:

- Merge overly granular adjacent leaves (e.g. multiple interfaces' `请求方式 [TC-3x0]` may be selectively trimmed)
- Depending on the mind-map audience (review meeting vs archive), decide whether to keep placeholder branches
- Add xmind-native visual annotations (icons / priority markers) — these are downstream xmindmd concerns

## Self-Check (LLM runs before delivery)

- [ ] Root unique, format `# {project}｜{module} 测试脑图`
- [ ] Every TC-NNN in case.md is retrievable in xmind.md (`grep -o 'TC-[0-9]\+'` counts match on both sides)
- [ ] `[TC-xxx]` bracket sits tight after the title, exactly one space before it, no stray whitespace
- [ ] Trunk order matches case.md (需求分析 → 测试用例; C端 → B端; frontend → backend)
- [ ] All 10 interface contract points preserved, no merging, no renaming
- [ ] Hierarchy uses markdown unordered-list indentation (uniform 2 spaces or tab)
- [ ] No markdown tables / code blocks / images
- [ ] No `【原文 L…】` anchors / `<!-- TBD:#X -->` comments leaked into xmind

## Fallback Protocol

- Phase 1: LLM reads case.md and writes xmind.md directly, no MCP tool dependency
- No parser invocation; LLM aligns manually per this SKILL's rubric + schema
- Phase 2: once `qa.authorXmindMd` MCP tool plugs in the case-md parser, switch back to the programmatic path; this rubric remains as LLM fallback

## Division of Labor

- This skill only emits the `xmind.md` intermediate; `.xmind` binary is produced by external `xmindmd` tool, out of qa-kit scope
- xmind.md itself has no schema gate (structural rules live in this SKILL rubric + `references/xmind-md-schema.md`); if the xmindmd tool side fails to parse, reverse-check xmind.md and hand-fix

## Cross References

- `references/xmind-md-schema.md` — authoritative xmind.md structure / syntax definition
- `references/xmind-md-golden-template.md` — full conversion example aligned to case.md golden template
- `../qa-design-test-cases/references/test-case-schema.md` — upstream case.md schema
- `../qa-design-test-cases/references/module-golden-template.md` — upstream case.md golden template
- `../../rules/qa-html-tag-contract.md` — HTML comment trailing-tag contract (basis for TC-NNN extraction)
- `../../rules/qa-no-fabrication.md` — anti-fabrication: xmind nodes come strictly from case.md, never add content
