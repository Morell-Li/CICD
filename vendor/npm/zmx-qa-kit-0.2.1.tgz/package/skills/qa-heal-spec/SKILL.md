---
name: qa-heal-spec
description: Given a FailureSignal + spec.ts + trace summary, render a class-specific heal prompt that guides an IDE LLM to propose a patch. Invoked by qa.heal MCP tool per failureClass (selector-drift / assertion-mismatch / network-flake / data-race / env); real-bug / unknown go to handoff card instead.
priority: 15
allowed-tools: "Bash(qa-kit:*) Read"
metadata:
  preset: web-e2e
  ownerTool: qa.heal
  category: qa-heal-spec
---

# qa-heal-spec — 按 failureClass 渲染 heal prompt

## 职责

Healer 闭环的 **prompt 渲染侧**。输入 `{ FailureSignal, specTs, traceSummary }`，按 `FailureSignal.class` 加载对应模板（`references/heal-prompt-<class>.md`），产出"给 IDE LLM 的 propose 指令"（**不是 patch 本身**，是让 LLM 在自己的回合生成 patch 的输入）。

## 何时使用

- `qa.heal` MCP tool **内部**调用（LLM 不直接触发本 skill）
- `/qa:heal` 入口后，分类器判出非 `real-bug` / 非 `unknown` 类时
- Healer 重试循环中 propose 失败，重新渲染 prompt

**不用于**：
- `real-bug` / `unknown` → 走 `references/handoff-card-real-bug.md` 转交卡（不渲染 heal prompt）
- 压测 / 设计类 preset（类型 2 / 3 不挂 Heal）

## 输入

```ts
type HealPromptInput = {
  signal: FailureSignal;          // 来自 qa-explain-failure
  specTs: string;                 // 失败 spec.ts 文件内容
  traceSummary: {
    failedStep: string;
    selector?: string;
    expected?: unknown;
    actual?: unknown;
    networkEvents?: string[];
    stderr?: string[];
  };
  relatedPO?: string[];           // 相关 PageObject 源码片段
};
```

## 输出

```ts
type HealPrompt = {
  class: FailureSignal['class'];
  systemHint: string;             // 给 LLM 的角色 / 边界提示
  task: string;                   // 具体修改任务(含约束)
  evidence: string;               // 可读的失败证据摘要
  constraints: string[];          // 硬约束(不要改 annotation / 不要删 TC / 等)
  verifySteps: string[];          // LLM 自验步骤(tsc + playwright --list)
};
```

## 操作步骤（rubric）

1. **按 class 路由**：
   - `selector-drift` → `references/heal-prompt-selector-drift.md`
   - `assertion-mismatch` → `references/heal-prompt-assertion-mismatch.md`
   - `network-flake` → `references/heal-prompt-network-flake.md`
   - `data-race` → `references/heal-prompt-data-race.md`
   - `env` → `references/heal-prompt-env.md`
   - `real-bug` / `unknown` → **不渲染 heal**；走 `references/handoff-card-real-bug.md` 生成转交卡
2. **读模板 + 注入上下文**：把 `signal.evidence` / `traceSummary` 对应字段填入模板变量（`{{selector}}` / `{{expected}}` / `{{actual}}`）。
3. **约束必填**：每个模板都带"不允许改的内容" — annotation 元数据 / dataCleaner 声明 / jira 字段 / test 标题。LLM patch 尝试改动这些 = 程序化拒绝。
4. **verifySteps 固定**：`tsc --noEmit` + `playwright test --list`；Verify 由 `qa.applyHealDiff` 程序化执行，LLM 不自验。
5. **unknown / real-bug 路径**：本 skill 退化为 handoff-card 渲染器；输出包含 trace 引用 + failureClass + confidence + 复现步骤模板；不包含 patch 指令。
6. **阈值不满足**：`confidence < classThreshold` 时直接退化为 handoff-card（即使 class ≠ real-bug / unknown）。阈值源：`.zmx-tools-config.json#qaKit.failureClass.thresholds`。
7. **Playwright MCP live-probe（patch 生成前）**：若 `mcp__playwright__*` 工具可用，且 `class ∈ {selector-drift, assertion-mismatch}`，模板应指导下游 LLM **先调浏览器再改代码**：
   - `browser_navigate(<失败页面 URL>)` 打开真实页面（用 `traceSummary` 里记录的 URL，或从 spec.ts 推断）
   - `browser_snapshot()` 读取实际 DOM，拿到真实可见的 role / accessible name / 结构
   - 对比 `traceSummary.selector`（老选择器）和 snapshot 里观察到的结构，给出替换依据
   - 禁止"凭 trace 文本猜新 selector"；猜的选择器会在下一轮跑测再失败，浪费一轮 heal 配额
   - `network-flake` / `data-race` / `env` 不强制 live-probe（失败本身和 DOM 无关）

## 分工提醒

- **LLM 不判 class**（ADR-021 D2）：分类走 `qa-explain-failure`；本 skill 是"按已有 class 路由模板"的**程序化**动作。
- prompt 模板**随 qa-kit 包版本发布**（`docs/ai-workflow/prompt-index.md` §真源），docs 不复写正文。
- `scripts/render.ts`（模板字符串注入 + 上下文裁剪）**P0 后续 wave 实施**；当前 SKILL.md 锁定契约 + 模板集合。

## 交叉引用

- `docs/ai-workflow/failure-class.md` §Healer 按 class 程序化渲染 prompt
- `docs/ai-workflow/prompt-index.md` §类型 1
- `docs/ai-workflow/components-architecture.md` §4 Healer 闭环
- `rules/qa-failure-class.md`
- `references/heal-prompt-*.md`（5 份 per-class）+ `references/handoff-card-real-bug.md`
