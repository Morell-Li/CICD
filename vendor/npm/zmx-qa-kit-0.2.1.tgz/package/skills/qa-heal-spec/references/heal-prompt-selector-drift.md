# heal-prompt: selector-drift

## systemHint（模板）

> 你是 Playwright 测试的 selector 维护者。当前一条用例因 DOM 结构变化导致 locator 失效。你**只能修 PageObject 或 spec 内的 selector 表达**，**不得**改 annotation、test 标题、断言语义、dataCleaner 配置。

## task（填槽后发给 LLM）

- 失败 selector：`{{selector}}`
- 失败 step：`{{failedStep}}`
- PO 片段（若涉及）：`{{relatedPO}}`
- 目标：用 `getByRole` / `getByTestId` / `getByLabel` 替换当前失败 selector；若目标元素的 `data-testid` 缺失，在 patch 里**留 TODO 注释**提醒前端补 testid，不要用 XPath / 长 CSS 链兜底。

## evidence 注入

```
failedStep: {{failedStep}}
selector:   {{selector}}
trace:      {{traceLink}}
```

## 硬约束

- NEVER 改 `test('...', { annotation: [...] }, ...)` 的 annotation 数组
- NEVER 改 test 标题（影响 Jira 对齐）
- NEVER 用 `nth-child` / `:has-text('业务文案')` 做唯一定位（`qa-runner-web` 红线）
- NEVER `waitForTimeout(<固定毫秒>)` 掩盖定位不稳
- 优先改 `tests/po/<Feature>Page.ts` 的 locator 定义，而不是 spec.ts 内联
- 单文件修改（不跨 feature 改 PO）

## 优先级选择器顺序

1. `getByRole('button', { name: '限价买入' })`
2. `getByTestId('limit-buy-submit')`
3. `getByLabel(...)` / `getByPlaceholder(...)`
4. `locator('[data-role="..."]')` — 最后兜底

## verifySteps（供 qa.applyHealDiff 跑）

1. `tsc --noEmit`
2. `playwright test --list` 包含目标 spec
3. `playwright test <spec>` 通过（按 class 重试阈值由 MCP 侧决定）

## 低置信度退化

当 `signal.confidence < 0.75`（selector-drift 阈值）时本模板**不发**；改走 handoff-card-real-bug 让人审判定是否真 drift。

## 样例输出骨架（LLM 应遵循）

```diff
 // tests/po/OrderPanel.ts
-  readonly cancelBtn = this.page.locator('.order-row > button.cancel');
+  readonly cancelBtn = this.page.getByRole('button', { name: '取消' });
```

patch diff 最多 20 行；超过说明 drift 太大，应转 handoff。
