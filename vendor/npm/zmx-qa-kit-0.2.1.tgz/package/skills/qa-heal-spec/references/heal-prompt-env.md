# heal-prompt: env

## systemHint

> 当前失败是环境问题（storageState 过期 / 目标服务不可达 / feature flag / 版本不一致）。**不改 spec**；输出 **env diff + 修复步骤清单**，交给运维 / SRE 处理。

## task

本模板**不产出 spec 代码 patch**，只产出：

1. env diff（before / after 对比）
2. 健康检查结论（目标服务是否可达）
3. 修复 checklist（按谁负责列）
4. 建议的 owner 渠道（#ops / #sre Lark 群）

## 判断矩阵

| 现象 | 修复路径 |
|---|---|
| storageState 过期 / cookie 失效 | 通知账号池 maintainer 重登账号；或等 `qa-kit accounts refresh` |
| 目标服务 healthcheck 失败 | 通知 SRE；暂挂用例 `@quarantine` |
| feature flag 差异 | 联系产品确认 flag 启用环境；不改 spec |
| 版本号 (`productVersion`) 不匹配 | 确认目标环境部署版本；annotation 不改 |

## 可以 patch 的改法

- **几乎没有**（env 类失败 = ops 问题）
- 例外：annotation 里 `runOn: ['staging']` 若明显与当前环境矛盾（如环境已下线），可建议改 `runOn` 或加 `test.skip(envMatch, ...)`，但**需人审 approve 后再 apply**。

## 硬约束

- NEVER 改业务断言 / PO 代码 / selector
- NEVER 假装是 flake 加 retry 兜底
- NEVER 删 annotation 的 `runOn` 来"让所有环境都跑过"
- 输出必须包含明确的 owner 建议（SRE / ops / 产品）

## evidence 注入

```
envDiff:
{{envDiff}}
healthcheck: {{healthcheck}}
storageStateAge: {{storageStateAge}}
```

## recommendedAction

固定为 `escalate`。渲染出 handoff-card 风格输出（轻量版）：

- 标题：`[env] <feature> - <简短原因>`
- env diff 表
- 建议 owner
- 是否需要临时 `@quarantine` 用例

## verifySteps

不适用（不产 patch 不跑 Verify Loop）。

## 退化

所有 env 类都走 escalate；本模板实际是 handoff-card 的 env 变体。
