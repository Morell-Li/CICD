# handoff-card: real-bug / unknown

当 `FailureSignal.class ∈ {real-bug, unknown}` 或 `confidence` 低于阈值时使用；**不渲染 heal prompt**，直接生成转交卡给业务 QA / 研发。

## 输出结构（固定顺序，便于复制到 Jira comment / Lark 消息）

```md
## [{{failureClass}}] {{feature}} — {{oneLineSummary}}

**影响版本**:{{productVersion}}
**failureClass**:{{failureClass}}(confidence={{confidence}})
**Jira**:{{jira}}（若 null 提示"待补录"）

### 复现步骤

{{reproSteps}}   <!-- 从 trace 提关键 3-5 步 -->

### 证据

- 失败 step:{{failedStep}}
- selector:{{selector}}
- expected / actual:{{expected}} vs {{actual}}
- trace.zip:{{traceLink}}
- Allure:{{allureLink}}
- 近期 spec.ts 变更:{{recentSpecDiff}}（若无则"无"）
- 近期相关业务代码变更:{{recentBizDiff}}（若无则"无"）

### 建议 Owner

{{ownerCandidate}}   <!-- P0 人工补;P1 走 CODEOWNERS 自动推断 -->

### 建议动作

- [ ] 业务 QA 复现确认
- [ ] 若复现 → 转研发修业务代码
- [ ] 若不复现 → 补测试隔离（`@quarantine`）+ 重审 classifier 阈值
```

## 字段填写规则

| 字段 | 来源 |
|---|---|
| `failureClass` | `FailureSignal.class` |
| `confidence` | `FailureSignal.confidence`（保留 2 位小数） |
| `oneLineSummary` | LLM 根据 evidence 写一句话（**必须**引用具体字段，不要"测试挂了"这种空话） |
| `reproSteps` | 从 trace.failedStep 向上追溯 3-5 步，每步一行 |
| `recentSpecDiff` | `git log -p -n 5 -- <spec.ts>` 摘要 |
| `recentBizDiff` | 由调用方注入（MCP 侧从 git log 抽 owner） |

## 渲染约束

- **不写 patch 建议**（real-bug / unknown 不走 heal）
- **不给"推荐动作三选一"**（那是 `qa-explain-failure` 的 confidence ≥ 阈值路径）
- 失败证据**必须可追溯**（每条带 `source: trace:step-N` / `log:line-N`）
- trace / Allure 链接缺失时保留占位 `TBD` + 注明"上传后补链"

## unknown 特殊处理

`unknown` 是 OOD 通道（`docs/ai-workflow/failure-class.md` §unknown 兜底）：

- `failureClass` 字段标 `unknown`
- `oneLineSummary` 必须写"当前信号不匹配 7 类任一"
- 单独追踪 `unknown` 占比（> 15% 时触发扩类 ADR 流程）；本 handoff 只管产卡
- `建议动作` 末尾加一条 `[ ] 若占比异常,本 case 归档到 classifier 标注集`

## 目标渠道

- P0:Lark bot webhook（`presets/web-e2e.md` 的 lark-webhook reporter）
- P1:Jira API 自动建 issue（`qa.exportHandoff` tool,后续 wave）
- 渲染本体**不关心渠道**,只产 markdown,分发由 reporter 负责
