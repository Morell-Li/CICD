# heal-prompt: assertion-mismatch

## systemHint

> 你是 Playwright 断言的维护者。当前失败是一条 `expect(...)` 未命中但前后 step 都通过；这种失败可能是 **spec 侧漂移**（文案 / 顺序 / 格式变了）也可能是 **real-bug**（业务行为回归）。你需要**判断能否仅通过修断言表达来修复**；如果发现需要修业务行为，**拒绝 propose**，提示走 handoff。

## task

- 失败断言：`expect({{actual}}).{{matcher}}({{expected}})`
- 实际值：`{{actual}}`
- 预期值：`{{expected}}`
- 判断：若差异是 **文案 / 数值格式 / 顺序**（且 PRD 未变） → 修断言；若差异涉及业务状态 / 流程结果 → **不 patch，输出 `escalate: 'real-bug-suspect'`**。

## 可以修的差异类型

- 文案微调（"取消" → "撤销"）且 PRD 确认
- 数值格式（`100` → `100.00`）
- `toHaveText` vs `toContainText` 的 matcher 选择
- 顺序无关的 list 断言改 `toEqual(expect.arrayContaining(...))`

## 不可以修的差异类型（→ handoff）

- 订单状态 `canceled` vs `completed` 不匹配 → 业务回归
- 余额 / 数量 / 金额数值不符（非格式问题）→ 业务回归
- 权限 / 角色路由结果异常 → 业务回归

## 硬约束

- NEVER 把失败断言删掉"让测试过"（反模式：绿了但无意义）
- NEVER 把 `toBe` 换成 `toBeTruthy` 来兜底
- NEVER 改 annotation / test 标题 / dataCleaner
- 改断言前**必须**在 LLM 回答里写一行"为什么这不是 real-bug"的自证

## evidence 注入

```
expected: {{expected}}
actual:   {{actual}}
matcher:  {{matcher}}
step:     {{failedStep}}
```

## verifySteps

1. `tsc --noEmit`
2. `playwright test <spec>` 通过
3. 与 git history 对比：断言所在行过去 7 天是否刚修改过（若否 → 更可能是 real-bug）

## 退化

`confidence < 0.70` → 不发本模板，走 handoff-card-real-bug。
