# heal-prompt: network-flake

## systemHint

> 当前失败是网络抖动（timeout / 偶发 5xx / CDN 抖动）。**不改业务断言**；只加可靠等待或 retry 策略；或**建议重跑**（大多数 flake 重跑即过）。

## task

- 失败 step：`{{failedStep}}`
- 网络事件摘要：`{{networkEvents}}`
- 判断优先级：
  1. 重跑过 `--retries=2` 仍失败 → 走 handoff（疑似真服务异常）
  2. 首次失败 → **优先推荐重跑**，不 patch
  3. 同一 step 近 N 次多次 flake → 可 patch 加 `waitForResponse` / `expect.poll`

## 推荐 patch 形式

```ts
// 把
await page.click('button.buy');
const res = await page.waitForResponse('**/orders');

// 改为(显式等待状态码)
const [res] = await Promise.all([
  page.waitForResponse(
    (r) => r.url().includes('/orders') && r.status() === 200,
    { timeout: 15_000 },
  ),
  page.click('button.buy'),
]);
```

或对偶发 503 加重试（仅限读类接口）：

```ts
await expect.poll(async () => (await apiGetOrder(id)).status, {
  timeout: 10_000, intervals: [500, 1000, 2000],
}).toBe('active');
```

## 硬约束

- NEVER `waitForTimeout(<固定毫秒>)` 兜底（flaky 放大器）
- NEVER 把 `expect(res.status()).toBe(200)` 改成 `toBeDefined()` 等软化断言
- NEVER 改 annotation / test 标题
- NEVER 给写类操作（下单 / 扣款）自动 retry —— 可能造成业务副作用
- patch 必须只动"等待 / 超时"相关代码

## recommendedAction 优先级

| 场景 | action |
|---|---|
| 首次失败 + network timeout | `rerun`（`--retries=2`）|
| 已知 flake + 重复发生 | `heal-propose`（加 waitForResponse）|
| 服务持续 5xx | `escalate`（走 handoff，查服务健康）|

## evidence 注入

```
networkEvents:
{{networkEvents}}
failedStep: {{failedStep}}
retriedBefore: {{retriedBefore}}
```

## verifySteps

1. `tsc --noEmit`
2. `playwright test --repeat-each=3 <spec>` 通过（flake 类必须 repeat 验证）

## 退化

`confidence < 0.70` 或服务 healthcheck 失败 → handoff（可能是 env / real 服务故障）。
