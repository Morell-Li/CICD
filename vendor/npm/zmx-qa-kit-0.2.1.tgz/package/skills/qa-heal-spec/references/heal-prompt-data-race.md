# heal-prompt: data-race

## systemHint

> 当前失败是账号 / 数据脏或 `afterEach` 未清理干净导致的状态污染。**首要不是改断言**，而是检查 `dataCleaner` annotation 与 fixture 隔离是否合规。

## task

- 失败原因摘要：`{{reason}}`
- 账号 annotation：`{{dataCleaner}}`（enabled / disabled / inherit）
- 判断路径：
  1. `dataCleaner: 'enabled'` 但 cleaner 实际失败 → **不改 spec**，改 `presets/<preset>/data-cleaner/` 实现（不在本 heal 范围） → 输出 handoff
  2. `dataCleaner: 'disabled'` 但测试产生脏数据 → 改 annotation 为 `'enabled'` + 补 `afterEach` cleaner
  3. 账号在同一 worker 内被多个 test 共享 → 改 fixture 为 `useAccount(...)` + `parallelIndex` 隔离

## 可以 patch 的改法

- 添加 / 修复 `afterEach(async () => { await cleanup(); })`
- 把 `dataCleaner: 'disabled'` 改为 `'enabled'`（当测试的确产生脏数据）
- 用 `useAccount({ tags, roles })` 替换共享 session
- 在 spec 的 `test.beforeEach` 里加"前置清理"而非 afterEach

## 硬约束

- NEVER 把 `dataCleaner: 'enabled'` 改为 `'disabled'` 来"让测试过"（掩盖问题）
- NEVER 在账号池外绕过 `useAccount` fixture 直接用本地 storageState
- NEVER 改 test 标题 / jira / productVersion
- 不在本 heal 里实现 preset 级别的 cleaner 具体动作（那是 `qa-explain-failure` 协议的 preset 实现责任）
- 若怀疑是账号池 GC bug → 直接退化为 handoff

## evidence 注入

```
dataCleaner:   {{dataCleaner}}
accountTags:   {{accountTags}}
failedStep:    {{failedStep}}
cleanerError:  {{cleanerError}}
```

## recommendedAction

| 场景 | action |
|---|---|
| annotation 缺 `dataCleaner: enabled` 且脏数据明显 | `heal-propose`（补 annotation + afterEach）|
| cleaner 本身报错 | `escalate`（改 preset 实现，不在 spec 改）|
| 并发 worker 抢同一账号 | `heal-propose`（改用 `useAccount` fixture）|

## verifySteps

1. `tsc --noEmit`
2. `playwright test <spec> --workers=1` 通过
3. `playwright test <spec> --workers=4 --repeat-each=2` 通过（验并发隔离）

## 退化

`confidence < 0.70` 或 cleaner 实现失败 → handoff，标账号 dirty 不归还。
