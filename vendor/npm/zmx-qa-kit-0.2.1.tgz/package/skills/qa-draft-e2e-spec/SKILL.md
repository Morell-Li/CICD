---
name: qa-draft-e2e-spec
description: Draft a new Playwright spec.ts from natural-language requirement, spec.md, or case.md + xmind.md + design assets. When caseMdPath is given, consume the TC list from HTML tail-tag comments and emit one test() per TC-NNN with metadata wired (jira / productVersion / runOn / dataCleaner / tags). Use when the user asks to "write a test", "draft a spec", "add an E2E", "case.md 转 spec", or runs /qa:draft-e2e. 起草 Playwright spec.ts / annotation 元数据 / case-driven.
priority: 30
allowed-tools: "Bash(npx:*) Read Write"
metadata:
  preset: web-e2e
  ownerTool: qa.draftE2ESpec
  category: qa-authoring
---

# qa-draft-e2e-spec — draft spec.ts

## Responsibility

Translate "natural-language test requirements" or an existing `spec.md` into an executable `tests/**/<feature>.spec.ts`, with correct `test()` annotation metadata. The artifact MUST pass the Verify Loop (tsc + `playwright --list`) directly.

## When to Use

Triggered by any of:

- User types `/qa:draft-e2e ...` in the IDE chat
- User describes a new test requirement directly ("write a limit-buy E2E for BTC/USDT spot")
- An existing `specs/<feature>/spec.md` needs a matching `.spec.ts`
- An existing spec.ts must be rewritten against new requirements (prefer the overwrite mode of MCP tool `qa.draftE2ESpec` over direct overwrite)

**Do NOT trigger in failure diagnosis, patch application, or account leasing scenarios** — those go through `qa-explain-failure` / MCP `qa.heal` / `qa.leaseAccount`.

## Input

- Natural-language requirement (at least one business scenario + expected result; ideally a Jira ID)
- Optional: `specs/<feature>/spec.md` (business description + AI prompt input, may drift; tools do **NOT parse its frontmatter**, it is prompt input only)
- Optional `caseMdPath`: `specs/<feature>/case.md` (v2.0 schema). When present, generate one `test()` per TC-NNN
- Optional `xmindMdPath`: `specs/<feature>/xmind.md` (used to look up selector clues by node hierarchy)
- Optional `designAssets: string[]`: design-mockup image paths (PNG/JPG) to help infer UI element semantics
- Optional: account-pool tags (e.g. `spot-trader`, `balance≥100USDT`) to inject into `runOn` / fixture

## Output

- Single `qa-e2e/tests/<feature>.spec.ts` 或 `qa-e2e/tests/<group>/<feature>.spec.ts`（Playwright `testDir` = `qa-e2e/tests`；**不要**写到项目根 `tests/`）
- **硬约束**：`<feature>` = 上游 case md 基名（剥 `.md`）。示例：
  - `qa-design/cases/trade-area.md` → `qa-e2e/tests/trade-area.spec.ts`（或 `qa-e2e/tests/<group>/trade-area.spec.ts`）
  - `qa-design/cases/login/buyer.md` → `qa-e2e/tests/login/buyer.spec.ts`
  - 自然语言起草无 case md 时，feature 从用户消息提取 kebab-case 后用作 basename
  - 这个约束保证 **case ↔ spec ↔ test-result 三向可追溯**；qa-kit validate 里有对应 gate，basename 不对齐 → warn
- MUST carry `test()` 调用两个字段分工（真源：`src/core/validate/annotation-schema.ts` v1.0 schema）：
  - **`tag: string[]`**（Playwright 原生） —— 至少含一个 `@feature-<name>` + 一个分类标签（`@equivalence`/`@boundary`/`@exception`/`@smoke`/`@tc-001` 等），**不是** annotation
  - **`annotation: Array<{type, description}>`**（qa-kit 自定 v1.0）：
    - `productVersion`（required）—— 版本字符串
    - `schemaVersion`（required）—— `^\d+\.\d+$`，目前 `'1.0'`
    - `runOn`（optional）—— e.g. `'staging'` / `'staging,prod-mirror'`
    - `dataCleaner`（optional）—— enum `'enabled' | 'disabled' | 'inherit'`
    - `supportedRange` / `deprecatedUntil` / `accounts`（optional）
    - **禁止** `jira` / `tags` 之类 v1.0 schema 外的 type —— validate 会 warn/reject。Jira ID 放到 commit / PR description / test 标题前缀里
- MUST pass the Verify Loop: `tsc --noEmit` + `playwright test --list`

## Steps (rubric)

### Branch A: input has `caseMdPath` → TC-driven generation

1. Read `caseMdPath`; extract all `<!-- id:TC-xxx | 分类:X | 维度:k=v -->` + the same-line title + the following three lines 前置条件 / 步骤 / 预期结果
2. **Filter scope**: only generate **non-contract TCs** (by default TC-001~299, i.e. 等价类 / 边界值 / 异常路径). Contract range (TC-3xx, frontmatter.idRange.contract) is skipped; that belongs to `qa-draft-k6-scenario` or contract testing
3. For each TC generate a `test('TC-xxx {标题}', { annotation: [...] }, async ({ page }) => { ... })`:
   - test title format fixed as `TC-xxx {中文标题}`, for regression-report traceability
   - annotation tags append `@tc-xxx` and a category tag matching case.md `分类` (`@equivalence` / `@boundary` / `@exception`)
   - In the test body, translate each line of 步骤 into a Playwright action, and 预期结果 into `expect(...)`
4. **Selector source priority**:
   1. `xmindMdPath` exists → first read xmind.md to locate the same TC-xxx node context
   2. `designAssets` exists → infer element semantics (button text / label) from mockups
   3. Project `tests/po/` has an existing Page Object → reuse
   4. **Playwright MCP live probe** (if `mcp__playwright__*` tools are available in this IDE session) → call `browser_navigate(baseURL + <page>)` then `browser_snapshot()` to read real DOM; pick `getByRole` / `getByTestId` / `getByLabel` from the snapshot rather than guessing. This is the preferred path when 1–3 fail.
   5. None of the above → emit a `TODO: selector 待 qa-heal-spec + MCP playwright 修正` comment; NEVER hardcode a fabricated selector
5. After writing, proceed to "Verify Loop" and "Cross-Tool Constraints" below

### Branch B: traditional natural-language / spec.md draft

1. **Understand the requirement**: break natural language into (preconditions / action sequence / assertions). Confirm Jira ID; if user did not provide, mark `jira: null` in annotation and prompt for back-fill.
2. **Locate PO module**: first read `presets/<preset>/po/` and project `tests/po/`. **Reuse existing Page Objects**; when missing, do NOT fabricate selectors inline — propose adding a new PO file first, then write the spec.
   - **Playwright MCP live probe**: if `mcp__playwright__*` tools are available and neither existing PO nor design assets give unambiguous selectors, call `browser_navigate(<target>)` + `browser_snapshot()` to read the real DOM first, then pick `getByRole` / `getByTestId` / `getByLabel` from observed roles/labels. Prefer this over hardcoding or leaving TODO.
3. **Skeleton first**: use Playwright `test()` + the standard annotation schema. Do NOT use `waitForTimeout(<fixed ms>)`; wait via `expect.poll` / `locator.waitFor`.
4. **Account handling**: tests requiring login state use the Playwright fixture `useAccount({ tags: [...] })`, which calls `qa.leaseAccount` underneath. Do NOT read `.qa-kit/accounts.json` directly.
5. **Data cleanup**: if the test produces dirty data (placing orders / opening positions), mark annotation `dataCleaner: 'enabled'` and add an `afterEach` hook hooked into the dataCleaner protocol.
6. **Verify**: after writing, MUST prompt to invoke the built-in verify of `qa.draftE2ESpec` (tsc + `playwright --list`); verify failure = incomplete.
7. **Cross-tool constraints**: do NOT `import '@playwright/test'`; always `import { test, expect } from '@zmx/qa-kit/runners/web'` (violates `qa-runner-web` rule otherwise).

## Division of Labor

- This skill is the **LLM propose side**. Programmatic checks (annotation schema / tsc / playwright list) go through the Verify Loop in `qa.validateSpec` / `qa.draftE2ESpec`. The LLM MUST NOT run tsc itself and self-declare "passed" (violates ADR-021 D2).
- This skill emits **draft only**. Real-browser selector fixing on already-failed runs belongs to `qa-heal-spec` downstream. **However**, using playwright MCP (`mcp__playwright__browser_*`) to *read live DOM during initial drafting* is in-scope and encouraged — see "Selector source priority" above.
- Contract range (TC-3xx) does NOT generate E2E; that belongs to perf / contract testing.
- Large few-shot / annotation schema tables will be moved to `references/` later; `scripts/scaffold.ts` handles PRD → skeleton one-shot conversion. **The scaffold scripts directory is a P0 follow-up**; this SKILL.md provides the rubric for now.

## Fallback Protocol

- Phase 1: LLM reads case.md / xmind.md / design mockups directly, no MCP tool dependency
- Phase 2: once MCP tool `qa.draftE2ESpec`'s `caseMdPath` param plugs in the parser (Wave 2), switch back to the programmatic path; this SKILL rubric remains the LLM fallback

## Cross References

- `../qa-author-xmind-md/SKILL.md` — upstream (xmind.md producer)
- `../qa-design-test-cases/references/test-case-schema.md` — case.md v2.0 schema
- `../qa-heal-spec/SKILL.md` — downstream selector fix
- `../../rules/qa-html-tag-contract.md` — TC-NNN / 分类 / 维度 extraction contract
- `docs/ai-workflow/qa-workflow.md` §2 DraftHarness
- `docs/ai-workflow/components-architecture.md` §7 decision rules
- `rules/qa-conventions.md` / `rules/qa-runner-web.md`
