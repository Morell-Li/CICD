# Coverage Gaps Heuristics

Six high-frequency miss heuristics. Scan `test-cases.md` + PRD for each, report to the user.

## H1 — Missing "Invalid Equivalence Class"

**Signal**: an input dimension has only "valid" representative TCs, no "invalid" ones.
**Example**: the `amount` dimension has only `100 USDT (valid)`, missing invalid classes like "negative / 0 / non-numeric string".
**Fix**: add a TC under `## 等价类` tagged `分类: 等价类 / 维度覆盖: amount=invalid(负数)`.
**Mapped class**: `missing-coverage`

## H2 — Incomplete 7-Point Boundary

**Signal**: a dimension with continuous boundaries has only the nominal value, missing `min-1 / min / max / max+1`.
**Example**: order amount `0 < x ≤ 10000`, only TC "amount=100", missing `0.01 / 10000 / 10000.01`.
**Fix**: generate 7 points per `boundary-value-rubric.md`.
**Mapped class**: `missing-boundary-value`

## H3 — Missing Exception Paths

**Signal**: `## 异常路径` section is empty or has fewer than 3 entries.
**Default requirement**: every feature MUST cover at least 4 exception categories — **permission denied / network failure / concurrent conflict / illegal state-machine transition**.
**Mapped class**: `missing-coverage`

## H4 — Missing Idempotency Dimension

**Signal**: PRD interface declares idempotency support (`Idempotency-Key` header or `requestId`), but TCs do not cover "repeat request".
**Fix**: at least 1 TC for "first success + replay same key returns identical result".
**Mapped class**: `missing-coverage`

## H5 — Missing Concurrency Race

**Signal**: resource-type operations (debit / stock decrement / place order) have only single-user TCs, no concurrent TCs.
**Fix**: at least 1 TC "two concurrent requests debit the same balance, only one succeeds".
**Mapped class**: `missing-coverage`

## H6 — Missing null / Default / Edge Characters

**Signal**: string / list dimensions cover only "normal values", missing `null / undefined / empty string / overlong / emoji / leading-trailing whitespace`.
**Fix**: every nullable field has at least 1 "default" TC + 1 "overlong" TC.
**Mapped class**: `missing-coverage`

## H7 — Equivalence Class Merges Mutually Exclusive States (not missing, but wrong)

**Signal**: a TC's `维度覆盖` is written as `status=canceled|completed|refunding`, merging mutually exclusive states.
**Fix**: split into 3 independent TCs.
**Mapped class**: `invalid-equivalence-class`

## H8 — Duplicate Representative

**Signal**: two TCs have identical `维度覆盖` key-values.
**Mapped class**: `duplicate-coverage`
**Action**: merge or delete one.

## Heuristic Priority

H1 / H2 / H3 are P0 (MUST report); H4 / H5 depend on whether the PRD declares them; H6 is "nice to have"; H7 / H8 are structural errors (higher priority than missing).

## Aggregation Into `coverageClass`

A single review may hit multiple heuristics; `coverageClass` takes the worst:

1. `invalid-equivalence-class` (structural)
2. `duplicate-coverage`
3. `missing-boundary-value`
4. `missing-coverage`
5. `ok`

When multiple issues coexist, the report's `missingItems` lists all of them; only the `coverageClass` field reports the worst.
