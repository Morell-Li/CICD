---
name: qa-review-coverage
description: Review an existing case.md (v2.0) against its PRD using CoverageDoctor rubric; extract TC dimension matrix from HTML tail-tag comments, compute cartesian coverage, emit gap list + coverage-class diagnostics (missing-coverage / duplicate-coverage / invalid-equivalence-class / missing-boundary-value) and draft candidate补全 cases. Use when user runs /qa:review-coverage, asks "cover 补全" / "覆盖率审查" / "补全边界" / "维度缺口" / "是否有遗漏", or at PR review. 覆盖率审查 / 维度矩阵 / 缺口诊断.
priority: 30
allowed-tools: "Bash(qa-kit:*) Read"
metadata:
  preset: test-case-design
  ownerTool: qa.reviewCoverage
  category: qa-review
---

# qa-review-coverage — CoverageDoctor review

## Responsibility

For a given case md (optionally with `spec.ts`), run coverage review against the PRD's acceptance criteria: identify **missing / duplicate / invalid** coverage, emit `coverage-class` diagnostics and a missingItems list. The LLM does NOT auto-edit the file; back-filling goes through `/qa:design` (overwrite mode).

## When to Use

- User runs `/qa:review-coverage <feature>`
- Coverage self-check before PR review (CI also runs this gate)
- After a new PRD version ships, diff-review against the old case md

**Do NOT use for**:
- Drafting TC from zero (that's `qa-design-test-cases`)
- Load-test coverage review (perf preset has its own metric, out of this skill's scope)

## Input Contract

```ts
type CoverageInput = {
  caseMdPath: string;         // qa-design/cases/<feature>.md（扁平单模块）或 qa-design/cases/<feature>/{module}.md（嵌套多模块）
  prdPath: string;            // 用户 PRD 路径（不限目录）
  specTsPaths?: string[];     // optional: existing spec.ts list (for PRD → TC → spec three-layer traceability)
  outputPath?: string;        // defaults to qa-design/cases/<feature>.coverage.md（同基名 + `.coverage.md` 后缀）
};
```

Input file MUST be v2.0 schema (see `../qa-design-test-cases/references/test-case-schema.md`): frontmatter `schemaVersion: '2.0'`, TC-NNN in HTML comment trailing tag. Older schemas must be migrated first.

## Output

```ts
type CoverageReport = {
  summary: { totalTCs: number; coveredACs: number; totalACs: number; rate: number };
  missingItems: Array<{
    acId: string;                  // PRD AC ID or excerpt
    kind: 'missing-coverage' | 'missing-boundary-value';
    dimension?: string;            // missing dimension (e.g. "amount 边界")
    suggestion: string;            // suggested TC to add
  }>;
  duplicates: Array<{ tcIds: string[]; reason: string }>;
  invalidClasses: Array<{ tcId: string; reason: string }>;
  coverageClass: 'ok' | 'missing-coverage' | 'duplicate-coverage' | 'invalid-equivalence-class' | 'missing-boundary-value';
};
```

## Steps (rubric)

### 1. Pull PRD AC list first

Scan PRD `## 验收条件` / `## Acceptance Criteria` section; each AC is a row of the coverage matrix. If the PRD has no AC → review cannot proceed, prompt user to add AC first.

### 2. Extract TC Dimension Matrix from HTML Comments

Read `caseMdPath`, regex-match all `<!-- id:TC-xxx | 分类:X[,Y] | 维度:k=v,k=v -->`, parse into:

```ts
type TcEntry = {
  id: string;                  // TC-001
  title: string;               // title (text before the same-line trailing comment)
  category: string[];          // ['等价类'] / ['契约','边界值']
  dimensions: Record<string, string>;  // { status: 'active', role: 'owner' }
};
```

Leaves without a comment, or comments missing `分类`, are marked `missing-label` in `missingItems` and excluded from the matrix computation.

### 3. Aggregate by Dimension Key + Cartesian Coverage

- Aggregate all observed value sets by `dimensions` key, e.g. `status={active, pending, canceled}`, `role={owner, admin}`
- Theoretical combinations = cartesian product of each key's value count (e.g. 3 × 2 = 6 combos)
- Actual combinations = de-duplicated count N of TC dimension-value tuples
- `coverage = N / theoretical total`
- Missing combinations enter `missingItems`, classified `missing-coverage`

### 4. Align Matrix by AC × Category

Rows/columns = AC × (等价类 / 边界值 / 异常路径 / 契约). Mark hit / miss; miss → `missing-coverage` with AC source text attached.

### 5. Apply Heuristics

Run the 6 heuristics per `references/coverage-gaps-heuristics.md` (missing invalid class / missing 7-point boundary / missing exception path / missing idempotency / missing concurrency / missing null-default).

### 6. Duplicate / Invalid Detection

- Two TCs with identical `分类` + `维度` → `duplicate-coverage`
- `维度` merges mutually-exclusive states (`status=canceled|completed`) → `invalid-equivalence-class`

### 7. Generate coverage-report.md

Write to `outputPath` (default `qa-design/cases/<feature>.coverage.md（同基名 + `.coverage.md` 后缀）`):

```markdown
# {项目}｜{模块} 覆盖率审查报告

## 摘要
- 用例总数: N
- 维度组合覆盖: 4/6 = 66.7%
- AC 覆盖: 8/10

## 已覆盖
- TC-001 status=active, role=owner
- ...

## 缺口（missingItems）
- [missing-coverage] status=canceled, role=admin —— 建议补用例:...
- [missing-boundary-value] orderId 长度 31 / 33 未覆盖

## 补用例草稿
（按分类归号段起草,号段继承 frontmatter.idRange）

### 等价类（1-99）
##### 取消 canceled 状态订单（应失败） <!-- id:TC-00N | 分类:等价类 | 维度:status=canceled,role=owner -->
- 前置条件:...
- 步骤:...
- 预期结果:...
```

### 8. Do Not Auto-Edit case.md

This skill only emits `coverage-report.md`; actually writing back into case.md goes through `/qa:design --overwrite` or user hand-merge.

## Division of Labor

- This skill is the **LLM propose side**. The LLM produces gap analysis + candidate补全 drafts
- ID-range uniqueness / ID conflict / schema legality are the validator's job (phase 2 Wave 2 `qa.validateTestCaseMd`)
- Preset type 3 has no Heal hook; `coverage-class` failures do NOT go through `qa.heal`, no patch emitted
- Coverage-matrix / dimension-key comparison / duplicate detection in phase 2 go through the programmatic `qa.reviewCoverage` gate; the LLM does NOT own the "judge duplicate / invalid" decision (ADR-021 D2 red line)

## Fallback Protocol

- Phase 1: LLM reads case.md directly, no MCP tool; follow this rubric to hand-extract comments, compute cartesian product, write report
- Phase 2: MCP tool plugs in case-md parser, switch back to programmatic path; this SKILL rubric remains as LLM fallback

## Cross References

- `../qa-design-test-cases/references/test-case-schema.md` — upstream case.md v2.0 schema (HTML trailing-tag syntax)
- `../qa-design-test-cases/references/module-golden-template.md` — dimension matrix reference
- `../../rules/qa-html-tag-contract.md` — HTML comment contract (basis for TC-NNN / 分类 / 维度 extraction)
- `../../rules/qa-preset-types.md` — three preset types cheatsheet
- `references/coverage-gaps-heuristics.md` — 6 heuristics
- `docs/presets/test-case-design.md` §6 coverage-class
- `docs/ai-workflow/failure-class.md` §type-3 coverage-class
