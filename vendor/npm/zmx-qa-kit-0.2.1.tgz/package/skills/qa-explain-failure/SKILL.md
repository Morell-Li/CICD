---
name: qa-explain-failure
description: Summarize a failed test run with failureClass, confidence, evidence, and a 3-choice recommended action. Use when a test fails and the user asks "why did it fail", runs /qa:explain, or Healer propose was rejected and needs a handoff card.
priority: 20
allowed-tools: "Bash(qa-kit:*) Read"
metadata:
  preset: web-e2e
  ownerTool: qa.heal
  category: qa-diagnostics
---

# qa-explain-failure — 失败诊断与转交卡

## 职责

把一次失败的测试跑（trace.zip + Playwright 报告 + stderr）翻译成人类可读的失败摘要，给出 **`failureClass` + `confidence` + `evidence`**，以及三选一的推荐动作；当置信度低或判为 `real-bug` / `unknown` 时，直接生成 **Lark / Jira 转交卡**。

## 何时使用

- 用户敲 `/qa:explain <spec>` 或在聊天里问"为什么挂了"
- `qa.heal` dry-run 返回 `real-bug` / `unknown` 类别，Healer 拒绝 propose，需要业务 QA 看转交卡
- PR 评审时对某个失败用例要人读的复盘

**不用于**：自动修 patch（那是 `qa-heal-spec` + MCP `qa.applyHealDiff`）、选择器打磨（那是 `qa-draft-e2e-spec` 的 PO 复用路径）。

## 输入

- trace.zip 路径（来自 `test-results/<run>/trace.zip`）
- 失败用例的 `spec.ts` 路径
- 可选：Playwright `test-results.json` / reporter 摘要
- 可选：最近的 spec.ts git diff（判 `real-bug` 时参考）

## 输出

- Markdown 段落，包含：
  1. 一句话失败摘要（给业务 QA 看）
  2. `failureClass`（七类之一）+ `confidence`（0-1）
  3. `evidence`：2-5 条具体证据（trace 步骤 / network / stderr 摘录）
  4. **推荐动作三选一**：转开发 / 改 spec / 重跑
- 若 `failureClass ∈ {real-bug, unknown}` 或 `confidence < 0.5`：追加 **Lark / Jira 转交卡**（标题 / 复现步骤 / trace 链接 / failureClass + confidence + evidence）

## 操作步骤（rubric）

1. **先调程序化分类器**：LLM 不要自己猜类别。先调 MCP `qa.heal` (dry=true) 或在无 MCP 环境里跑 `skills/qa-explain-failure/scripts/classifier.ts`（P0 后续实施）。**把分类交给代码，LLM 只做人话翻译**。
2. **读取 evidence**：从 trace 中挑关键步骤（失败 step 名 / selector / 网络响应码 / 关键 stderr 行）；**不虚构不存在的 step**。
3. **判读置信度**：低置信（< 0.5）或类别是 `real-bug` / `unknown` → 走转交卡路径；高置信且非 real-bug → 走"推荐动作三选一"。
4. **推荐动作三选一模板**：
   - **转开发**：当判为 `real-bug`（功能回归 / 断言逻辑失败且非 spec 漂移）
   - **我改 spec**：当判为 `selector-drift` / `assertion-mismatch(spec-side)`（可调 `/qa:heal`）
   - **重跑**：当判为 `network-flake` / `data-race`（附上 `--retries=2` 建议）
5. **转交卡字段顺序**固定（便于业务 QA 复制到 Jira comment）：标题 → 影响版本 → 复现步骤 → trace 链接 → failureClass + confidence → evidence → 建议 Owner。
6. **不要把 trace 全文粘进回答**：只挑关键 2-5 条；全文用链接引用。

## 分工提醒

- 本 skill 只负责"人话翻译 + 转交卡生成"，不负责改代码。
- 真正的分类逻辑在 `qa-explain-failure` skill（LLM 经 Bash 调）或 MCP tool `qa.heal` 内部（经 JSON-RPC 调）——**两条路径共享同一个 `src/classifier/` 核心**（ADR-021 双轨 wrapper）。
- Handoff-card 模板（7 类各一份）后续落 `references/handoff-card-<class>.md`；当前 P0 先内联在 LLM 推理里。

## 交叉引用

- `docs/ai-workflow/failure-class.md` §7 类判定 rubric
- `docs/ai-workflow/components-architecture.md` §5 双轨 wrapper
- `rules/qa-failure-class.md`
