---
name: qa-codegen
description: Record user interactions via Playwright's GUI recorder (`playwright codegen`) to seed a spec; the raw recording is then cleaned into a qa-kit-compliant spec via `qa-draft-e2e-spec`. Use when the user says things like "帮我录一个 E2E / 我不熟这个页面 / 用录制起草 / 录屏生成用例 / record the login flow", or runs `/qa:codegen`. 录制起草 E2E / selector 不熟 / 可视化录制。
priority: 25
allowed-tools: "Bash(qa-kit:*) Bash(pnpm:*) Read"
metadata:
  preset: web-e2e
  ownerTool: qa-kit codegen
  category: qa-authoring
---

# qa-codegen — 录制起草 Playwright spec

## 职责

调起 runner 原生录制器（`playwright codegen` GUI）作为 **起草辅助**，让业务 QA 通过在真实页面点击来产出原始 spec 初稿；录完 **不直接落盘**，由 `qa-draft-e2e-spec` 清洗成合规 spec.ts（annotation / PO / selector 优先级 / verify loop）。

## 何时使用

触发条件任一：

- 用户在 IDE 聊天里输入 `/qa:codegen [--url]`
- 用户用自然语言表达"不熟这个页面 / 帮我录一个 / 录屏生成 / 跟着我点一下" 等 **偏向可视化录制** 的意图
- 多步交互场景（5+ 步）从零起草，直接写 spec 风险高

**不用于**：
- 用户已有 `case.md` / `spec.md` / 详细文字需求 → 走 `qa-draft-e2e-spec`（Branch A / B），不需录制
- 修挂掉的测试 → 走 `qa-heal-spec`
- 压测 / 设计类 → 对应 skill

## 操作步骤（rubric）

1. **确认 URL**：从用户消息里抽取目标 URL；缺失则追问一句 "录哪个页面？(staging / 本地端口)"。不要随便拿 `baseURL` 兜底，录错页面等于浪费录制。
2. **起录**：spawn CLI
   ```bash
   pnpm exec qa-kit codegen --url <URL>
   ```
   （用户本机；`qa-kit codegen` 内部 = `npx --no-install playwright codegen`。这是 L1，**不走 MCP**，因为录制必须人机交互。）
3. **等用户操作完**：GUI 里用户点完关闭窗口后，CLI 把 raw 代码写到 **`qa-e2e/recordings/codegen-<时间戳>.spec.ts`**（未指定 `-o` 时的默认路径；gitignore 已覆盖）。stderr 会打印 `[qa-kit codegen] output → <绝对路径>`，从那里取路径。
4. **读 recording 文件 → 立刻转交 `qa-draft-e2e-spec`**：Read 工具读取 step 3 的路径，把文件内容作为 `chatDescription` 的一部分喂给 MCP `qa.draftE2ESpec`；由它重写：
   - `import '@playwright/test'` → `import { test, expect } from '@zmx/qa-kit/runners/web'`
   - 原始 selector（`page.locator('.css-xxx')` / nth-child 等脆弱选择器）→ `getByRole` / `getByTestId` / `getByLabel`（若 Playwright MCP 可用，边改边调 `browser_snapshot` 验 role/label）
   - 裸 `test('test', ...)` → 带 annotation 的 `test('TC-xxx 标题', { annotation: [...] }, ...)`
   - 复用项目 `tests/po/` 里已有的 Page Object；没有就提议新建 PO，再落 spec
   - 删掉 `page.waitForTimeout(1000)` 这种硬 sleep，换 `expect.poll` / `locator.waitFor`
   - 过 verify loop（tsc + `playwright --list`），verify 失败不算完成
5. **Jira / annotation 元数据**：录制本身不带这些信息，必须和用户再确认 `jira` / `productVersion` / `runOn` / `dataCleaner`，缺字段标 `null` 不硬编造。

## 分工提醒

- **录制 = L1 CLI**，不挂 MCP：GUI 必须人操作，封成 MCP 工具反而阻塞 AI 自动化
- **清洗 = 走 MCP `qa.draftE2ESpec` / `qa-draft-e2e-spec` skill**，propose / verify loop 不破契约
- **别跳过清洗直接落 raw**：raw 代码的 selector 质量极低（codegen 爱用 `nth-child`、`.classname`），落盘等于给未来埋 heal 债

## 降级

- `playwright` CLI 不在 PATH → `qa-kit codegen` 报 `BINARY_NOT_FOUND`；提示用户 `pnpm install` 或 `brew install --cask playwright` 后重试
- 非 `web-e2e` preset 项目调用 → CLI 直接拒绝（P0 仅支持 web-e2e；flutter-maestro P1）

## 交叉引用

- `commands/qa/codegen.md` — slash 入口
- `../qa-draft-e2e-spec/SKILL.md` — 清洗下游（必经）
- `../qa-heal-spec/SKILL.md` — 跑起来挂了再走这里
- `rules/qa-runner-web.md` — selector 优先级 / import 约束
