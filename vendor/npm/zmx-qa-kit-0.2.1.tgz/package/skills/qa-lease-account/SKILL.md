---
name: qa-lease-account
description: Lease a test account (or multi-role bundle) from the file-based account pool using proper-lockfile atomic locking and tag filtering. Use when a test needs a logged-in user, or the user asks "which account can I use" / "give me a maker+taker pair".
priority: 20
allowed-tools: "Bash(qa-kit:*) Read"
metadata:
  preset: core-reserved
  ownerTool: qa.leaseAccount
  category: qa-infra
---

# qa-lease-account — 账号池租借

## 职责

从 `.qa-kit/accounts.json`（P0 file mode；P1 `HttpPoolProvider`）按标签过滤租借账号，写入租约文件，保证多 worker 并发下同一账号不被双租。支持 **multi-role**（如 `maker` + `taker` 一次租一对）。

## 何时使用

- 测试 fixture 需要登录态用户（`useAccount({ tags: ['spot-trader', 'balance>=100USDT'] })`）
- 用户问"哪个账号能用"或跑 `qa-kit accounts lease`
- multi-role 场景：撮合 / IM / 社交 需要一次租 N 个角色

**不要用于**：
- 跨测试持久化账号（每个 test 独立租借 + afterEach 归还）
- 生产账号（账号池只含 dev / staging）

## 输入

```ts
type CheckoutInput = {
  tags: string[];                    // 标签过滤（AND 语义）
  roles?: Record<string, string[]>;  // multi-role：role name → tags
  ttlMs?: number;                    // 租约 TTL，默认 30min
  runId: string;                     // 调用方传入，用于租约归属
};
```

## 输出

```ts
type CheckoutResult = {
  leaseId: string;
  accounts: Record<string, {
    username: string;
    storageStatePath: string;        // Playwright storageState 落盘路径
    roleTag?: string;
    releaseUrl: string;              // 归还租约的幂等 URL（CLI + MCP 共用）
  }>;
  expiresAt: number;                 // epoch ms
};
```

## 操作步骤（rubric）

1. **走 MCP tool `qa.leaseAccount` 优先**：JSON-RPC 签名更严，server 侧拿 `proper-lockfile` 跨 worker 原子锁。Skill + script 路径是无 MCP 环境的兜底。
2. **永远不要直接读写 `.qa-kit/accounts.json`**：即便 LLM 看到了文件，也不允许直接 patch。没有锁 = 多 worker 抢账号直接爆（反模式，见 `components-architecture.md` §8）。
3. **multi-role 一次租一组**：不要分两次 `checkoutAccount`，否则死锁可能发生。MCP tool 的 `roles` 入参是**原子**的。
4. **归还时机**：测试 `afterEach` / `afterAll` 里必归还（调 `qa.releaseAccount` 或 CLI `qa-kit accounts release <leaseId>`）；失败路径 **标 dirty 不归还**（dataCleaner 协议）。
5. **TTL 保底**：即便 LLM / 用户忘记归还，TTL 到期后 lockfile GC 会自动回收（见 `core/account-pool.md`）。
6. **multi-role 租约协议**：`roles` key 是业务角色名（`maker` / `taker` / `customer-service`），value 是 tag 数组；返回的 `accounts` 键与入参 role name 对齐，便于在 spec.ts 里按名引用。

## 分工提醒

- 原子锁、标签过滤、租约 GC 都是**程序化**动作（ADR-021 D2 verify 侧）——**必须由 server 代码做**，LLM 不承担。
- 本 skill 仅在 Codex / Copilot / Gemini 这类无 MCP 环境下，作为 `scripts/lock.ts` 的 LLM 操作说明（P0 后续实施）。

## 交叉引用

- `docs/core/account-pool.md`
- ADR-012 账号池 + multi-role
- `docs/ai-workflow/components-architecture.md` §8 反模式
- `rules/qa-conventions.md`（fixture 命名 / 租约生命周期）

**scripts 目录（`scripts/lock.ts` / `scripts/release.ts` + `references/multi-role-protocol.md`）P0 后续实施**。
