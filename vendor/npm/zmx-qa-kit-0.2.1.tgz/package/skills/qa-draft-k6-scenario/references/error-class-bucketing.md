# Error Class Bucketing

A pattern for splitting a single "error rate" metric into per-category counters
so that thresholds reflect real regression rather than expected business
outcomes.

## Why per-category buckets

A single overall `errors / total` rate hides regressions. Some error codes
returned by a server are **legitimate terminal states** for a particular code
path — for example, an "input rejected by validation" outcome is a correct
response to certain inputs and may be 100% of one scenario's traffic by design.
Aggregating that path into the global error rate either:

- forces the threshold to be loose enough to accept those rejections (and now
  it cannot catch real regressions), or
- forces the threshold to be tight (and now every routine run is "failing"
  because expected rejections exceed the bound).

Splitting into per-category counters lets each category carry its own
threshold, sized to that category's expected behaviour.

## Generic primitive

The recommended primitive (defined in the perf-helpers package, outside the
scope of this reference) has the shape:

```ts
defineErrorBuckets<K extends string>(
  buckets: readonly K[],
  classify: (errorCode: string) => K | undefined,
): Record<K, Counter>
```

It returns one `Counter` per declared bucket name. Each iteration, after you
read the response error code, you call `classify(code)` and increment the
returned counter (the perf-helpers API hides this dispatch). Codes that
`classify` returns `undefined` for are unrecognized and should be tracked
separately so they cannot hide silently.

This document only describes the shape — the actual implementation lives with
the helpers.

## Recipe template

Fill the bracketed values with names that match **your project**. qa-kit does
not prescribe categories.

```ts
// Step 1: declare YOUR project's error categories.
// These names are NOT prescribed by qa-kit. Pick categories that match your
// backend's error codes and your team's response procedure (retry vs alert
// vs accept-as-business-outcome).
const buckets = defineErrorBuckets(
  ['<category_a>', '<category_b>', '<category_c>'] as const,
  (errorCode) => {
    // Step 2: implement project-specific classify.
    // Prefer an exact switch on enum values exported by your backend.
    // Fall back to keyword / regex heuristics only when the enum is unstable
    // or partially documented.
    switch (errorCode) {
      case '<your_code_1>':
        return '<category_a>';
      case '<your_code_2>':
        return '<category_b>';
      // ...
    }
    return undefined; // unrecognized — bubble up to an "unknown" counter
  },
);

// Step 3: declare per-bucket thresholds in perf-spec.yaml, e.g.:
//   thresholds:
//     - metric: err_<category_a>
//       expr: "count<<project_specific_limit>"
//     - metric: err_<category_b>
//       expr: "count<<project_specific_limit>"
```

## Anti-pattern: importing a fixed taxonomy

Do not copy the error categories from another team's PRD, framework, or system
into your scenario. Categories that look generic ("transient", "permanent",
"business") are still implicitly tied to a specific backend's error code list
and a specific operations playbook. Re-using them in a different system gives
you buckets that nothing maps cleanly into, and you end up with a junk
"other" bucket that absorbs the regression you wanted to detect.

Pick categories that satisfy two tests:

1. Each declared category has at least one error code that maps into it from
   *this* project's backend.
2. Each declared category has a distinct response procedure (retry, alert,
   accept, escalate). If two categories share the same procedure, merge them.

## Examples of category *shapes* generic teams may end up with

These are descriptions, not prescribed names. Your team picks the actual
labels:

- A **transient retryable** shape — codes the client can safely re-issue
  (capacity backoff, transient dependency timeout). Usually thresholded as a
  small percentage.
- A **permanent client error** shape — codes that mean the request itself is
  invalid (malformed input, unknown handle). Usually thresholded near zero in
  a healthy load-test corpus.
- An **expected rejection** shape — codes that represent a correct terminal
  outcome of the business rule under test (e.g. an "input was deliberately
  invalid in this scenario"). Threshold sized to the design, not to zero.

The point of listing shapes rather than names is that the names you commit to
should come from reading your own error-code documentation and talking to the
team responsible for it, not from a fixed taxonomy in this reference.

## Drafter behaviour

`qa.draftK6Scenario` should not auto-generate category names. When the user's
fixture / proto context exposes an `errorCode` field on responses, drafter
emits the recipe skeleton above with `<category_a>` / `<category_b>` /
`<category_c>` placeholders left for the user to rename, plus a TODO comment
pointing them at this reference.
