# k6 Threshold Declaration Spec

## Required Fields

Every scenario MUST declare at least four items:

```ts
thresholds: {
  http_req_duration: ['p(95)<300', 'p(99)<500'],
  http_req_failed:   ['rate<0.01'],
  checks:            ['rate>0.99'],
  iteration_duration:['p(95)<2000'],    // optional, but recommended
}
```

Missing any of these → `scenario-schema` gate rejects.

## p95 / p99 Value Guide

| Business class | Suggested p95 | Suggested p99 |
|---|---|---|
| Read-class HTTP (market / balance / list) | < 150ms | < 300ms |
| Write-class HTTP (place / cancel / withdraw) | < 300ms | < 500ms |
| Heavy query (history orders / reports) | < 800ms | < 1500ms |
| WebSocket session lifetime | `ws_session_duration > target * 0.9` | — |

Concrete values **MUST align to PRD performance targets or the previous baseline**; arbitrary values make the baseline meaningless.

## Tagged Thresholds

Granularity down to "a specific endpoint":

```ts
thresholds: {
  'http_req_duration{name:placeOrder}': ['p(95)<300'],
  'http_req_duration{name:cancelOrder}': ['p(95)<200'],
}
```

Tag `name` is manually attached at the request site:

```ts
http.post(url, body, { tags: { name: 'placeOrder' } });
```

## abortOnFail

Critical thresholds can `abortOnFail` to short-circuit and save budget:

```ts
thresholds: {
  http_req_failed: [{ threshold: 'rate<0.05', abortOnFail: true, delayAbortEval: '30s' }],
}
```

`delayAbortEval` avoids false aborts during early ramp-up jitter.

## checks vs thresholds

- `check(res, { 'status 200': (r) => r.status === 200 })` — business assertion, success-rate statistic
- `thresholds.checks: ['rate>0.99']` — gate on checks success rate

Used together: `check` writes assertions, `threshold` guards the gate. **`check` alone does NOT fail the scenario**; a threshold is required to affect exit code.

## Exit-Code Semantics

- All thresholds pass → exit 0
- Any threshold fails → exit 99 (qa.runK6 uses this to decide `perf-class = threshold-breach`)

## Error-Rate Naming

- `http_req_failed` is a built-in metric (HTTP status ≥ 400 or network error)
- A custom `Rate` metric for business semantics (e.g. `cancel_success_rate`) must be declared separately in thresholds

## Baseline Alignment

Threshold values and the baseline in `qa-perf/eval/baseline.json` are NOT the same thing:

- **threshold** = absolute acceptance line (business goal)
- **baseline p95** = last stable run's p95 sample (consumed by bootstrap-CI for delta comparison)

The `qa-analyze-perf` skill reads both: threshold breach → `threshold-breach`; threshold pass but baseline delta > 10% → `p95-degradation`.
