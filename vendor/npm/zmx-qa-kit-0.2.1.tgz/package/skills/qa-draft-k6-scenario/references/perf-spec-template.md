# perf-spec → 多 scenario 脚本骨架

## 用法

当用户运行 `/qa:draft-perf` 且业务仓里**已有** `qa-perf/perf-spec.yaml` 时，AI 按
本模板把 spec 编译成对应的 k6 TypeScript 脚本骨架。若 spec 缺失，用自然语言
起草 spec 再按此流程走一次（不要跳过 spec 直接写 script —— analyzer/gate 依赖 spec）。

## 最小可跑骨架

```ts
// scenarios/demo.k6.ts — 由 /qa:draft-perf 从 perf-spec 派生
import { check } from 'k6';
import { get } from '../lib/protocols/http.ts';
import { scenarioTags } from '../lib/tags.ts';
import { uniformThinkTime } from '../lib/thinkTime.ts';
import { registerMetrics, metric } from '../lib/metrics.ts';
import type { Trend } from 'k6/metrics';

// 1) 读 spec.custom_metrics 注册（init 上下文一次）
registerMetrics([{ name: 'demo_latency_ms', type: 'trend', isTime: true }]);
const demoLatency = metric('demo_latency_ms') as Trend;

// 2) 每个 spec.scenarios[].exec 对应一个 exported function
export function steadyFlow(): void {
  const t0 = Date.now();
  const res = get(`${__ENV.QA_K6_TARGET_URL}/items`, {
    bizTags: { endpoint: 'items' },  // scenario tag 自动注入
  });
  demoLatency.add(Date.now() - t0);
  check(res, { 'status ok': (r) => r.status === 200 });
  uniformThinkTime(0.5, 1.5);  // jitter 避免 VU 锁步
}

export function burstFlow(): void {
  // ...
}

export default steadyFlow;  // k6 要求 default；runner 会按 spec.scenarios 挂载
```

## 映射规则

| perf-spec 字段 | 脚本侧产出 |
|---|---|
| `runtime.script` | 本文件路径 |
| `scenarios[].exec: X` | `export function X(): void { ... }` |
| `scenarios[].name: Y` | **不写进脚本**；runner 自动注入 `tag: { scenario: Y }`（见 `scenarioTags`）|
| `custom_metrics[]` | init 上下文 `registerMetrics(...)` 调用 |
| `thresholds[]` | **不写进脚本**；由 perf-spec 声明，runner 注入到 k6 options |
| `data_pools[]` | `import { definePool } from '../lib/pool.ts'` + `pool.acquire()` 在 exec 里 |
| `hooks[]` | **不写进脚本**；由 qa-kit hook runner 在脚本外执行 |

## 禁写

- ❌ 脚本里不要自己写 `export const options = {...}` —— spec 是唯一 source-of-truth，
  写了会触发 scenario-schema gate 的冲突警告
- ❌ 不要在 exec 函数里 retry 业务逻辑 —— 压测就是测真实失败率
- ❌ 不要用 `sleep(1)` 裸 sleep —— 用 thinkTime helper 的 jitter 版本

## 热点账户 / 高压单账户模式

```ts
import { definePool } from '../lib/pool.ts';

// spec.data_pools 里声明 { name: 'hotspots', ref: './fixtures/hot.json', lease_strategy: 'shared' }
const hotspots = definePool<{ key: string }>({
  name: 'hotspots',
  filePath: '../fixtures/hot.json',
  strategy: 'shared',
  onExhaust: 'fail',
});

export function hotspotFlow(): void {
  const rec = hotspots.acquire();
  if (!rec) return;
  get(`${BASE}/resource/${rec.key}`, { bizTags: { mode: 'hotspot' } });
}
```

## gRPC 骨架（unary）

```ts
import { defineGrpcClient } from '../lib/protocols/grpc.ts';

const client = defineGrpcClient({
  importPaths: ['../protos'],
  protoFiles: ['my_service.proto'],
  address: __ENV.QA_GRPC_TARGET ?? 'svc.local:9090',
  plaintext: true,
});

export function unaryFlow(): void {
  const resp = client.invoke('my.service.v1.Service/Method', { id: '1' });
  if (resp.status !== 0) throw new Error(`grpc err: ${resp.status}`);
}
```

gRPC client/server streaming：k6 支持有限，**超出 qa-kit 覆盖**——需要时走 ghz 独立 runner，
不纳入压测脚本。AI 不应生成 streaming 调用代码。

## 当 spec 没给到全部信息时

- scenarios 里 `exec` 函数名未定：按 kebab→camel 转换（"burst-flow" → `burstFlow`）
- threshold metric 未指定 scenario：生成顶层 exec 留白 TODO，提示用户补
- data_pool ref 指向不存在文件：**不创造内容**，抛 handoff card 让用户填 fixture

## 交叉引用

- `rules/qa-perf-spec.md` — spec 本身的完整契约
- `references/threshold-schema.md` — threshold 表达式约定
- `references/k6-script-patterns.md` — VU / stages / executor 组合范式
