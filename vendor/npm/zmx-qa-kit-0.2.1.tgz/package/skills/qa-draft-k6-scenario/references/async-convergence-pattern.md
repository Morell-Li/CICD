# Async Convergence Pattern

A reference pattern for measuring SLA on **asynchronous systems** where the
"submit" call returns an intermediate state and the work completes later. The
metric we care about is wall-clock time from submit to terminal state, not the
RTT of any single RPC.

## When this pattern applies

The shape "submit returns intermediate state → poll a query endpoint until the
state becomes terminal or a deadline elapses" appears across many domains. A
non-exhaustive set of generic examples:

- **Message-queue consumer**: producer enqueues a message; some downstream
  consumer eventually marks the message processed. Verifier polls a status
  endpoint or queries the queue's processed offset.
- **Job runner / workflow engine**: caller submits a job, gets back a `jobId`
  and `status: queued`. Verifier polls `GET /jobs/{id}` until status is one of
  `succeeded` / `failed` / `cancelled`.
- **Async HTTP API (`202 Accepted` + `Location`)**: server returns 202 plus a
  resource URL. Verifier polls that URL until it returns 200 (terminal success)
  or a 4xx/5xx (terminal failure).
- **Promise / Future-style RPC**: submit returns a handle; a separate
  `awaitResult(handle)` returns when the future resolves. From the load-test
  side this still looks like "poll until resolved".

The common abstraction:

```
submit() -> { handle, status: <intermediate> }
loop until deadline:
  state = query(handle)
  if isTerminal(state): record(now - submittedAt); break
  sleep(interval)
otherwise: record(deadline - submittedAt)  // short-circuit; see below
```

## k6 skeleton

A generic poll-until-terminal helper. There is no business naming here; both
the predicate and the query function are user-supplied.

```ts
import { sleep } from 'k6';

interface PollOptions {
  timeoutMs: number;
  intervalMs: number;
}

export function pollUntilTerminal(
  queryFn: () => { status: string },
  isTerminal: (status: string) => boolean,
  opts: PollOptions,
): number | null {
  const startedAt = Date.now();
  const deadline = startedAt + opts.timeoutMs;
  while (Date.now() < deadline) {
    sleep(opts.intervalMs / 1000);
    const r = queryFn();
    if (isTerminal(r.status)) {
      return Date.now() - startedAt;
    }
  }
  return null; // did not converge before deadline
}
```

Per iteration, the calling scenario does:

```ts
const submittedAt = Date.now();
const handle = submit(req);
const elapsed = pollUntilTerminal(
  () => query(handle),
  (s) => s !== 'pending' && s !== 'processing',
  { timeoutMs: 10_000, intervalMs: 200 },
);
const observed = elapsed ?? 10_000;          // see "Short-circuit" below
convergenceTrend.add(observed);
```

## Threshold convention

Declare a custom Trend metric in your `perf-spec.yaml` and a matching
threshold:

```yaml
custom_metrics:
  - { name: <your_metric_name>_ms, type: trend }

thresholds:
  - metric: <your_metric_name>_ms
    expr: "p(99)<<SLA_ceiling>"
```

Replace `<your_metric_name>` and `<SLA_ceiling>` with project values. Names
ending in `_convergence_ms` or `_settlement_ms` are conventional but not
required.

## Short-circuit design

If polling exceeds the deadline, the helper returns `null`. The caller MUST
record a value **at least as large as the SLA ceiling** in that case, so the
threshold can fire. The simplest implementation is to record the timeout value
itself:

```ts
const observed = elapsed ?? opts.timeoutMs;
convergenceTrend.add(observed);
```

If you instead skip recording on timeout, you silently improve the metric
distribution: every too-slow iteration vanishes from the percentile, and the
threshold can never break. That is the opposite of what you want.

## Drafter trigger

`qa.draftK6Scenario` should recommend this template when both signals appear:

1. The spec declares a custom metric whose name matches `*_convergence_*` or
   `*_settlement_*`.
2. The proto / fixture set contains a poll-style RPC method (a query that
   returns a status field and is the natural pair of a submit method).

When both fire, drafter emits the `pollUntilTerminal` skeleton and wires it to
the declared custom metric and threshold. The actual terminal-state predicate
and query call are filled in from the user's proto / fixture context, not
inferred from a hard-coded business taxonomy.
