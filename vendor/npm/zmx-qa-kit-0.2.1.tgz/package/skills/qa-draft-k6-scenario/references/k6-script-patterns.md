# k6 Scenario Patterns

Three draft templates. Pick one as the skeleton per business scenario.

---

## Pattern A — placement-cancel (matching-engine loop)

Place order → wait N seconds → cancel. Measures place/cancel throughput + matching latency.

```ts
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Rate } from 'k6/metrics';

export const options = {
  scenarios: {
    place_cancel: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '60s', target: 200 },
        { duration: '300s', target: 200 },
        { duration: '30s', target: 0 },
      ],
      gracefulStop: '30s',
      tags: { scenario: 'place-cancel', product: 'zmx' },
    },
  },
  thresholds: {
    'http_req_duration{name:placeOrder}': ['p(95)<300', 'p(99)<500'],
    'http_req_duration{name:cancelOrder}': ['p(95)<200'],
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
  },
};

const placeCounter = new Counter('placed_orders');
const cancelRate = new Rate('cancel_success_rate');

export default function () {
  const place = http.post(`${__ENV.API_BASE}/orders`, JSON.stringify({ /* ... */ }), {
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${__ENV.TOKEN}` },
    tags: { name: 'placeOrder' },
  });
  check(place, { 'place 200': (r) => r.status === 200 });
  placeCounter.add(1);

  const orderId = place.json('id');
  sleep(1);

  const cancel = http.del(`${__ENV.API_BASE}/orders/${orderId}`, null, {
    headers: { Authorization: `Bearer ${__ENV.TOKEN}` },
    tags: { name: 'cancelOrder' },
  });
  cancelRate.add(cancel.status === 200);
}
```

**Typical params**: VU 100-500, ramp 60s, steady state 300s.

---

## Pattern B — http-plus-ws (mixed market-data push)

HTTP requests + WebSocket subscriptions concurrently.

```ts
import http from 'k6/http';
import ws from 'k6/ws';
import { check } from 'k6';

export const options = {
  scenarios: {
    http_poll: {
      executor: 'constant-vus',
      vus: 100,
      duration: '300s',
      exec: 'httpPoll',
      tags: { scenario: 'http-plus-ws-http' },
    },
    ws_stream: {
      executor: 'constant-vus',
      vus: 50,
      duration: '300s',
      exec: 'wsStream',
      tags: { scenario: 'http-plus-ws-ws' },
    },
  },
  thresholds: {
    'http_req_duration{scenario:http-plus-ws-http}': ['p(95)<200'],
    ws_session_duration: ['p(95)>250000'],  // WS session MUST hold ≥ 250s
    http_req_failed: ['rate<0.01'],
  },
};

export function httpPoll() {
  const res = http.get(`${__ENV.API_BASE}/tickers/BTCUSDT`);
  check(res, { '200': (r) => r.status === 200 });
}

export function wsStream() {
  const url = `${__ENV.WS_BASE}/market?symbol=BTCUSDT`;
  ws.connect(url, null, (socket) => {
    socket.on('message', (msg) => {
      check(msg, { 'has payload': (m) => m.length > 0 });
    });
    socket.setTimeout(() => socket.close(), 270_000);
  });
}
```

**Typical params**: HTTP VU 100 + WS VU 50, same steady-state duration.

---

## Pattern C — staged-ramp-up (capacity limit)

Staged ramp to find the system knee.

```ts
import http from 'k6/http';

export const options = {
  scenarios: {
    capacity: {
      executor: 'ramping-arrival-rate',
      startRate: 10,
      timeUnit: '1s',
      preAllocatedVUs: 200,
      maxVUs: 2000,
      stages: [
        { duration: '60s', target: 100 },
        { duration: '60s', target: 500 },
        { duration: '60s', target: 1000 },
        { duration: '60s', target: 2000 },
        { duration: '30s', target: 0 },
      ],
      tags: { scenario: 'capacity-ramp' },
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<800'],
    http_req_failed: ['rate<0.05'],
  },
};

export default function () {
  http.get(`${__ENV.API_BASE}/health`);
}
```

**Typical params**: ramp from `startRate` up to `maxVUs`, 60s per stage; watch which stage first breaks a threshold.

---

## Selection Guide

| Scenario | Pattern |
|---|---|
| Paired requests (place order / cancel / withdraw) | A |
| Market-data push / IM / subscription | B |
| Capacity-ceiling search / pre-release load test | C |

Combined use: a single `.k6.ts` may declare multiple `scenarios`, each tied to a different pattern.
