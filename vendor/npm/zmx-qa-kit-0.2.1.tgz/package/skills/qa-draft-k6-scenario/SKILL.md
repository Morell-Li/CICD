---
name: qa-draft-k6-scenario
description: Draft a k6 TypeScript performance scenario from either natural-language (VU / duration / rampUp / target endpoints) or case.md contract blocks (TC-3xx interface-contract sections), emitting thresholds (p95/p99/error-rate) and tags back-referencing TC-NNN. Use when the user runs /qa:draft-perf, asks to "写一个 k6 压测场景", "case.md 接口转 k6", or needs a starter for the k6-perf preset. 起草 k6 压测脚本 / threshold 必填 / TC-3xx 契约回标.
priority: 30
allowed-tools: "Bash(qa-kit:*) Read Write"
metadata:
  preset: k6-perf
  ownerTool: qa.draftK6Scenario
  category: qa-authoring
---

# qa-draft-k6-scenario — k6 load-test script draft

## Responsibility

Translate a natural-language load-test scenario ("write a 1000VU / 10min ramp for the order endpoint") into a `qa-perf/scenarios/<name>.k6.ts` skeleton with `scenarios / stages / thresholds / tags`, passing the `k6-script-parse` + `scenario-schema` gate.

## When to Use

- User runs `/qa:draft-perf <natural language>`
- Scenario draft before establishing a performance baseline for a new feature
- Existing scenario must be rewritten against new VU / target endpoints

**Do NOT use for**:
- Load-test failure diagnosis (type-2 preset has no Heal hook; diagnosis goes through `qa-analyze-perf`)
- Functional correctness tests (go through `qa-draft-e2e-spec` + web-e2e preset)

## Input

```ts
type DraftK6Input = {
  description?: string;         // natural-language scenario description (traditional input)
  caseMdPath?: string;          // optional: specs/<feature>/case.md, consumes TC-3xx contract blocks
  tcRange?: 'contract' | [number, number];  // default 'contract', reads frontmatter.idRange.contract
  targetPath: string;           // qa-perf/scenarios/<name>.k6.ts
  vus?: number;                 // peak VU, default 100
  durationSec?: number;         // steady-state duration, default 300
  rampUpSec?: number;           // ramp-up duration, default 60
  endpoints?: Array<{ method: 'GET'|'POST'|'PUT'|'DELETE'; path: string; weight?: number }>;
  wsEndpoints?: string[];       // optional: WebSocket scenarios
  thresholds?: {
    p95Ms?: number;
    p99Ms?: number;
    errorRate?: number;         // 0-1
  };
};
```

At least one of `description` / `caseMdPath` MUST be provided. When both given, `caseMdPath` dominates and `description` supplements semantics.

## Output

- Single `qa-perf/scenarios/<name>.k6.ts`（与 `qa-kit test --preset k6-perf` 默认扫描目录一致；**不要**写到 `tests/perf/` 之类的非标准路径） <!-- lint-doc-ignore -->
- Top-level `options` object with `scenarios` / `stages` / `thresholds` / `tags`
- `default export` or named export matches scenario `exec`
- Passes `k6 inspect` syntax check (MCP-side gate)

## Steps (rubric)

### Branch A: input has `caseMdPath` → contract-block driven

1. Read `caseMdPath`, get frontmatter.idRange.contract range (default [300, 399])
2. Filter all leaves whose TC `id` falls in that range, group by parent `##### 接口描述：METHOD /path` node
3. For each interface contract block, extract key info from the 10 points:
   - 请求方式 → `method` + `Content-Type` header
   - 请求体 → payload schema (field name / type / required)
   - 预期状态码 → `check((r) => r.status === 200)`
   - 边界条件验证 (TC-3x7) → generate a boundary sub-scenario or drive via `sharedIterations`
4. Each scenario's `tags` back-references the original TC-NNN, so blob reporter can aggregate by TC: `tags: { scenario: '...', tc: 'TC-300,TC-301,...' }`
5. Pick one pattern per `references/k6-script-patterns.md` (typical contract load uses `staged-ramp-up`)
6. Threshold MUST still be declared per `references/threshold-schema.md`; missing → gate rejects
7. For VU / duration not present in the contract block, use input defaults and explicitly state "came from default" in the LLM reply

### Branch B: traditional natural-language draft

1. **Decompose natural language into structured scenario**: extract peak VU / ramp-up / steady state / target endpoint list / error-rate target. Missing fields take defaults and the LLM reply MUST explicitly state "default source".
2. **Pick pattern**: one of three per `references/k6-script-patterns.md`:
   - `placement-cancel`: place-cancel loop (matching-engine class)
   - `http-plus-ws`: mixed HTTP + WebSocket (market data push class)
   - `staged-ramp-up`: staged ramp (capacity-limit class)
3. **Threshold required**: declare `http_req_duration{p95,p99}` + `http_req_failed` + `checks` per `references/threshold-schema.md`. **A scenario without thresholds is rejected by the gate**.
4. **Tag convention**: `tags: { scenario: '<name>', product: 'zmx', env: 'staging' }`; tags are later used by blob reporter for aggregation.
5. **Account pool reuse**: for login-required tests, lease `perf-<role>` tag accounts via `qa.leaseAccount`; NEVER hardcode credentials in the script.
6. **Do NOT write Heal logic**: type 2 forbids AI fixing the script (`k6-perf.md` §4); this skill drafts only, failures escalate.
7. **Persistence protocol**: `qa.draftK6Scenario` goes through **dry-run + apply** (type-2 scripts are executable TS; still require Verify Loop = tsc + k6-inspect).

## Division of Labor

- Scenario syntax check (`k6 inspect`) is a programmatic gate; **the LLM MUST NOT declare "syntax OK"**
- Threshold declaration is a scenario required component; absence is NOT a "style issue" but a hard gate failure
- This skill keeps the existing **dry-run + apply + Verify Loop** flow; the `caseMdPath` branch only adds a **data source**, no change to persistence protocol
- `scripts/` directory (pattern renderer / k6 import fixer) is a **P0 follow-up wave**

## Fallback Protocol

- Phase 1: LLM reads case.md directly to extract TC-3xx contract blocks; no parser invocation
- Phase 2: once MCP tool `qa.draftK6Scenario`'s `caseMdPath` param plugs in the case-md parser, switch back to programmatic path; this SKILL rubric remains LLM fallback

## Cross References

- `../qa-design-test-cases/SKILL.md` — upstream (case.md producer, includes 10-point contract)
- `../qa-design-test-cases/references/test-case-schema.md` §5.4 interface contract block
- `../../rules/qa-html-tag-contract.md` — TC-NNN / 分类 / 维度 extraction contract
- `docs/presets/k6-perf.md` §8 workflow / §10 k6 runner interface
- `docs/runners/k6.md` (if present; P0 follow-up)
- `references/k6-script-patterns.md` / `references/threshold-schema.md`
- `rules/qa-runner-k6.md` (added this wave)
