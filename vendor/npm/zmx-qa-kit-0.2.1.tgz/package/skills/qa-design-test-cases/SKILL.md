---
name: qa-design-test-cases
description: Design structured test cases from PRD markdown, using v5 four-grid business structure (C-end/B-end × frontend/backend) with engineering labels (TC-NNN stable IDs, coverage dimensions). Output follows test-case-design preset v2.0 schema. Use when user runs /qa:design, asks "按业务模块设计用例", "从 PRD 写用例", "design test cases from PRD". 从 PRD 起草结构化模块用例 md / v2.0 四格 + 工程标签.
priority: 30
allowed-tools: "Bash(qa-kit:*) Read Write"
metadata:
  preset: test-case-design
  ownerTool: qa.designTestCases
  category: qa-authoring
---

# qa-design-test-cases — PRD → module test-case md (v2.0 four-grid + engineering labels)

## Responsibility

Translate a PRD into one or more structured module test-case markdown files. **Skeleton follows the v5 four-grid business view** (`## 业务模块` → `### C端/B端/纯后端` → `#### 前端功能交互测试 / #### 后端业务逻辑测试`). **Engineering labels sink into trailing HTML-comment annotations** (`<!-- id:TC-001 | 分类:等价类 | 维度:status=active -->`) so they do not pollute Chinese headings. The artifact conforms to the test-case-design preset v2.0.

## When to Use

- User runs `/qa:design <prd.md>`, or says "按业务模块设计用例" / "从 PRD 写用例"
- Requirements review is done; draft an initial test-case file in one pass
- An old `test-cases.md` is stale and must be rewritten against the new PRD

**Do NOT use for**:

- Drafting Playwright spec.ts (that's `qa-draft-e2e-spec`)
- Reviewing coverage of existing test cases (that's `qa-review-coverage`)
- Drafting load-test scenarios (that's `qa-draft-k6-scenario`)
- XMind delivery pipeline (a separate pipeline extension, out of this skill's scope)

## Input Contract

```ts
type DesignInput = {
  prdPath: string;            // 用户自备的 PRD md 绝对/相对路径，任意目录；qa-kit 不规定 PRD 位置（PRD 是输入不是产出）
  feature: string;            // kebab-case；作为 case md 基名 `qa-design/cases/<feature>.md`
  productVersion: string;
  project?: string;           // business project name (写进 frontmatter)
  module?: string;            // business module name (single-module 时可由 PRD 推断省略)
  jira?: string | null;
};
```

## Output Contract

路径一律以 **`qa-design/cases/`** 起始（test-case-design preset 的 canonical source dir；见 `src/core/layout.ts#DESIGN.cases`）：

- **Single module**（默认）: `qa-design/cases/<feature>.md`（扁平命名；下游 `/qa:author-xmind` 按同基名产 `<feature>.xmind.md`）
- **Multi-module**（PRD 里有 > 1 个独立业务模块才用）: `qa-design/cases/<feature>/{module}.md`（嵌套时 author-xmind 仍按同基名产 `{module}.xmind.md`）
- **不要** 写到 `specs/`（根下）或 `qa-design/cases/<feature>/test-cases.md` 这种老嵌套路径 —— 会让 xmind 流找不到
- Each file has two sections separated by `---`:
  - Upper = requirements analysis (with `【原文 L…】` anchors and the mandatory `## ⚠️ 文档中不清楚或缺失的内容` section)
  - Lower = test cases (v5 four-grid)
- frontmatter schema v2.0 (see `references/test-case-schema.md`)
- Phase-1 output does **NOT** pass the legacy `markdown-schema` gate (that gate enforces the old TC-NNN heading form); phase-2 validator will adapt to v2.0

## Steps (rubric)

### 1. Read PRD Acceptance Criteria

Scan the PRD's "验收标准" / "Acceptance Criteria" section. **If the PRD has no AC, first ask the user to add AC before continuing**; do NOT push forward.

### 2. Module Independence Judgment (hard criteria)

Any feature meeting **any one** of the following MUST be promoted to a top-level `## 模块`; NEVER compress into a sub-block:

1. Independent top-level entry (Tab / nav item / secondary route)
2. Independent API prefix (e.g. `/order-cancel/*` vs `/refund/*`)
3. Independent rule system (independent formulas / reward system / data model)
4. Independent business closure (can complete a full business flow on its own)

当模块数 > 1 时，拆成 `qa-design/cases/<feature>/{module}.md`（**feature 为目录，每个 module 是独立 md 文件**）；否则单文件 `qa-design/cases/<feature>.md`（扁平，无中间目录）。

### 3. Skeleton-First Protocol

**First emit the full heading skeleton only** (down to `####`, no leaves), then self-check:

- frontmatter schemaVersion='2.0' complete
- Four-grid `C端` / `B端` complete (empty ends still keep a `####` shell with a placeholder)
- 10 `######` contract sub-nodes under the interface block
- Fixed four-grid order: 时间轴 (optional) → C端 → B端; inside each end, frontend → backend

Only fill leaves after skeleton is confirmed. See `references/module-golden-template.md` as the authoritative shape.

### 4. Business-Param Matrix → Four Case Classes

Fill cases along the v5 four-grid structure:

- **等价类**: at least 1 valid + 1 invalid class per input dimension. See `references/equivalence-class-rubric.md`
- **边界值 7-point**: for continuous boundaries (amount / count / time window), generate `min-1 / min / min+1 / nominal / max-1 / max / max+1` per `references/boundary-value-rubric.md`
- **异常路径**: at least 1 each for network failure / permission denied / concurrent conflict / illegal state-machine transition
- **Interface 10-point contract**: under `#### 后端业务逻辑测试`, use `##### 接口描述：METHOD /path` hanging 10 `######` nodes

### 5. ID Allocation Decision Table

| Case type | Needs ID? | ID range (3-digit default) |
|---|---|---|
| 等价类 normal case | As needed (required if automated / linked to Jira / in regression set) | 001-099 |
| 边界值 | Recommended | 100-199 |
| 异常路径 | Recommended | 200-299 |
| Interface contract (each of 10 points) | Required | 300-399 |
| 页面UI整体走查 | Optional | — |
| Placeholder cases (`（本模块无…）`) | Optional | — |
| Pure one-off manual walkthrough | Optional | — |

ID range is read from frontmatter `idRange`; out-of-range triggers a warning. Large projects may use `idWidth: 4` to switch to TC-NNNN.

ID goes into an **HTML comment at end of the same line** as the heading:

```markdown
##### 取消 active 状态订单 <!-- id:TC-001 | 分类:等价类 | 维度:status=active,role=owner -->
```

### 6. Dimension Coverage

Write key input dimensions (status / role / amount / time window) into the `维度:k=v` annotation segment, `,` separating multiple keys. Consumed by CoverageDoctor for matrix comparison.

### 7. TBD and Anchors

- **Requirements-analysis section** allows `【原文 L…】` source anchors (`L12` = PRD line 12)
- **Test-case section forbids** `【原文 L…】`
- Inline open questions: `（文档未明确，需确认）` (fullwidth punctuation)
- Hard open questions that need PM closure: `<!-- TBD:#X | ... -->`, see `../../rules/qa-tbd-lifecycle.md`

### 8. Self-Check (LLM runs before delivery)

- [ ] frontmatter `schemaVersion: '2.0'` complete
- [ ] Requirements-analysis section contains the mandatory `## ⚠️ 文档中不清楚或缺失的内容`
- [ ] `---` separator present
- [ ] Test-case section top heading is `# {项目}｜{模块} 测试用例`
- [ ] C端 / B端 four-grid complete; empty ends use `##### （本模块无 X 端 Y 功能）` placeholder with three lines filled
- [ ] `#### 前端功能交互测试` MUST precede `#### 后端业务逻辑测试`
- [ ] `### C端` MUST precede `### B端`; `### 时间轴` if present MUST be first
- [ ] `##### 页面UI整体走查` fixed name, placed under C端 frontend; may contain just 步骤 + 预期 two lines
- [ ] 10 `######` contract sub-nodes under the interface block, exact names (请求方式 / 登录态 / 请求体 / 预期状态码 / 预期响应 / 必填参数缺失验证 / 错误码验证 / 边界条件验证 / 未登录状态验证 / 异常展示验证)
- [ ] Leaf keys 前置条件 / 步骤（或 触发方式）/ 预期结果, fullwidth colon 「：」
- [ ] No `TC-xxx` as heading prefix (IDs live only in the trailing HTML comment)
- [ ] No `P0` / `P1` / `P2` / `P3` / `[高]` / standalone "优先级" fields
- [ ] No Markdown table pipes `|`
- [ ] No numbered section prefixes (`1.1` / `2.1.1`)
- [ ] IDs within their designated range, unique within file
- [ ] Every English identifier annotated with Chinese meaning on first use (see `../../rules/qa-no-fabrication.md`)

### 9. Fallback Protocol

- Phase 1 does **NOT** call MCP tool `qa.designTestCases` (schema is stale)
- LLM writes the v2.0 artifact directly via the Write tool
- Phase 2 switches back to the MCP path once validator / designer adapts to v2.0

## Division of Labor

- This skill is the **LLM propose side**. Schema / coverage-matrix checks are programmatic actions (phase 2 via `qa.validateTestCaseMd`); the LLM MUST NOT self-declare "schema passes"
- Coverage review goes through `qa-review-coverage`, not in scope here
- Phase 1 has no script support; the LLM manually aligns shape to the golden template

## Cross References

- `references/test-case-schema.md` — machine-readable v2.0 schema definition
- `references/module-golden-template.md` — authoritative golden template for shape; read before writing
- `references/equivalence-class-rubric.md` / `references/boundary-value-rubric.md` — leaf-label heuristics
- `../../rules/qa-no-fabrication.md` — anti-fabrication hard rules
- `../../rules/qa-tbd-lifecycle.md` — TBD annotation lifecycle
- `../../rules/qa-conventions.md` — qa-kit global conventions
