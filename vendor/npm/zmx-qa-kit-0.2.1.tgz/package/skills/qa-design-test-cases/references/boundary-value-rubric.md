# Boundary Value 7-Point Method

## Core Idea

Defects cluster **near the boundary**. For every dimension with continuous or ordered values, sample at 7 points:

```
[ min-1 ]  [ min ]  [ min+1 ]  [ nominal ]  [ max-1 ]  [ max ]  [ max+1 ]
  invalid    valid    valid      typical        valid     valid    invalid
```

## Applicable Dimensions

- **Numeric**: amount / quantity / leverage multiplier / page number / rate-limit threshold
- **Time window**: validity start/end / TTL / rollback window
- **Length**: string length / array length / file size
- **Time instant**: 1 second before effective time / effective instant / 1 second after
- **Permission level**: permission value / VIP tier / whitelist cutoff

**Not applicable**: enum types (use 等价类 partitioning); boolean (only two values, no "boundary" concept).

## 7-Point Template

| Point | Meaning | Expected |
|---|---|---|
| `min - 1` | Below lower bound | Reject / error |
| `min` | Exactly lower bound | Accept (open/closed per PRD) |
| `min + 1` | Just past lower bound | Accept |
| `nominal` | Typical value | Accept, happy path |
| `max - 1` | Just below upper bound | Accept |
| `max` | Exactly upper bound | Accept (open/closed per PRD) |
| `max + 1` | Above upper bound | Reject / error |

## Example: Order Amount `0 < amount ≤ 10000`

| TC No. | amount | Expected |
|---|---|---|
| 边界-1 | `0` | Reject (lower bound open) |
| 边界-2 | `0.01` | Accept |
| 边界-3 | `0.02` | Accept |
| 边界-4 | `100` (nominal) | Accept |
| 边界-5 | `9999.99` | Accept |
| 边界-6 | `10000` | Accept (upper bound closed) |
| 边界-7 | `10000.01` | Reject |

## Open / Closed Intervals Must Be Read From PRD

Whether `min` / `max` is valid in the 7 points depends on the PRD's open/closed declaration:
- `0 < x ≤ max` → `min = minimum valid value` (e.g. 0.01), `max = 10000` valid
- `0 ≤ x < max` → `min = 0` valid, `max = 9999.99` valid

**If PRD does not state open/closed, ask the user to clarify before writing the TC**; do NOT guess.

## Precision and Units

- Currency / decimal: the "1" in `min - 1` = minimum precision unit (e.g. `0.01`), not integer 1
- Time: millisecond / second as minimum unit; state timezone explicitly
- Length: distinguish character vs byte (UTF-8 Chinese = 3 bytes)

## Self-Check

- [ ] Every numeric / length / time dimension has 7-point coverage?
- [ ] Open / closed intervals match the PRD?
- [ ] Precision units stated (`0.01` not `1`)?
- [ ] Boundary TCs aggregated under the `## 边界值` section in test-cases.md?

## Simplification

When `max` is unreachable for a dimension (e.g. `unsigned int max`) or the PRD has no upper bound: keep only `min - 1 / min / min + 1 / nominal`, and note "no upper bound" in the TC. Missing 7 points does NOT count as `missing-boundary-value` as long as the upper value is business-unreachable.
