# Equivalence Class Partitioning Rubric

## What Is an Equivalence Class

On one input dimension, the set of inputs **handled by the same business logic branch** forms one equivalence class. Pick a single representative from each class; no need to exhaust.

## Partitioning Steps

1. **Identify input dimensions**: every business parameter in the PRD is a dimension (amount, order status, user role, time window, feature flag, context state).
2. **Partition by business branch**: read the PRD's acceptance criteria (AC) and branch logic; each `if / else / switch case` maps to one class.
3. **Valid + invalid classes**: every dimension MUST produce at least 1 "valid class (happy path)" + 1 "invalid class (error path)".
4. **Mutual exclusion**: classes have empty intersection; do NOT put `active` and `canceled` into one class.
5. **Completeness**: the union of all classes = the dimension's full value space; anything left over MUST be absorbed into some "invalid" / "exception" class.

## Dimension Example: Order-Cancel API

| Dimension | Valid classes | Invalid classes |
|---|---|---|
| Order status | `active` (cancellable) | `canceled` / `completed` / `refunding` (each is an independent invalid class, do NOT merge) |
| User role | `owner` (own order) | `other-user` / `admin` (cross-permission) |
| Amount | `0 < x ≤ maxPerOrder` | `x ≤ 0` / `x > maxPerOrder` |
| Idempotency key | First request | Repeat request (MUST return same result) |

## Common Anti-Patterns

- **Merging mutually exclusive states**: stuffing `canceled` and `refunding` into one "non-active" class → hides illegal state-machine transition bugs
- **Ignoring null / default**: many APIs miss the "field absent" path, which is an independent class
- **Class = single value**: if a class has only one representative, the dimension is too fine-grained; it might be a boundary, not a class
- **Missing "idempotency" dimension**: any idempotency-key-supporting API MUST have "first / repeat" as two classes

## Self-Check

- [ ] Every input dimension has at least 2 classes listed?
- [ ] Invalid classes cover all "non-valid" values (not just one kind of invalid)?
- [ ] Any mutually exclusive states wrongly merged?
- [ ] Any missing null / default / idempotency / context-state dimensions?
- [ ] Every class has at least 1 representative TC in test-cases.md?

## Mapping to coverage-class

- Rubric detects unpartitioned dimension → `missing-coverage`
- Mutually exclusive states merged → `invalid-equivalence-class`
- Two TCs represent the same class with the same value → `duplicate-coverage`
