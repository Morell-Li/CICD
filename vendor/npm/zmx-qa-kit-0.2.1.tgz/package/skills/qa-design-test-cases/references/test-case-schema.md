# test-cases.md schema v2.0 (v5 four-grid + engineering labels)

> Machine-readable definition. LLM and validator both align to this file. Shape sample: `module-golden-template.md`.

## 1. File-Level Overview

```text
---
<frontmatter v2.0>
---

# {项目}｜{模块}

## {模块}
### C 端（用户端）
#### 前端部分
  ...
#### 后端部分
  ##### 业务逻辑 / ##### 接口信息
### B 端（管理后台）
### 纯后端

## ⚠️ 文档中不清楚或缺失的内容
- ...

---

# {项目}｜{模块} 测试用例

## {模块}
### 时间轴                ← optional
- ...
### C端
#### 前端功能交互测试
##### 页面UI整体走查
#### 后端业务逻辑测试
##### ...
##### 接口描述：POST /xxx
###### 请求方式
...（10 items）
### B端
#### 前端功能交互测试
#### 后端业务逻辑测试
```

**Two-section hard rules**:

- Upper section MUST end with `## ⚠️ 文档中不清楚或缺失的内容` (NEVER delete)
- `---` separator occupies its own line
- Lower section top heading MUST be `# {项目}｜{模块} 测试用例`

## 2. Frontmatter Field Table

```yaml
---
schemaVersion: '2.0'
productVersion: '2.4.0'
project: 'order-system'
module: 'order-cancel'
feature: 'order-cancel'
jira: 'PROJ-123'
idWidth: 3
idRange:
  equivalence: [1, 99]
  boundary: [100, 199]
  exception: [200, 299]
  contract: [300, 399]
---
```

| Field | Type | Required | Description | Example |
|---|---|---|---|---|
| `schemaVersion` | string | Yes | Fixed `'2.0'` | `'2.0'` |
| `productVersion` | string | Yes | Target version | `'2.4.0'` |
| `project` | string | Yes | Business project name (qq dimension) | `'order-system'` |
| `module` | string | Yes | Business module name (qq dimension) | `'order-cancel'` |
| `feature` | string | Yes | kebab-case, path use (matches directory) | `'order-cancel'` |
| `jira` | string\|null | Yes | Jira ticket or `null` | `'PROJ-123'` |
| `idWidth` | 3 \| 4 | No | ID digit count; default 3 | `3` |
| `idRange.equivalence` | `[int, int]` | No | 等价类 range | `[1, 99]` |
| `idRange.boundary` | `[int, int]` | No | 边界值 range | `[100, 199]` |
| `idRange.exception` | `[int, int]` | No | 异常路径 range | `[200, 299]` |
| `idRange.contract` | `[int, int]` | No | Interface contract range | `[300, 399]` |

## 3. Requirements-Analysis Section Rules

- Organize by business module (`## {模块}`); within a module write `### C 端 / ### B 端 / ### 纯后端` at the same level
- Within each end use `#### 前端部分` / `#### 后端部分`; under 后端部分 use `##### 业务逻辑` / `##### 接口信息`
- **Allowed**: `【原文 L12】` anchors (`L12` = PRD line 12), only in this section
- UI mockup recognition results blend into C-end 前端部分; do NOT create a standalone section
- **Required final section** `## ⚠️ 文档中不清楚或缺失的内容`: list ambiguities / gaps / conflicts / who must confirm what
- Sub-blocks use `#### 子区块:[子模块名]`, deeper nesting `##### 子区块:...`

## 4. Test-Case Section Rules

Hierarchy:

```text
# {项目}｜{模块} 测试用例
└── ## {模块}
    ├── ### 时间轴                     ← optional, unordered list only
    ├── ### C端
    │   ├── #### 前端功能交互测试
    │   │   ├── ##### 页面UI整体走查    ← two lines allowed (步骤 + 预期)
    │   │   └── ##### ...              ← three lines (前置 + 步骤 + 预期)
    │   └── #### 后端业务逻辑测试
    │       ├── ##### ...              ← 触发方式 may substitute 步骤
    │       └── ##### 接口描述：...     ← interface block, 10 ###### children
    └── ### B端
        ├── #### 前端功能交互测试
        └── #### 后端业务逻辑测试
```

**Hard ordering rules**:

- 时间轴 (if present) → C端 → B端
- Within each end: 前端功能交互测试 → 后端业务逻辑测试
- NEVER reverse; NEVER delete the `####` shell (empty ends get a placeholder)

**Forbidden**: `【原文 L…】` anchors in this section.

## 5. Leaf Forms

### 5.1 Normal Case (three lines)

```markdown
##### 正常取消 active 状态订单 <!-- id:TC-001 | 分类:等价类 | 维度:status=active,role=owner -->
- 前置条件：用户已登录；订单状态 = `active`（可取消）
- 步骤：进入订单详情页 → 点击"取消订单" → 确认弹窗
- 预期结果：订单状态变为 `canceled`（已取消），退款流程触发，列表页状态同步更新
```

### 5.2 页面UI整体走查 (two lines)

Fixed name `##### 页面UI整体走查`, placed under C端 → `#### 前端功能交互测试`:

```markdown
##### 页面UI整体走查
- 步骤：打开订单详情页
- 预期结果：顶部导航 / 订单卡片 / 操作按钮区 三区齐全；金额格式 `¥0.00`；文字无截断
```

### 5.3 Backend Non-Interface (触发方式 substitutes 步骤)

```markdown
##### 超过 24 小时自动关闭未支付订单 <!-- id:TC-050 | 分类:等价类 | 维度:time_window=>24h -->
- 前置条件：存在未支付订单，创建时间 > 24 小时前
- 触发方式：定时任务 `orderCloseJob` 调度执行
- 预期结果：订单状态更新为 `closed`（已关闭）；推送关闭通知
```

### 5.4 Interface Contract Block (no three-line template)

```markdown
##### 接口描述：POST /order/cancel
###### 请求方式 <!-- id:TC-300 | 分类:契约 -->
- POST，Content-Type: application/json
###### 登录态 <!-- id:TC-301 | 分类:契约 -->
- 必须携带 `Authorization: Bearer <token>`
###### 请求体 <!-- id:TC-302 | 分类:契约 -->
- `orderId`（订单 ID）: string, 必填
- `reason`（取消原因）: string, 选填
###### 预期状态码 <!-- id:TC-303 | 分类:契约 -->
- 200 成功；4xx 业务错误；5xx 系统错误
###### 预期响应 <!-- id:TC-304 | 分类:契约 -->
- `{ code: 0, data: { orderId, status: 'canceled' } }`
###### 必填参数缺失验证 <!-- id:TC-305 | 分类:契约 -->
- 缺 `orderId` → 400，错误码 `PARAM_MISSING`
###### 错误码验证 <!-- id:TC-306 | 分类:契约 -->
- 订单不存在 → `ORDER_NOT_FOUND`；状态非可取消 → `ORDER_STATE_INVALID`
###### 边界条件验证 <!-- id:TC-307 | 分类:契约,边界值 -->
- `orderId` 长度超限 / 特殊字符 / 空串
###### 未登录状态验证 <!-- id:TC-308 | 分类:契约,异常路径 -->
- 无 token → 401；token 过期 → 401 + `TOKEN_EXPIRED`
###### 异常展示验证 <!-- id:TC-309 | 分类:契约,异常路径 -->
- 500 时前端 Toast 显示"系统繁忙，请稍后再试"
```

**The 10 names MUST be exact**: 请求方式 / 登录态 / 请求体 / 预期状态码 / 预期响应 / 必填参数缺失验证 / 错误码验证 / 边界条件验证 / 未登录状态验证 / 异常展示验证. Never miss one, never rename.

### 5.5 Placeholder Case

When one end has no content at all:

```markdown
##### （本模块无 B 端 前端功能）
- 前置条件：本模块未对管理后台开放前端交互
- 步骤：不适用
- 预期结果：不适用
```

**NEVER** delete the `#### 前端功能交互测试` / `#### 后端业务逻辑测试` shell.

## 6. HTML Comment Tag Syntax

### 6.1 Trailing Tag (same line as heading)

```
<!-- id:TC-001 | 分类:等价类 | 维度:status=active,role=owner -->
```

| Key | Optional | Values |
|---|---|---|
| `id` | Yes | `TC-NNN` or `TC-NNNN` (by frontmatter `idWidth`) |
| `分类` | Yes (required when `id` present) | `等价类` / `边界值` / `异常路径` / `契约` single or combined (`,` separated) |
| `维度` | No | `k=v`, multiple keys `,` separated (e.g. `status=active,role=owner`) |

### 6.2 TBD Comment (own line)

```
<!-- TBD:#X | 询问对象 | 状态 | 问日期 | 回答 -->
```

Details in `../../rules/qa-tbd-lifecycle.md`.

### 6.3 Parsing Rules

- Trailing tag MUST be on the **same line** as `#####` or `######` heading
- TBD comment occupies its own line, adjacent (above or below) to the placeholder line it annotates
- MUST NOT be inserted between leaf bullets (`- 前置条件:...`)
- Multiple keys within a comment separated by ` | ` (space + pipe + space)

## 7. ID-Range Rules

- Read from frontmatter `idRange`; defaults when absent (3-digit: 1-99 / 100-199 / 200-299 / 300-399)
- Large projects may use `idWidth: 4`, ranges configurable (e.g. `[1, 999]`)
- Out-of-range requires a stated reason in the `## ⚠️` section; phase-2 validator warns
- IDs unique within a file; multi-file scenarios avoid collisions via `project + module`

## 8. Hard Prohibitions (full list)

**Heading layer**:

- ❌ `TC-xxx` as heading prefix (IDs live only in HTML comment trailing tag)
- ❌ `P0` / `P1` / `P2` / `P3` / `[高]` / `[中]` / `[低]`
- ❌ Standalone line `- **优先级**：...`
- ❌ Numbered section prefixes (`1.1` / `2.1.1`)
- ❌ `【原文 L…】` anchor in the test-case section
- ❌ Deleting the `####` shell of an empty end

**Format layer**:

- ❌ Markdown tables (pipe `|`); use only `#` ~ `######` + `-` list
- ❌ Leaf-key variants: `操作步骤` / `执行步骤` / `操作:` / `结果:`
- ❌ ASCII colon `:` in place of fullwidth `：`
- ❌ Rewriting / missing the 10 interface contract names
- ❌ Renaming `##### 页面UI整体走查` to "UI 走查" / "页面 UI 检查"

**Content layer**:

- ❌ Fabricating pages / fields / interfaces / rules / roles / flows / copy not in the doc (see `qa-no-fabrication`)
- ❌ English identifier first occurrence without Chinese-meaning annotation
- ❌ Generating cases for Redis / cache middleware implementation details

## 9. Minimal Full Example (skeleton + representative leaves)

See `module-golden-template.md` (complete sample, 5-8 cases covering all forms).

## 10. Anti-Pattern Table

| ❌ Wrong | ✅ Correct |
|---|---|
| `##### TC-001 取消订单` | `##### 取消订单 <!-- id:TC-001 | 分类:等价类 -->` |
| `- 优先级：P0` | (delete; P0-P3 comprehensively forbidden) |
| `- 操作步骤：...` | `- 步骤：...` |
| `- 预期: ok` | `- 预期结果：订单状态变为 canceled（已取消）,退款触发` |
| `## 1.1 取消订单` | `## 取消订单` |
| Table `\| 用例 \| 预期 \|` | `##### 用例标题\n- 前置条件：...\n- 步骤：...\n- 预期结果：...` |
| Empty end deletes `#### 后端业务逻辑测试` | Keep shell + `##### （本模块无 B 端 后端业务用例）` placeholder |
| bare `status` | `status（订单状态）` |
| `##### UI 走查` | `##### 页面UI整体走查` |
| Interface block with only 5 `######` | All 10 contract sub-nodes MUST be covered |
