# perf-class 触发规则映射

## 六类触发表

| perf-class | 触发条件（任一满足即触发） | 默认 confidence |
|---|---|---|
| `threshold-breach` | k6 summary 里任一 threshold `fails: > 0` 或 `ok:false` | 0.95 |
| `error-rate-spike` | `http_req_failed.rate > errorRateLimit`（默认 0.01，spec 可覆盖） | 0.9 |
| `saturation` | 外部 saturationHint=true（P1：Prom 饱和度信号接入） | 0.8 |
| `p95-degradation` | baseline 存在 **且** bootstrap CI 判 regression（current > upper）**且** deltaRatio > tolerance | 0.75 |
| `insufficient-samples` | baseline samples 数量 < `MIN_SAMPLES_FOR_BOOTSTRAP`（5）；回归判定不可靠 | 0.6 |
| `test-infra-issue` | k6 binary 找不到 / summary 缺失 / 脚本解析失败（runner 侧探测） | 0.95 |
| `unknown` | 无上述任一信号 | 0 |

## 优先级（多触发时取最严重）

```
test-infra-issue > threshold-breach > error-rate-spike > saturation > p95-degradation > insufficient-samples > unknown
```

实现见 `src/core/classifier/perf-class.ts`。优先级的判断顺序就是代码里 if-early-return 的顺序。

## 为什么 `threshold-breach` 最高优先级

- threshold 是业务方声明的"绝对合格线"，超出即业务未达标
- 这类失败**不需要 baseline 对照**，直接 escalate
- 即便 p95-degradation 也叠加触发，报告里仍以 `threshold-breach` 为主类，但在 evidence 里并列列出

## 各类 handoff 行为

**类型 2 preset 不挂 Heal**，所有类都走 escalate，区别在 owner 与动作：

| perf-class | Owner 建议 | 动作 |
|---|---|---|
| `threshold-breach` | SRE + 负责开发 | 查容量 / 依赖服务 / 配置变更 |
| `p95-degradation` | 负责开发 | diff 近期代码变更找回归点 |
| `error-rate-spike` | SRE | 查依赖服务健康 / 限流策略 |
| `saturation` | SRE | 扩容 / 限流调整 |
| `test-infra-issue` | QA 平台 owner | 修脚本 / 扩 runner 资源（允许人改，不 AI 改） |
| `insufficient-samples` | QA | 累积更多历史 run；< 5 个 baseline 判定不可靠 |
| `unknown` | QA | 加长压测窗口 / 建 baseline |

## 阈值参数（可在 `.zmx-tools-config.json` 覆盖）

```json
{
  "qaKit": {
    "perf": {
      "degradationPct": 0.10,
      "errorRateSigma": 3,
      "errorRateAbsolute": 0.05,
      "saturationOccupancy": 0.20,
      "minSamplesForCI": 100,
      "bootstrapIters": 1000
    }
  }
}
```

## 对 handoff card 的影响

- `threshold-breach` / `error-rate-spike` / `saturation` → handoff 标"**紧急**"
- `p95-degradation` → 标"**回归**"（24h 内响应）
- `test-infra-issue` → 标"**QA 平台**"
- `unknown` → 标"**信息不足**"，要求重跑更长窗口

## 反模式

- 用 `p95-degradation` 当兜底类（应该用 `unknown`）
- 不区分 threshold-breach 和 baseline 对照（threshold 是硬合格线，baseline 是回归对照，二者独立）
- baseline 缺失时硬算 CI（bootstrap 结果不可信）

## 交叉引用

- `docs/ai-workflow/failure-class.md` §perf-class
- `docs/presets/k6-perf.md` §5 perf-class 分类
- `references/bootstrap-ci-method.md`
