# Bootstrap 置信区间 — qa-kit 实装说明

## 约束先行

k6 `summary.json` **不含原始响应时间样本**，只给聚合统计（p50/p95/p99/...）。
"raw-sample bootstrap" 需要每次请求的响应时间，qa-kit 不把 `--out json=raw.json`
作为默认产物（体积巨大）。所以 qa-kit 的 bootstrap 走 **跨 run** 方案：

- baseline 文件存**历史 N 次 run 的 p95 点估计**（每次 run 一条）
- 用这 N 个点估计做重采样，给出"baseline 分布"的置信区间
- current run 的 p95 超出 CI 上界 → 判定回归

优点：summary.json 就够用、实现简单、统计上合理（各 run 独立同分布）。
代价：需要积累 ≥5 次历史基线（< 5 时退化到固定容忍度）。

## 算法

```
输入: baselineSamples[] = [p95_run1, p95_run2, ..., p95_runN]
      current = 本次 run 的 p95 点值
      B = 1000（重采样次数）
      confidence = 0.95

if N < 5:  # MIN_SAMPLES_FOR_BOOTSTRAP
    返回 insufficient-samples；退到固定 tolerance 判定
    (current - mean(baseline)) / mean(baseline) > tolerance → regression

else:
    stats = []
    for b in 1..B:
        resample = sample_with_replacement(baselineSamples, N)
        stats.push(mean(resample))       # 默认 mean；也可以选 median
    sort(stats)
    lower = percentile(stats, 0.025)
    upper = percentile(stats, 0.975)
    if current > upper → regression
    else → ok
```

## 源码位置

- `src/core/perf/bootstrap-ci.ts` 里 `bootstrapCI()` / `compareAgainstBaseline()`
- `src/core/mcp/tools/qa-analyze-perf.ts` handler 调用处

## baseline 文件格式

```json
{
  "schemaVersion": 1,
  "metric": "http_req_duration",
  "stat": "p(95)",
  "samples": [450, 462, 455, 470, 448, 458, 461],
  "createdAt": "2026-04-24T..."
}
```

- `samples` 推荐；`value`（单点）保留向后兼容
- 由 CLI（P3 的 `qa-kit perf baseline save`）追加，每次 run 完成后 opt-in 写入

## 确定性 / 可测试性

- 实现用 LCG 伪随机（seed 可传），便于单测复现
- 默认 `seed = 1`；生产分析 LLM 不需要在意，reproducibility 对 QA 报告够用

## 判定语义

| 分支 | verdict | classifier 输入 |
|---|---|---|
| current ≤ upper | ok | deltaRatio（可能仍 > tolerance，但 bootstrap 更权威） |
| current > upper | regression | p95Delta = deltaRatio，触发 p95-degradation |
| N < 5 & 超 tolerance | regression | p95Delta = deltaRatio + insufficientSamples=true |
| N < 5 & 在容忍内 | ok | insufficientSamples=true（降低 unknown 优先级） |

## 与 classifier 的优先级交互

`perf-class.ts` 优先级：
```
threshold-breach > error-rate-spike > saturation > p95-degradation > insufficient-samples > unknown
```

即使 bootstrap 判 regression，如果同时有 threshold-breach / error-rate-spike，
classifier 会用更高优先级的类（因为"原始硬信号"比"对比信号"更明确）。

## 反模式

- ❌ 用 t-test：响应时间长尾，违反正态假设
- ❌ 比较均值：p95 才反映尾延迟，业务侧关心的就是尾
- ❌ 单 run baseline 就判回归：无法区分自然抖动，容易报假阳
- ❌ 把 bootstrap 应用到 summary 内部的 avg/std（那是样本内；我们做的是跨 run）

## 样本量经验

| N 基线 | 建议 |
|---|---|
| 1-4 | 退到固定 tolerance，标 insufficient-samples |
| 5-10 | bootstrap 可用，但 CI 偏宽；阈值判定会偏保守（假阴）|
| 10-30 | 推荐区间 |
| >30 | CI 收敛，可考虑降低 B（e.g. 500） |
