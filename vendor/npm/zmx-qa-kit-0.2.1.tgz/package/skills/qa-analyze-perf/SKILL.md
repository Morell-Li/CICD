---
name: qa-analyze-perf
description: Analyze a k6 summary.json (with optional baseline) using bootstrap-CI to compute p95 delta and assign perf-class (threshold-breach / p95-degradation / error-rate-spike / saturation / test-infra-issue / unknown). Use when the user runs /qa:analyze-perf or a perf run finishes and needs regression verdict.
priority: 30
allowed-tools: "Bash(qa-kit:*) Read"
metadata:
  preset: k6-perf
  ownerTool: qa.analyzePerf
  category: qa-analysis
---

# qa-analyze-perf — k6 报告分析与回归判定

## 职责

输入 k6 的 `summary.json`（可选带 baseline），输出：
- 各 endpoint / scenario 的 p95 / p99 / error-rate 汇总
- 对比 baseline 的 **bootstrap 置信区间**（95% CI）+ p95-delta（绝对 + 百分比）
- `perf-class` 判定（`threshold-breach` / `p95-degradation` / `error-rate-spike` / `saturation` / `test-infra-issue` / `unknown`）
- 是否需要生成 Lark / Jira 转交卡（类型 2 所有失败都走 escalate，不走 propose）

## 何时使用

- 用户敲 `/qa:analyze-perf <summary.json>`
- k6 scenario 跑完，CI 自动触发回归判定
- 发布前 go/no-go 评估

**不用于**：
- 功能正确性失败（那是 7 类 failureClassifier + `qa-explain-failure`）
- 压测脚本修复（类型 2 禁止 AI 改脚本）

## 输入

```ts
type AnalyzeInput = {
  summaryPath: string;            // k6 summary.json
  baselinePath?: string;          // qa-perf/eval/baseline.json
  thresholds?: Record<string, { p95Ms?: number; p99Ms?: number; errorRate?: number }>;
  bootstrapIters?: number;        // 默认 1000
};
```

## 输出

```ts
type AnalyzeReport = {
  summary: Array<{
    scenario: string;
    endpoint?: string;
    p95Ms: number;
    p99Ms: number;
    errorRate: number;
    reqsPerSec: number;
  }>;
  delta: Array<{
    scenario: string;
    baselineP95Ms: number;
    currentP95Ms: number;
    deltaMs: number;
    deltaPct: number;
    ci95: [number, number];      // bootstrap 95% CI of delta
    significant: boolean;         // CI 不跨 0 → 显著
  }>;
  perfClass: 'threshold-breach' | 'p95-degradation' | 'error-rate-spike' | 'saturation' | 'test-infra-issue' | 'ok' | 'unknown';
  handoffRequired: boolean;
  evidence: string[];
};
```

## 操作步骤（rubric）

1. **先判 threshold-breach（硬失败）**：任一 k6 `thresholds` 在 summary.json 里 `fails: > 0` → `perf-class = threshold-breach`；不做 CI 比较，直接转交。
2. **拉 baseline**：若 `baselinePath` 存在，读 p95 样本分布；否则 `perf-class` 只能判 `threshold-breach` / `ok`（首次跑不判 degradation）。
3. **bootstrap-CI 计算 delta**：按 `references/bootstrap-ci-method.md` 对 `currentP95 - baselineP95` 做 1000 次 bootstrap，取 95% CI。CI 不跨 0 且 `deltaPct > 10%` → `p95-degradation`。
4. **error-rate-spike**：`currentErrorRate > baselineErrorRate + 3σ` 或绝对值 `> 0.05` → 记 `error-rate-spike`。
5. **saturation**（若 summary 含系统指标）：CPU / 内存 / 连接数 ≥ 90% 持续时间占比 > 20% → `saturation`。
6. **test-infra-issue**：k6 自身异常（OOM / scenario 未启动 / script parse 错）→ `test-infra-issue`；注意此类 AI 可以提建议（但修脚本仍需人审，不自动 apply）。
7. **unknown 兜底**：以上都不触发且 baseline 存在 → `ok`；baseline 缺失且无 threshold-breach → `unknown`（非错误，是"信息不足"）。
8. **handoffRequired**：`perf-class ∈ {threshold-breach, p95-degradation, error-rate-spike, saturation}` → `true`；产出 handoff card（类型 2 所有失败都 escalate）。

## perf-class 优先级（同一轮多触发时取最严重）

1. `threshold-breach`
2. `error-rate-spike`
3. `saturation`
4. `p95-degradation`
5. `test-infra-issue`
6. `unknown`
7. `ok`

详见 `references/perf-class-mapping.md`。

## 分工提醒

- bootstrap-CI 计算、threshold 比对、CI 跨 0 判定都是**程序化**（ADR-021 D2）；LLM 不自己算百分位。
- `qa.analyzePerf` MCP tool 承载实际计算；本 skill 负责"把结果翻译给用户"（类似 `qa-explain-failure` 对类型 2 的角色）。
- 类型 2 **不挂 Heal**，本 skill 不产 patch 指令，只产报告 + 转交卡。
- `scripts/bootstrap.ts`（P0 简化版 bootstrap 实现）**P0 后续 wave 实施**。

## 交叉引用

- `docs/presets/k6-perf.md` §6 Eval 策略 / §7 指标
- `docs/ai-workflow/failure-class.md` §perf-class
- `references/bootstrap-ci-method.md` / `references/perf-class-mapping.md`
- `rules/qa-runner-k6.md`
