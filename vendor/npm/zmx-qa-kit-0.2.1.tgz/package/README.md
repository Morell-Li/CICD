# @zmx/qa-kit

> 多范式 AI 原生 QA 基建：Core 原子能力 + Preset 组合（测试用例设计 / E2E / 压测）

本仓库是 **qa-kit 的维护者仓库**。qa-kit 是一套基础设施（infra）包，不包含业务代码；真实业务场景发生在下游项目 `qa-kit init` 之后的消费者仓库里。

## 这是什么

qa-kit 交付 6 件东西：

1. **`src/` 下的 TypeScript 库代码** — 发布为 `@zmx/qa-kit` npm 包，含 parser / validator / 18 个 MCP tool / runners / presets / CLI / perf 核心（spec-schema / spec-schema-v2 / bootstrap-CI / hook-runner / prom-fetch / summary-shape / verdict / fixtures-schema / dashboard-decoder / long-tail / perf-run-report / baseline-accumulate）+ proto 反射（`src/core/proto/reflection.ts`）+ 安全（`src/core/security/baseline-token.ts` HMAC 双签）
2. **`skills/` / `rules/` / `commands/` / `mcp/` 下的 AI 组件** — 由 `aibundle` 分发到各 IDE 原生位置（Claude Code / Cursor / Copilot / Codex / Gemini）
3. **`perf-helpers/` 业务中性 k6 helper 库** — 由 k6-perf preset 通过 `preset-lib` 模板下发到消费者 `qa-perf/lib/`（k6 runtime 读文件路径，不走 node_modules）；含 `thinkTime/tags/correlation/pool/metrics/token-pool/debug` + `protocols/{http,grpc,grpc-int64}`
4. **一个 CLI（`qa-kit` bin）** — `init / doctor / validate / test / eval / report / explain / accounts / perf / proto / bootstrap / codegen / mcp` 等工具命令
5. **一个 MCP server** — `npx @zmx/qa-kit mcp` 启动 stdio 子进程，向 IDE LLM 暴露工具（mutating 类走 `_meta.runId + idempotencyKey` 幂等）
6. **契约层**（代码级稳定接口）— TC-NNN ID 格式 + HTML 注释标签语法 + frontmatter schema + perf-spec.yaml schema；下游工作流依赖它，允许 AI 组件 md 自由迭代零代码成本

**v0.2.0 关键升级**（schema-additive，不破坏既有契约）：

- 🚨 修复 k6 v1.7 `handleSummary` 阈值解析（v0.1.x 误报全部 `ok:true`）。真实 testnet 数据（617 400 iter，5/8 阈值越界）经 3 轮独立 drill 验证准确。**v0.1.x 用户必须升级**。
- 新增 gRPC 工具链：`qa-kit validate --proto-reflection` + `qa-kit proto fetch` + `perf-helpers/protocols/grpc-int64.ts`（int64 显式 opt-in，不再有 `*Id` 启发式）
- 新增 gates：`dead-metric`（C1）/ `fixtures-schema` 含 `_qaKit.uniqueBy`（C2）/ `proto-drift`（自动触发）
- HMAC 双签：`qa-kit perf baseline reset` 与 `qa-kit eval promote` 强制两阶段 `--request → --confirm-token`
- MCP input-guard 加固：`qa.applyHealDiff` / `qa.poolRelease` / `qa.releaseAccount` 改返结构化 `MISSING_INPUT` / `LEASE_NOT_FOUND` / `ACCOUNT_NOT_FOUND`
- 新增报表：`qa-kit report decode-dashboard | perf-run | long-tail` + `qa-kit perf analyze --output` + `qa-kit perf baseline accumulate`
- 交互菜单补齐 v0.2.0 全部新能力（perf 子菜单加 `analyze` / `proto-fetch`，`baseline` 加 `accumulate / reset 双签`，`report` 升级为子菜单含三剑客），`eval-promote / baseline-reset` 双签共用 `double-sign.ts` helper；旧版 inline 英文 prompt 全部移到 `copy.ts` 中文化

详见 [`CHANGELOG.md`](./CHANGELOG.md)；端到端真实演练实证融入在 [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md)。

## 三工作流（消费者视角）

```
1. Design:
   PRD ─/qa:design─→ case.md ─/qa:review-coverage─→ /qa:author-xmind
                                                         │
                                          ─ qa-kit report xmind ─→ .opml ─→ .xmind

2. E2E:
   case.md + xmind.md + 设计稿 ─/qa:draft-e2e─→ spec.ts ─/qa:heal─→ 回归自动化

3. Perf:
   perf-spec.yaml(声明式契约) / case.md(TC-3xx) / 自然语言
          │
          ├── qa-kit proto fetch ──→ qa-perf/proto/*.proto（gRPC 反射，v0.2.0）
          │
          ├──/qa:draft-perf──→ k6.ts (含 options + scenarios + thresholds + handleSummary)
          │
          ├── qa-kit test run ──→ qa-results/perf/summary.json
          │
          ├── qa-kit perf baseline save | accumulate --runs N
          │                            ──→ samples[]（≥5 触发 bootstrap CI）
          │
          ├── qa.runHooks (pre_flight / post_run + as_metric 捕获)
          │
          ├── qa-kit perf prom-fetch ──→ prom-snapshot.json（服务端指标）
          │
          ├──/qa:analyze-perf [--output json] ──→ 7 类 perf-class + bootstrap 95% CI
          │
          └── qa-kit report {decode-dashboard | perf-run | long-tail}
                                          ──→ md/json 报告（v0.2.0）

变更类操作（HMAC 双签，v0.2.0）：
   qa-kit perf baseline reset --request --reason "..." → token
   qa-kit perf baseline reset --confirm-token <token>
   qa-kit eval promote --preset <p> --request --reason "..." → token
   qa-kit eval promote --preset <p> --confirm-token <token>
```

完整说明见 [`SKILLS.md`](./SKILLS.md)、[`docs/OVERVIEW.md`](./docs/OVERVIEW.md) 与 [`docs/QA-TEAM-DEMO.md`](./docs/QA-TEAM-DEMO.md)（操作清单 / 回归 checklist）。

## 快速开始（维护者视角）

```bash
# 安装依赖（私有 registry,需要 authToken,见"发布"章节）
pnpm install

# 开发
pnpm dev              # builder dev,watch 模式
pnpm typecheck        # tsc --noEmit
pnpm test             # vitest run(96+ case)
pnpm test:watch

# 构建
pnpm build            # builder build,输出 dist/

# 发布（patch 自增）
pnpm publish:pkg

# 发布（其它模式）
pnpm publish:pkg -- --bump minor
pnpm publish:pkg -- --bump none       # 保持当前版本号
pnpm publish:pkg -- --tag beta
pnpm publish:pkg -- --dry-run

# 撤回已发布版本（仅 72h 内可撤,交互式）
pnpm unpublish:pkg
```

## 仓库结构

```
qa-kit/
├── package.json                    # @zmx/qa-kit npm 包声明,含 7 个 exports 入口
├── builder.config.ts               # 构建配置(7 入口 ESM+CJS,rolldown via @zmx/builder-cli)
├── tsconfig.json                   # 开发期 tsconfig(strict,noEmit)
├── tsconfig.build.json             # 构建期 tsconfig
├── tsdown.config.ts                # tsdown 备用构建配置(fallback)
├── .npmrc                          # 私有 registry 配置(authToken 不在此)
├── .gitignore                      # 含 node_modules/dist/.env/.auth 等
│
├── README.md                       # 本文件(维护者视角)
├── SKILLS.md                       # aibundle discovery 清单(skills/commands/rules/mcp 元数据)
│
├── src/                            # TypeScript 源码
│   ├── index.ts                    # 包主入口
│   │
│   ├── core/                       # 核心能力 + 契约层 + MCP 实现
│   │   ├── case-md-parser.ts       # ★ case.md 解析器(契约核心,下游都吃它)
│   │   ├── case-md-validator.ts    # ★ 契约断言型校验(TC-NNN 唯一性/号段/注释格式)
│   │   ├── define-preset.ts        # defineQaPreset() — preset 组合工厂
│   │   ├── index.ts / types.ts / layout.ts / project-root.ts
│   │   │
│   │   ├── mcp/                    # MCP server 实现
│   │   │   ├── server.ts           # stdio server 入口
│   │   │   ├── tool-registry.ts    # tool 注册器
│   │   │   └── tools/              # 18 个 MCP tool(qa.* 命名;17 实装 + 1 stub)
│   │   │       ├── qa-design-test-cases.ts
│   │   │       ├── qa-review-coverage.ts       # 接入 case-md-parser
│   │   │       ├── qa-draft-e2e-spec.ts        # 接入 case-md-parser
│   │   │       ├── qa-draft-k6-scenario.ts     # 接入 case-md-parser
│   │   │       ├── qa-heal.ts / qa-apply-heal-diff.ts
│   │   │       ├── qa-analyze-perf.ts / qa-run-k6.ts / qa-run-test.ts
│   │   │       ├── qa-pool-lease.ts / qa-pool-release.ts     # ★ 业务中性账号池租借(推荐)
│   │   │       ├── qa-lease-account.ts / qa-release-account.ts # deprecated shim,向后兼容
│   │   │       ├── qa-run-hooks.ts             # ★ perf hooks(pre_flight/post_run) 执行器
│   │   │       ├── qa-validate-spec.ts         # annotation 真校验(ts-morph AST)
│   │   │       ├── qa-export-to-testrail.ts    # stub,NOT_IMPLEMENTED_P1
│   │   │       ├── qa-capabilities.ts / qa-ping.ts
│   │   │       └── _shared.ts
│   │   │
│   │   ├── perf/                   # ★ 压测核心(Phase 2+3 + v0.2.0)
│   │   │   ├── spec-schema.ts      # perf-spec.yaml 声明式契约 schema
│   │   │   ├── spec-schema-v2.ts   # ★ v0.2.0:dead-metric 检测(C1)
│   │   │   ├── load-spec.ts        # perf-spec loader + meta.id 推断
│   │   │   ├── bootstrap-ci.ts     # 基线历史 → bootstrap 95% 置信区间
│   │   │   ├── baseline-accumulate.ts  # ★ v0.2.0:`baseline accumulate --runs N`
│   │   │   ├── hook-runner.ts      # shell/http/wait hook 执行 + as_metric 捕获
│   │   │   ├── prom-fetch.ts       # Prometheus query_range 快照
│   │   │   ├── summary-shape.ts    # ★ v0.2.0 P0:k6 v1.7 handleSummary 形状契约
│   │   │   ├── verdict.ts          # ★ v0.2.0:Verdict 联合(baseline-warming/insufficient-samples/ok/improved/regressed)
│   │   │   ├── fixtures-schema.ts  # ★ v0.2.0:fixtures _qaKit.uniqueBy 校验(C2)
│   │   │   ├── dashboard-decoder.ts    # ★ v0.2.0:k6 web-dashboard NDJSON 反解码
│   │   │   ├── long-tail.ts        # ★ v0.2.0:dashboard 时序长尾离群检测
│   │   │   └── perf-run-report.ts  # ★ v0.2.0:模板化压测报告(§1-§4 自动填)
│   │   │
│   │   ├── proto/                  # ★ v0.2.0:gRPC 反射工具
│   │   │   └── reflection.ts       # 本地 .proto vs server reflection schema 比对(纯 Node,无 grpcurl 依赖)
│   │   │
│   │   ├── security/               # ★ v0.2.0:HMAC 双签
│   │   │   └── baseline-token.ts   # baseline reset / eval promote 双签(secret 自动生成 + gitignore)
│   │   │
│   │   ├── harness/                # 起稿/执行/修复等"回路式"编排
│   │   │   ├── draft-harness.ts    # E2E/k6 起稿 + Verify Loop
│   │   │   ├── heal-harness.ts     # 失败 → heal prompt → apply diff 回路
│   │   │   ├── run-harness.ts      # 统一测试执行入口
│   │   │   ├── coverage-doctor-harness.ts   # 覆盖率审查(legacy)
│   │   │   ├── doctor-harness.ts   # 健康自检
│   │   │   ├── test-case-draft-harness.ts
│   │   │   └── load-reference.ts
│   │   │
│   │   ├── verify/                 # Verify Loop 实现
│   │   │   ├── verify-loop.ts
│   │   │   ├── gates/              # tsc / playwright-list / k6-inspect / scenario-schema(perf-spec gate)
│   │   │   └── util/
│   │   │
│   │   ├── classifier/             # 失败分类器(7 类)
│   │   │   ├── default-7class.ts           # E2E 失败分类
│   │   │   ├── flutter-7class-extended.ts
│   │   │   ├── perf-class.ts               # perf 7 类(threshold-breach/p95-degradation/...)
│   │   │   ├── coverage-class.ts
│   │   │   └── index.ts
│   │   │
│   │   ├── reporters/              # 产物导出器
│   │   │   └── xmind/              # md → OPML/原生 .xmind ZIP
│   │   │       ├── md-to-opml.ts
│   │   │       ├── md-to-xmind.ts
│   │   │       ├── minimal-zip.ts
│   │   │       └── index.ts
│   │   │
│   │   ├── accounts/               # 账号池(proper-lockfile 原子锁)
│   │   ├── commands/test-run/      # e2e/k6 测试执行命令实现
│   │   ├── metrics/                # 指标采集/聚合/写入
│   │   ├── eval/                   # Fixture/评测
│   │   ├── memory/                 # 持久化记忆(selector 缓存等)
│   │   ├── mock/                   # 网络/全局 mock handler
│   │   ├── data-cleaner/           # afterEach 脏数据清理协议
│   │   ├── business-summary/       # 业务摘要渲染(HTML)
│   │   ├── validate/               # annotation-schema 校验
│   │   ├── doctor/                 # doctor + doc-lint(路径 drift 扫描)
│   │   ├── explain/                # unified diff 结构解析
│   │   ├── presets/                # preset registry
│   │   ├── cli-shared/             # CLI 通用工具(spawn/format/interactive/run-contract)
│   │   └── diff/                   # apply-diff 基础
│   │
│   ├── cli/                        # qa-kit bin 命令行入口
│   │   ├── index.ts                # commander 主入口
│   │   ├── commands/               # 13 个子命令:
│   │   │                           #   init / bootstrap / doctor / validate / test / eval
│   │   │                           #   report / explain / mcp / accounts / codegen / perf
│   │   │                           #   proto-fetch (★ v0.2.0:qa-kit proto fetch)
│   │   │                           # 其中 perf.ts = baseline save/list/show + accumulate + reset 双签
│   │   │                           #               + analyze --output + prom-fetch
│   │   │                           # report.ts 新增 decode-dashboard / perf-run / long-tail 子命令
│   │   ├── menu/                   # 交互式菜单(clack wizard 体系,21 个 wizard;v0.2.0 全中文化)
│   │   │   ├── double-sign.ts      # ★ v0.2.0:HMAC 双签流复用 helper(eval-promote + baseline-reset)
│   │   │   └── wizards/            # init / accounts / e2e-run / perf-run / perf-baseline(+accumulate/+reset)
│   │   │                           # perf-prom-fetch / perf-report(子菜单分发) / perf-analyze(★ v0.2.0)
│   │   │                           # perf-reports(★ v0.2.0:decode-dashboard / perf-run / long-tail)
│   │   │                           # proto-fetch(★ v0.2.0) / metrics / metrics-tail
│   │   │                           # eval-run / eval-promote(用 double-sign helper) / validate / xmind / codegen
│   │   │                           # explain-diff / summary / reducer / ...
│   │   └── templates/              # qa-kit init 下发给消费者的模板(15 个)
│   │                               #   playwright-config / agents-md / auth-setup
│   │                               #   perf-spec-templates / preset-lib(业务中性 helper 分发)
│   │                               #   demo-spec / eval-fixtures / husky-pre-commit / misc ...
│   │
│   ├── runners/                    # 测试 runner 适配
│   │   ├── web/                    # Playwright adapter + qa-kit-metrics reporter
│   │   └── k6/                     # k6 adapter
│   │
│   └── presets/                    # 三类 preset
│       ├── web-e2e/                # exec-correctness(Playwright)
│       ├── test-case-design/       # design(PRD → case.md)
│       └── k6-perf/                # exec-non-correctness(k6 压测)
│
├── perf-helpers/                   # ★ 业务中性 k6 helper 库(源)
│   │                               # 由 k6-perf preset 通过 preset-lib 模板下发到消费者 qa-perf/lib/
│   │                               # 维护者在此维护真源,不同步发布 npm(k6 runtime 读文件路径,不读 node_modules)
│   ├── index.ts                    # barrel export
│   ├── thinkTime.ts                # 思考时间 / 随机抖动
│   ├── tags.ts                     # scenario tag / group tag 统一命名
│   ├── correlation.ts              # request 间值关联(提取 token / id 跨步骤)
│   ├── pool.ts                     # 数据池轮询(fixtures 批量消费)
│   ├── metrics.ts                  # 自定义 k6 metric 封装
│   ├── token-pool.ts               # ★ v0.2.0:prefetchTokenPool token 预取池
│   ├── debug.ts                    # ★ v0.2.0:QA_K6_DEBUG=1 标准化调试(每 VU 首次迭代打印 method/req/status)
│   └── protocols/
│       ├── http.ts                 # HTTP 压测协议封装
│       ├── grpc.ts                 # gRPC 压测协议封装(snake_case → lowerCamelCase 自动映射)
│       └── grpc-int64.ts           # ★ v0.2.0:int64/uint64/sint64 显式 opt-in(int64Fields / int64Suffix)
│
├── tests/                          # vitest 单测(60 files / 331 tests as of v0.2.0)
│   ├── case-md-parser.test.ts / case-md-validator.test.ts
│   ├── perf-analyze.test.ts / perf-analyze-handlesummary.test.ts (★ P0 回归)
│   ├── perf-analyze-output-flag.test.ts
│   ├── perf-bootstrap-ci.test.ts / baseline-accumulate.test.ts
│   ├── perf-hook-runner.test.ts / perf-prom-fetch.test.ts
│   ├── perf-spec-schema.test.ts / perf-spec-dead-metric.test.ts(C1)
│   ├── perf-scenario-schema-gate.test.ts / perf-draft-spec-branch.test.ts
│   ├── perf-dashboard-decoder.test.ts / perf-long-tail.test.ts / perf-perf-run-report.test.ts
│   ├── perf-helpers-grpc.test.ts / perf-helpers-token-pool.test.ts
│   ├── proto-reflection.test.ts / proto-drift-gate.test.ts
│   ├── security-baseline-token.test.ts / security-baseline-reset-flow.test.ts / security-secret-resolution.test.ts
│   ├── eval-promote-arg-order.test.ts / draft-k6-scenario-context.test.ts
│   ├── fixtures-schema-validator.test.ts(C2)
│   ├── template-run-perf-shell.test.ts / template-scenario-env.test.ts
│   ├── validate-cli-integration.test.ts
│   ├── mcp/                        # case-md-tools / pool-tools / run-hooks / validate-spec
│   │                               # apply-heal-diff-input-guard / pool-release-input-guard
│   │                               # release-account-input-guard(★ v0.2.0:input-guard 加固)
│   ├── commands/                   # init-merge / init-k6-perf-scaffold / test-run / perf-baseline
│   ├── menu/                       # entry-gate / file-picker / print-command / visibility
│   │   ├── v0.2.0-wiring.test.ts   # ★ v0.2.0:菜单接线 + 中文化文案守门(8 断言)
│   │   └── wizards/                # accounts / metrics-menu / perf-baseline / perf-prom-fetch
│   │                               # perf-report / eval-promote-wiring
│   ├── integration/                # business-word-grep(铁律:业务词污染回归) / v0.2.0-smoke
│   ├── harness/ / presets/ / doctor/ / reporters/
│
├── rules/                          # AI rules(aibundle 分发到各 IDE)
│   ├── qa-case-md.md               # ★ 契约层规则(case.md frontmatter + TC-NNN + 注释语法)
│   ├── qa-perf-spec.md             # ★ perf-spec.yaml 契约层规则
│   ├── qa-conventions.md           # spec.ts 真源 / annotation / PO / 命名
│   ├── qa-failure-class.md         # 7 类失败分类 rubric
│   ├── qa-preset-types.md          # 三类 preset cheatsheet
│   ├── qa-runner-web.md            # Playwright runner 约定
│   └── qa-runner-k6.md             # k6 runner 约定
│
├── skills/                         # AI skills(每个独立目录,含 SKILL.md + references/)
│   ├── qa-design-test-cases/       # PRD → case.md
│   │   └── references/             # test-case-schema / module-golden-template
│   │                               # boundary-value-rubric / equivalence-class-rubric
│   ├── qa-author-xmind-md/         # case.md → xmind.md
│   │   └── references/             # xmind-md-schema / xmind-md-golden-template
│   ├── qa-review-coverage/         # 覆盖率审查 + 缺口补全
│   │   └── references/coverage-gaps-heuristics.md
│   ├── qa-draft-e2e-spec/          # Playwright spec 起草
│   ├── qa-draft-k6-scenario/       # k6 场景起草(三分支:spec-driven/case.md/simple)
│   │   └── references/             # k6-script-patterns / threshold-schema
│   │                               # perf-spec-template(spec-driven 分支骨架)
│   ├── qa-codegen/                 # Playwright codegen 录制前置 helper
│   ├── qa-heal-spec/               # 失败 → patch 回路
│   ├── qa-explain-failure/         # 失败分类解读
│   ├── qa-analyze-perf/            # k6 报告分析
│   │   └── references/             # bootstrap-ci-method / perf-class-mapping
│   └── qa-lease-account/           # 账号池租借
│
├── commands/qa/                    # IDE slash 命令源文件(13 个,aibundle 分发)
│   ├── design.md                   # /qa:design
│   ├── review-coverage.md          # /qa:review-coverage
│   ├── author-xmind.md             # /qa:author-xmind
│   ├── draft-e2e.md                # /qa:draft-e2e
│   ├── draft-perf.md               # /qa:draft-perf
│   ├── codegen.md                  # /qa:codegen (Playwright 录制起稿)
│   ├── heal.md                     # /qa:heal
│   ├── explain.md                  # /qa:explain
│   ├── analyze-perf.md             # /qa:analyze-perf
│   ├── test.md                     # /qa:test (按 .spec.ts / .k6.ts 后缀推断 preset)
│   ├── report.md                   # /qa:report (含 --kind xmind 出原生 .xmind ZIP)
│   ├── doctor.md                   # /qa:doctor
│   └── validate.md                 # /qa:validate
│
├── mcp/
│   └── qa-kit.yaml                 # MCP server 声明(stdio: npx @zmx/qa-kit mcp)
│
├── scripts/                        # 维护者脚本(不随包发布)
│   ├── publish.js                  # 单包发布(版本号处理 → 构建 → pnpm publish)
│   └── unpublish.js                # 交互式撤回(仅 72h 内,二次确认)
│
├── docs/                           # 架构 / 运营 / 讲述文档
│   ├── OVERVIEW.md                 # 总览(四件套真源 + 三条不可让约束)
│   ├── ADR.md                      # 架构决策记录
│   ├── MAINTAINER-SOP.md           # 维护者 SOP
│   ├── QA-TEAM-DEMO.md             # ★ 操作清单 + 回归 checklist(融入 v0.2.0 真实 drill 实证)
│   ├── CONSUMER-BEST-PRACTICES.md  # ★ v0.2.0:消费方边界外配方(Docker/mirror/SFTP/non-root)
│   ├── ai-workflow/                # qa-workflow/failure-class/harness-advanced/memory/components-architecture/...
│   ├── core/                       # core-runtime-guide/account-pool/schema-version/cheatsheet-business
│   ├── presets/                    # test-case-design/web-e2e/k6-perf/flutter-maestro
│   ├── runners/                    # web/k6/flutter-maestro/cross-browser
│   ├── ops/                        # ci-and-reporting/ci-gates/eslint-plugin/visual-regression/...
│   └── distribution/               # COMPONENTS/AGENTS.md.tpl/INIT-OUTPUT
│
└── design/                         # 设计阶段文档(不随包发布)
    ├── cli-surface.md / command-contract.md
    ├── execution-plan.md / menu-ux.md
```

**核心识别**：

- `★` 标记的文件是**契约层**：`case-md-parser.ts` / `case-md-validator.ts`（case.md 契约）+ `rules/qa-case-md.md` / `rules/qa-perf-spec.md`（规则源）+ `src/core/perf/spec-schema.ts`（perf-spec 契约）+ 新增 pool/hooks MCP tool（业务中性接口）。动它们要升 `schemaVersion` 发 breaking change。
- `src/core/mcp/tools/` 的 tool 和 `skills/` + `commands/qa/` 一一对应,改任一端注意同步。
- `perf-helpers/` 是**源**，由 `src/cli/templates/preset-lib.ts` 在 `qa-kit init --preset k6-perf` 时拷到消费者 `qa-perf/lib/`。改这里会影响下游所有 k6 脚本的 import 路径。
- `src/cli/templates/` 是 `qa-kit init` 下发给消费者的文件模板（.env.example 的规范版本在这里,**不在仓库根目录**）。
- `docs/` 和 `design/` 都不随包发布(见 `files` 字段),只在源码仓库里供维护者查阅。

## 架构核心：契约层 vs Prompt 层

qa-kit 的关键设计：**把"代码稳定契约"和"AI 可迭代 prompt"严格分层**。

| 层                     | 内容                                                                                                                                                                                                                                           | 改动频率 | 影响                                        |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- | ------------------------------------------- |
| **契约层 · case.md**   | parser 认的三件事：<br>① TC-NNN 正则 `/TC-\d{3,4}/`<br>② HTML 注释语法 `<!-- id:xxx \| 分类:yyy \| 维度:k=v,k=v -->`<br>③ YAML frontmatter schema（`schemaVersion: '2.0'` + `feature:`）                                                        | 半年一动 | 动了就是 breaking change,要升 schemaVersion |
| **契约层 · perf-spec** | `perf-spec.yaml` 声明式契约：<br>① `meta.id` + `scenarios[].executor`（enum:constant-vus/ramping-vus/...）<br>② `thresholds` 子指标语法<br>③ `hooks.pre_flight` / `post_run` 结构（shell/http/wait/sql）<br>④ `observability.prometheus.queries` | 半年一动 | 动了升 schemaVersion + scenario-schema gate 同步更新 |
| **Prompt 层**（md）    | `rules/` + `skills/` + `commands/`                                                                                                                                                                                                             | 随时调   | AI 组件自由迭代,代码零改动                  |

外层业务结构（C/B 四格 / 等价类分组 / 接口 10 点契约 / 叶子键名 / 时间轴节 / 压测场景 rubric……）全部在 prompt 层，**改 md 不用动代码**。

详见 [`rules/qa-case-md.md`](./rules/qa-case-md.md)（case.md 契约）与 [`rules/qa-perf-spec.md`](./rules/qa-perf-spec.md)（perf-spec 契约）。

## 维护场景速查

| 想做什么                                  | 动哪里                                                              | 需要懂                                        |
| ----------------------------------------- | ------------------------------------------------------------------- | --------------------------------------------- |
| 加一种新的用例分类（如 `性能`）           | rules + skills md                                                   | parser 天然支持（分类是自由字符串）           |
| 调整四格 / 加时间轴写法                   | skills md + golden template                                         | 不动 src                                      |
| 加一个新 slash 命令                       | `commands/qa/*.md` + 对应 skill                                     | 不动 src                                      |
| 改 TC-NNN 为 TC-NNNNN                     | **契约改动**：parser 正则 + validator + 所有 golden template        | 升 schemaVersion                              |
| 加 HTML 注释新字段（如 `优先级`）         | parser 解析 + `rules/qa-case-md.md`                                 | 升 schemaVersion                              |
| perf-spec 加新 executor / hook 类型       | `src/core/perf/spec-schema.ts` + `rules/qa-perf-spec.md` + hook-runner | 升 schemaVersion + scenario-schema gate 同步  |
| 改 k6 业务中性 helper（thinkTime 等）     | `perf-helpers/**`                                                   | preset-lib 模板 = 源；消费者 `qa-perf/lib/` 是副本 |
| 加新的 MCP tool                           | `src/core/mcp/tools/` + skill rubric + SKILLS.md                    | 参考现有 tool；mutating 类必须走 `_meta` 幂等；入参缺失走结构化 `MISSING_INPUT`，不抛异常 |
| 加 perf 新指标类（threshold 类型）        | `src/core/classifier/perf-class.ts` + analyze tool + perf-class-mapping | 动 classification class 列表要同步文档        |
| 加交互菜单新 wizard                       | `src/cli/menu/wizards/*.ts`                                         | 参考现有 wizard；对应 CLI parity 要保证       |
| 加新 validate gate                        | `src/cli/commands/validate.ts` + `src/core/perf/{spec-schema-v2,fixtures-schema}.ts` 等 | 新 gate 必须可被 `--strict` 升级 warn→error；空项目首次跑必须 0 issue |
| 加新 mutating CLI op（写盘/破坏性）       | `src/core/security/baseline-token.ts` 复用双签                      | 必须双阶段 `--request --reason → --confirm-token`；secret 解析顺序固定 |
| 改 k6 v1.7 summary 解析                   | `src/core/perf/summary-shape.ts` 唯一入口                           | 永远兼容 bare-boolean + 遗留 `{ok}`；stderr 兜底为最高优先级 |
| 改 builder 配置                           | `builder.config.ts`                                                 | `@zmx/builder-cli` 的 `defineConfig`          |
| 发布新版本                                | `pnpm publish:pkg`                                                  | 见"发布"章节                                  |
| 撤回错误发布                              | `pnpm unpublish:pkg`（仅 72h 内）                                   | 见下                                          |

## 发布

### 私有 registry

qa-kit 发布到自建 private npm registry：

```
https://npm.fa6155a11bce5eb246352747007ea5fc.com
```

需要配置 authToken：

```bash
# 本地开发：~/.npmrc 或 项目根 .npmrc.local(已 gitignore)
//npm.fa6155a11bce5eb246352747007ea5fc.com/:_authToken=<your-token>

# CI：通过环境变量 NPM_AUTH_TOKEN 注入
```

### 发布流程 `pnpm publish:pkg`

三步：

1. **版本号处理** — 查远程版本 → `semver.inc` 计算 next → 写回 package.json
2. **构建** — `pnpm build`（可 `--skip-build`）
3. **发布** — `pnpm publish --tag ... --registry ... --access ... --no-git-checks`

参数：

- `--bump <none|patch|minor|major|prerelease>` — 默认 `patch`;`none` 保持当前版本
- `--tag <tag>` — 默认 `latest`，可发 beta
- `--registry <url>` — 覆盖默认 registry
- `--dry-run` — 模拟不推送
- `--skip-build` — 跳过构建步骤

### 撤回流程 `pnpm unpublish:pkg`

npm 规则：**只能撤回 72 小时内发布的版本**，超过即永久锁定。

交互式：

1. 查询远程所有版本 + 发布时间
2. 每个版本标注"可撤回 / 已超时"
3. 选一个 + 二次确认
4. 执行 `npm unpublish <pkg>@<version>`

> ⚠️ 撤回不可逆。已被其它项目 install 的版本撤回会导致下游安装失败。**生产版本严禁撤回**，只撤回明显污染的 beta / 误发版本。

## 测试与契约保障

```bash
pnpm test
# 60 test files / 331 tests(v0.2.0)
# 含 perf 全家桶:spec-schema(v1+v2)/bootstrap-ci/hook-runner/prom-fetch/analyze/
#                handleSummary P0 回归/scenario-schema/dead-metric/fixtures-schema/
#                draft-spec 分支/baseline save+accumulate/dashboard-decoder/long-tail/perf-run-report
# 含 v0.2.0 加固:proto reflection+drift gate/HMAC 双签/MCP input-guard×3/
#                k6 grpc int64+token-pool/template scenario+run-perf
# 含菜单回归:v0.2.0-wiring(交互菜单接线 + 中文化文案守门)/wizard 全套
# 含铁律回归:business-word-grep(全 src/skills/rules/tests/fixtures 业务词污染检测)
# 覆盖 parser / validator / MCP tool(18 个) / reporters / runners / perf / wizard / doctor
```

CI 建议（未来补齐 GitHub Actions 时）：PR 过 `pnpm typecheck` + `pnpm test` + `pnpm build` 三件套才允许合并。

## 依赖说明

### 运行时（dependencies）

- `@zmx/tools-config` — 读取消费者 `.zmx-tools-config.json`
- `@modelcontextprotocol/sdk` — MCP 协议
- `@clack/prompts` / `inquirer` — CLI 交互
- `commander` — CLI 参数解析
- `ts-morph` — TypeScript AST 操作（spec.ts 编辑）
- `proper-lockfile` — 账号池原子锁
- `@grpc/grpc-js` / `@grpc/proto-loader` / `protobufjs` — ★ v0.2.0:gRPC 反射 + proto 加载
- `diff` / `picocolors` — 工具

### 开发时（devDependencies）

- `@zmx/builder-cli` — 构建（`defineConfig` 从 `@zmx/builder-cli/config` 导入；cli 内含 core，不再单独依赖）
- `vitest` — 测试
- `@playwright/test` — peerDep + devDep（本仓库测试也用）
- `semver` / `chalk` / `inquirer` — 发布脚本用

### peerDependencies

- `@playwright/test`（optional）— 仅 web-e2e preset 消费者需要

## AI 组件分发（消费者视角）

qa-kit 不做分发，只生产组件。分发由 `@zmx/aibundle` 负责：

```bash
# 消费者项目里：
pnpm add -D @zmx/qa-kit @zmx/aibundle
aibundle discover              # 扫 node_modules/@zmx/qa-kit/SKILLS.md
qa-kit init                    # 往消费者 .aibundle/ 注入 commands/rules/mcp 映射
aibundle sync                  # 分发到 .claude/ / .cursor/ / .github/ / .gemini/ / AGENTS.md
```

消费者之后就能敲 `/qa:design <prd.md>` 等 slash 命令触发工作流。

## 历史与来源

本仓库从 `zmx-builder` monorepo 的 `libs/qa-kit/` 拆分而来（0.1.0 为首个独立版本）。拆分原因：交付给 QA 团队独立维护。

拆分保留：

- 包名 `@zmx/qa-kit`（下游消费者零感知）
- 发布到原私有 registry
- 所有 rule / skill / command / MCP 组件

拆分后**失去**：

- `zmx-builder` 根的 `pnpm start` 交互菜单（本仓库只关心单包，不需要）
- monorepo 级 `scripts/publish.js` 批量发布能力（本仓库 `scripts/publish.js` 是单包版）
- monorepo 级 CI（本仓库建议按需补齐 GitHub Actions / GitLab CI）

## 贡献指南（维护者必读）

### 改 AI 组件（rules / skills / commands）

- 大多数业务改动应落在 md 层
- 参照现有文件的 frontmatter（name / description / priority / globs / alwaysApply）
- `description` 字段建议**英文主句 + 中文副句**双语，跨 IDE 触发语都命中
- 产物示例（AI 要原样输出的字符串）**必须保留中文**，prose 用英文省 token 稳指令遵循
- 改完跑 `qa-kit doctor --lint-docs` 验证文档里的路径常量和 `src/core/layout.ts` 没有 drift

### 改代码

- `src/core/case-md-parser.ts` / `case-md-validator.ts` / `src/core/perf/spec-schema.ts` 是契约层，改前想清楚影响面（回归矩阵见 `docs/QA-TEAM-DEMO.md`）
- 新增 MCP tool 如是 mutating 性质（写文件 / 改状态 / lease），必须从 `params._meta` 读 `runId + idempotencyKey` 并做幂等
- 所有新公共 API 必须有 vitest 单测
- TypeScript strict mode，no `any`
- commit 前跑 `pnpm typecheck && pnpm test && pnpm build` 三件套

### 版本策略

- 契约层破坏性改动 → 升 minor（0.1.x → 0.2.0）或 major
- 只改 prompt / 加新 skill / 修 bug → 升 patch（0.1.0 → 0.1.1）
- 实验性功能 → `--tag beta` 发布

## License

MIT

## Author

ZMX Builder
