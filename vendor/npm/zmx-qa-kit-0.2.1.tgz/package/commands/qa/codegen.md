---
name: qa:codegen
description: Launch Playwright codegen (web-e2e) or Maestro Studio (flutter-maestro) to record user interactions and seed a spec.
argument-hint: "[--url <target>]"
---

# /qa:codegen

## 入口说明

调起 runner 原生录制工具作为 spec.ts 起稿辅助；录完 LLM 再走 `/qa:draft-e2e` 清洗成合规 spec（带 annotation + PO 复用）。

## 何时用

- 业务 QA 对新功能选择器 / 交互路径不熟，需要可视化录制
- 起草复杂多步骤 E2E 的初稿

## 步骤

1. LLM 调 CLI **`qa-kit codegen [--url]`**（这是 L1，不走 MCP）。
2. CLI 按当前 preset 启动：
   - `web-e2e` → `npx playwright codegen`
   - `flutter-maestro`（P1）→ `maestro studio`
3. 录制完成后，playwright 会把 raw 代码写到 `-o` 指定路径；CLI 不给 `-o` 时默认写到 `qa-e2e/recordings/codegen-<时间戳>.spec.ts`（已默认 gitignore）。路径会打到 stderr 方便立即定位。
4. LLM 读这个文件作为 raw 输入，走 `/qa:draft-e2e` 的流程**清洗** selector（优先 `getByRole` / `data-testid`，复用 PO），补上 `test()` annotation，**清洗合格后再落到 `qa-e2e/tests/`**。未清洗的 raw 永不入 tests/。

## 联动

- **CLI**：`qa-kit codegen`
- **后续 slash**：`/qa:draft-e2e`（把 raw 录制清洗成合规 spec）
- **相关 rule**：`qa-runner-web`（selector 优先级）

## 降级

- 无 playwright / maestro 二进制 → CLI 提示装 runner；本身不需要 MCP。

真源：`docs/runners/web.md` / ADR-027
