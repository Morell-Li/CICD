---
name: qa:draft-e2e
description: Draft or rewrite a Playwright spec.ts from a natural-language requirement or spec.md, via DraftHarness + Verify Loop.
argument-hint: "[qa-e2e/specs/<feature>.md | natural language requirement]"
---

# /qa:draft-e2e

## 入口说明

把用户的自然语言需求或既有 `spec.md` 翻译成可执行 `qa-e2e/tests/**/*.spec.ts`（Playwright testDir），并通过 DraftHarness 的 Verify Loop（tsc + `playwright --list`）。

## 何时用

- 新功能 E2E 的起步（"给 BTC/USDT 现货写一个限价买单测试"）
- 已有 spec.md 需要生成对应 spec.ts
- spec.ts 已存在但需按新需求整段重写

## 步骤

1. IDE LLM 收到 `/qa:draft-e2e <args>`，加载 skill `qa-draft-e2e-spec` 的 rubric。
2. LLM 组装入参后主动调 MCP tool **`qa.draftE2ESpec`**（dry-run）：拿回骨架 + annotation schema + PO manifest。
3. LLM 在自己的回合生成完整 spec.ts。
4. LLM 主动调 `qa.draftE2ESpec`（apply 模式）落盘 + 跑 Verify Loop。
5. Verify 过 → 结束；Verify 失败 → LLM 改 propose 重试（最多 3 轮）。

## 联动

- **Skill**：`qa-draft-e2e-spec`（rubric / PO 复用 / annotation schema）
- **MCP tool**：`qa.draftE2ESpec`（起草 + Verify Loop）
- **相关 rule**：`qa-conventions` / `qa-runner-web`
- **spec.ts 不存在** → 正常起稿；**已存在** → 交互询问用户"合并 / 覆盖 / 取消"（不要默认覆盖）

## 降级

- 无 MCP 环境（Codex / Copilot / Gemini）：LLM 按 skill 的 `scripts/scaffold.ts`（P0 后续）走 Bash 调，Verify 靠 CLI `qa-kit validate <spec>`。

真源：`docs/ai-workflow/qa-workflow.md` §2 / `docs/distribution/COMPONENTS.md`
