---
name: qa:author-xmind
description: Convert a finalized case md into a same-basename tree-shaped `<name>.xmind.md`, preserving TC-NNN labels as node annotations for downstream `qa-kit report xmind` conversion to native .xmind.
argument-hint: "<qa-design/cases/<feature>.md | qa-design/cases/<feature>/{module}.md> [outputPath]"
---

# /qa:author-xmind

## 入口说明

把定稿的 case md（`qa-design/cases/<feature>.md` 或 `qa-design/cases/<feature>/{module}.md`）转成**同基名**的树形 md：`<feature>.xmind.md` / `{module}.xmind.md`，节点带 `[TC-xxx]` 标签。下游由 `qa-kit report xmind` 直接打成原生 `.xmind` 文件（XMind 双击可开）。设计工作流收尾环节。

## 何时用

- `case.md` 定稿（通过 `/qa:review-coverage` 审过覆盖率）后出脑图
- 已有 `xmind.md` 过时，按新 `case.md` 整段重写
- 给 PM / 业务同学快速扫一遍脑图评审

**不适合**：
- 直接生成 `.xmind` 二进制文件（那是外部 xmindmd 工具的事）
- `case.md` 尚未定稿就转（结构会反复变）
- 起草 spec.ts / k6 场景（分别走 `/qa:draft-e2e` / `/qa:draft-perf`）

## 步骤

1. IDE LLM 收到 `/qa:author-xmind <case md> [outputPath]`，加载 skill `qa-author-xmind-md` 的 rubric。
2. LLM 用原生 Read 读 case md，识别 frontmatter + 所有 TC 注释 + headingPath。
3. LLM 按 skill 的转换规则重建树（模块 → C端/B端 → 前端/后端 → 具体用例），TC-NNN 作为 `[TC-xxx]` 标签挂节点末尾。
4. LLM 用原生 Write 落盘到 `outputPath`（默认：**同目录 + 同基名 + `.xmind.md`**）：
   - 源 `qa-design/cases/trade-area.md` → 出 `qa-design/cases/trade-area.xmind.md`
   - 源 `qa-design/cases/login/buyer.md` → 出 `qa-design/cases/login/buyer.xmind.md`
   - **禁止** 产出含混的 `xmind.md`（多 feature 平铺时不可区分）。
5. 人 + AI 调整 `.xmind.md` 内容后 → 跑 `qa-kit report xmind` 产出原生 `.xmind`（`qa-results/design/xmind/<basename>.xmind`，XMind 双击可开）。

## 联动

- **Skill**：`qa-author-xmind-md`（转换 rubric + xmind.md schema）
- **上游**：`/qa:design`（出 case.md）+ `/qa:review-coverage`（审过后定稿）
- **下游**：`qa-kit report xmind` CLI（`.xmind.md` → 原生 `.xmind` ZIP，`qa-results/design/xmind/<basename>.xmind`），或菜单 "Design → 生成 xmind 脑图文件"
- **相关 rule**：`qa-html-tag-contract`（TC-NNN 抽取契约）

## 降级

- 无 MCP 环境：LLM 直接 Read case md + Write `<basename>.xmind.md`，零 tool 依赖（本命令本来就是纯 md 流程，无 MCP tool）。

真源：`libs/qa-kit/skills/qa-author-xmind-md/references/xmind-md-schema.md`
