---
name: qa:analyze-perf
description: Analyze a k6 summary.json against optional baseline with bootstrap-CI, assign perf-class (threshold-breach / p95-degradation / error-rate-spike / saturation / test-infra-issue), and decide if handoff is required.
argument-hint: "<summary.json> [--baseline <baseline.json>]"
---

# /qa:analyze-perf

## 入口说明

`k6-perf` preset 下的压测报告分析入口。读取 k6 `summary.json`（可选 baseline），算 bootstrap 95% CI + p95-delta，判 `perf-class`，决定是否产转交卡。

## 何时用

- k6 scenario 跑完后判"这次是否回归"
- 发布前 go/no-go 评估
- CI 自动门禁（`threshold-breach` 直接 fail build）

**不适合**：
- 功能正确性失败分析（走 `/qa:explain`）
- 压测脚本修复（类型 2 禁止 AI 改脚本）

## 步骤

1. LLM 收到 `/qa:analyze-perf <summary.json>`，加载 skill `qa-analyze-perf`。
2. LLM 调 MCP tool **`qa.analyzePerf`**：入参 `{ summaryPath, baselinePath?, bootstrapIters? }`。
3. MCP 返回 `{ summary, delta, perfClass, handoffRequired, evidence }`（CI 计算完全在 MCP 侧，零 LLM）。
4. LLM 翻译成用户可读报告：
   - 各 endpoint p95 / p99 / error-rate 表
   - 与 baseline 的 delta + CI
   - `perfClass` 判定与证据
5. 若 `handoffRequired = true`，LLM 渲染 handoff card（Lark / Jira 格式），**不渲染 heal prompt**（类型 2 不挂 Heal）。

## 联动

- **Skill**：`qa-analyze-perf`（rubric + bootstrap-CI + perf-class mapping）
- **MCP tool**：`qa.analyzePerf`
- **上游**：`qa.runK6` → summary.json
- **相关 rule**：`qa-runner-k6` / `qa-preset-types`

## 降级

- 无 MCP：LLM 调 Bash `qa-kit analyze --summary <path>`，程序化 CI 计算仍在 CLI 侧；LLM 只管人话翻译。

## 不可让约束

- `perf-class` 判定**必须**由 MCP 程序化出（ADR-021 D2），LLM 不自由判类
- baseline 缺失时退化到 `unknown`，**不编 p95-degradation**
- 所有 `perf-class` 失败走 escalate，**不产 patch**

真源：`docs/presets/k6-perf.md` §6 Eval + §7 指标 / `docs/ai-workflow/failure-class.md` §perf-class
