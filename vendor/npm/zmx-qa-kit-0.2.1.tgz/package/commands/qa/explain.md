---
name: qa:explain
description: Explain a failed test with failureClass + confidence + evidence + 3-choice recommended action. Produces a Lark/Jira handoff card when real-bug / unknown or low-confidence.
argument-hint: "<spec file path>"
---

# /qa:explain

## 入口说明

把一次失败翻译成人话 + 分类结论 + 推荐动作；必要时产出转交卡。**不改代码**（改代码走 `/qa:heal`）。

## 何时用

- 用户问"为什么挂了 / 这是 bug 还是 flaky"
- `/qa:heal` 被 MCP 拒绝 propose（real-bug / unknown）后拿转交卡
- PR 评审时人读失败摘要

## 步骤

1. LLM 调 **`qa.heal`（dry=true）** 或在无 MCP 环境跑 `qa-kit explain diff <file>`。
2. 拿到 `FailureSignal { class, confidence, evidence }` 后，走 skill **`qa-explain-failure`** 的 rubric 组装人话摘要。
3. 展示"推荐动作三选一"：转开发 / 改 spec / 重跑。
4. 若 `class ∈ {real-bug, unknown}` 或 `confidence < 0.5` → 追加转交卡（标题 / 复现 / trace 链接 / failureClass + confidence + evidence / 建议 Owner）。

## 联动

- **Skill**：`qa-explain-failure`（人话翻译）+ `qa-explain-failure`（内部分类）
- **MCP tool**：`qa.heal`（dry 模式）
- **CLI 等价**：`qa-kit explain diff <file>`（程序化 diff 摘要，零 LLM 部分）
- **相关 rule**：`qa-failure-class`

真源：`docs/ai-workflow/failure-class.md` / `docs/ai-workflow/components-architecture.md` §5
