---
name: qa:draft-perf
description: Draft a k6 TypeScript perf scenario from a natural-language description (VU / duration / endpoints / thresholds) under the k6-perf preset.
argument-hint: "<自然语言场景描述> [--vus N] [--duration <Ns|Nm>]"
---

# /qa:draft-perf

## 入口说明

`k6-perf` preset 下的压测 scenario 起稿入口。把自然语言（"给下单接口 1000VU / 10 分钟爬坡"）翻译成 `qa-perf/scenarios/<name>.k6.ts`（与 wizard / `qa-kit test --preset k6-perf` 默认扫描路径一致），带 `options.scenarios` + `thresholds` + `tags`。

## 何时用

- 新功能性能基线建立前的 scenario 起草
- 已有 scenario 按新 VU / 目标端点整段改写

**不适合**：
- 压测失败诊断（类型 2 不挂 Heal；走 `/qa:analyze-perf`）
- 功能正确性测试（走 `/qa:draft-e2e`）

**命名区分**：与 `/qa:design`（类型 3 test-case-design preset）按 runner 上下文或显式 `-perf` 前缀区分（见 `docs/presets/k6-perf.md` §8）。

## 步骤

1. LLM 收到 `/qa:draft-perf <描述>`，加载 skill `qa-draft-k6-scenario`。
2. LLM 拆描述为 `{ vus, durationSec, rampUpSec, endpoints, thresholds }`；缺字段用默认并明示来源。
3. LLM 调 MCP tool **`qa.draftK6Scenario`**（dry-run）：拿回骨架 + pattern manifest。
4. LLM 在自己回合生成完整 `.k6.ts`（按 `k6-script-patterns.md` 三 pattern 挑一）。
5. LLM 调 `qa.draftK6Scenario`（apply 模式）落盘 + 跑 Verify Loop（`tsc` + `k6 inspect`）。
6. Verify 过 → 结束；不过 → 最多 3 轮重试。

## 联动

- **Skill**：`qa-draft-k6-scenario`
- **MCP tool**：`qa.draftK6Scenario`（含 k6 script parse gate）
- **下游**：`qa-kit test --preset k6-perf` + `/qa:analyze-perf`
- **相关 rule**：`qa-runner-k6` / `qa-preset-types`

## 降级

- 无 MCP 环境：LLM 按 references 手工渲染，CLI `qa-kit validate --preset k6-perf <path>` 兜底语法校验。

真源：`docs/presets/k6-perf.md` §8 工作流
