---
name: qa:doctor
description: Run qa-kit environment self-check and forward aibundle doctor's cross-tool capability matrix (shows degradations).
---

# /qa:doctor

## 入口说明

一次性跑 `qa-kit doctor`：检查 qa-kit 自身配置（`.zmx-tools-config.json#qaKit` / `.qa-kit/accounts.json` / `playwright.config.ts` / blob reporter / Lark webhook），并转发 `aibundle doctor` 的跨工具能力矩阵。

## 何时用

- 新机器 / 新项目第一次接入（冒烟"我能跑闭环吗"）
- MCP / skills 疑似不工作（schemaVersion 不匹配 / 账号池文件缺失）
- 团队新人自助诊断

## 步骤

1. LLM 调 CLI **`qa-kit doctor`**（这是 L1，不依赖 MCP）。
2. 展示两段输出：
   - qa-kit 自检：配置缺漏 / schemaVersion 不匹配 / storageState 是否 gitignored。
   - aibundle 转发：当前 IDE 能力矩阵 + 明示降级项（例如 "Copilot 下 `/qa:heal` 需手动贴 bundle markdown"）。
3. 按报告里的 `nextAction` 指引用户一步步修。

## 联动

- **CLI**：`qa-kit doctor` + 内部 call `aibundle doctor` API
- **无需 MCP / skill**（这是 L1 路径，所有工具都能用）

真源：`docs/ops/troubleshooting.md` / `docs/ai-workflow/tool-compatibility.md` §6
