---
name: qa:report
description: Generate qa-kit report (summary HTML by default; metrics JSON or xmind with --kind).
argument-hint: "[--kind summary|metrics|xmind]"
---

# /qa:report

## 入口说明

包装 `qa-kit report <kind>`：
- `summary`（默认）→ 汇总 Playwright JSON 报告为 HTML（红黄绿一眼看），输出到 `qa-results/e2e/summary.html`
- `metrics` → 聚合 `.runtime/metrics/**` 为 JSON 指标集（propose-accepted / MTTR / failure-class 分布等）
- `xmind` → 从 test-cases.md 渲染 XMind 脑图

## 何时用

- 一次跑完想要个人类可读的总览（business QA 场景）
- PR / 日报里贴指标（metrics）
- 产出设计评审材料（xmind）

## 步骤

1. LLM 调 CLI **`qa-kit report [--kind <k>]`**（默认 summary）。
2. 报告落盘后，LLM 告知用户落盘路径 + 关键数字（通过率、耗时、严重失败数）。

## 联动

- **CLI**：`qa-kit report summary` / `metrics` / `xmind`
- **上游**：`qa-kit test run` 产生的 `.runtime/playwright-report.json` / allure-results / metrics JSONL

真源：`docs/ops/ci-and-reporting.md` §reporter-order
