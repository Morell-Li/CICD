---
name: qa:review-coverage
description: Review an existing case md against the PRD using CoverageDoctor; reports missingItems + coverage-class diagnostics, does not auto-fix.
argument-hint: "<feature>"
---

# /qa:review-coverage

## 入口说明

对一个 feature 的 case md + `prd.md` 跑 CoverageDoctor：按等价类 / 边界值 / 异常路径 rubric 计算覆盖矩阵，报缺失 / 重复 / 无效覆盖，输出 `coverage-class` 诊断。**不自动改 case md**；补全由 `/qa:design --overwrite` 执行。

## 何时用

- PR 评审前的覆盖自检（CI 也可 gate 这个）
- 新 PRD 版本发布后，对老 case md 做 diff
- 团队周会评审测试设计健康度

**不适合**：
- 从 0 起稿 TC → `/qa:design`
- 压测覆盖（类型 2 有独立 metric，不走此入口）

## 步骤

1. LLM 收到 `/qa:review-coverage <feature>`，加载 skill `qa-review-coverage`。
2. LLM 调 MCP tool **`qa.reviewCoverage`**，入参 `{ testCasesPath, prdPath, specTsPaths? }`。
3. MCP 返回 `{ summary, missingItems, duplicates, invalidClasses, coverageClass }`。
4. LLM 把结果翻译成用户可读 markdown：覆盖率表 + 未命中 AC 清单 + 建议补 TC 动作。
5. 若 `coverageClass ≠ ok`，**提示用户下一步走 `/qa:design --overwrite` 补 TC**；本入口不自动改文件。

## 联动

- **Skill**：`qa-review-coverage`（rubric + 启发式）
- **MCP tool**：`qa.reviewCoverage`（含 `coverage-class` classifier）
- **上游**：`/qa:design`（起稿）
- **下游**：`/qa:design --overwrite`（补全）
- **相关 rule**：`qa-preset-types`

## 降级

- 无 MCP 环境：LLM 可按 `coverage-gaps-heuristics.md` 手工扫，准确度下降；程序化 `markdown-schema` gate 无法跑。

真源：`docs/presets/test-case-design.md` §6 / `docs/ai-workflow/failure-class.md` §coverage-class
