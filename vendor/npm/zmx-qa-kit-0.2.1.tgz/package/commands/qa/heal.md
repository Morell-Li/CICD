---
name: qa:heal
description: Auto-heal a failed spec via Healer (dry-run classify → LLM propose patch → applyHealDiff + Verify Loop). Escalates when real-bug / unknown.
argument-hint: "<spec file path>"
---

# /qa:heal

## 入口说明

对一个失败用例走 Healer 闭环：Doctor 程序化分类 → Healer 按 class 渲染 prompt → IDE LLM 生成 patch → MCP 应用 + Verify Loop。

## 何时用

- `/qa:test` 失败后用户想"让 AI 试着修"
- 已知是 `selector-drift` / `assertion-mismatch(spec-side)` / `network-flake` / `data-race` 类失败
- **不适合**：置信度低 / 判为 `real-bug` / `unknown`（应走 `/qa:explain` 拿转交卡）

## 步骤

1. LLM 调 **`qa.heal`（dry=true, runId, idempotencyKey）**：拿回 `{ failureClass, confidence, prompt(已渲染), context }`。
2. 看 failureClass：
   - `real-bug` / `unknown` → **MCP 返回 escalate.md**；LLM 直接展示转交卡，**不 propose patch**。
   - 其他类 → LLM 在自己回合生成 patch。
3. LLM 主动调 **`qa.applyHealDiff`（patch, idempotencyKey, runId）**：写文件 + tsc + `playwright --list` + rerun（按 class 分级阈值，零 LLM）。
4. Verify 过 → 成功；失败 → 继续 propose（最多 3 轮）→ 仍失败则输出 escalate.md。

## 联动

- **Skill**：`qa-heal-spec`（失败分类 + prompt 真源）+ `qa-explain-failure`（escalate 路径）
- **MCP tool**：`qa.heal` + `qa.applyHealDiff`
- **相关 rule**：`qa-failure-class`

## 不可让约束（ADR-021）

- `qa.applyHealDiff` **必须由 IDE LLM 主动调**，MCP 不能反向 push
- Verify Loop **零 LLM**
- Prompt 由 MCP 按 class 渲染，LLM 不自由发挥模板

真源：`docs/ai-workflow/qa-workflow.md` §2 / `docs/ai-workflow/components-architecture.md` §4
