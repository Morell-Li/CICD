---
name: qa:validate
description: Run qa-kit gate validators (annotation schema, markdown schema per preset). Exit code 2 on gate failure, 0 on pass.
argument-hint: "[--gate annotation|markdown]"
---

# /qa:validate

## 入口说明

本地跑 `qa-kit validate`：对 `qa-e2e/tests/**/*.spec.ts` 检查 `test()` / `qaTest()` annotation schema，并按已装 preset 跑 `markdown-schema`（比如 `test-case-design` 的 `test-cases.md` 结构）。与 CI 里同一套规则。

## 何时用

- 写完 spec / test-cases.md 后本地自检（PR 前 gate）
- `/qa:draft-e2e` / `/qa:design` 生成后快速核验
- 新项目冒烟确认 gate 能跑通

## 步骤

1. LLM 调 CLI **`qa-kit validate [--gate <g>]`**。
2. CLI 按 preset 挑启用的 gate，逐文件跑，输出 PASS / WARN / FAIL。
3. 失败时打印每个 issue 的 `code + @line:col + message` + 建议修法。
4. exit code：0 pass/warn、2 error、1 bad flag（与 CI 一致）。

## 联动

- **CLI**：`qa-kit validate`
- **MCP tool**：`qa.validateSpec`（单文件版本，供 `/qa:draft-e2e` 内部 Verify Loop 调）
- **相关 rule**：`qa-conventions`

真源：`docs/ops/version-management.md` §2 / `docs/presets/test-case-design.md` §validators
