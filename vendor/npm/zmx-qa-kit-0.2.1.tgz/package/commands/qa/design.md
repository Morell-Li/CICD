---
name: qa:design
description: Design a structured test-cases.md from a PRD (test-case-design preset), grouped by equivalence class / boundary value / exception path.
argument-hint: "<specs/<feature>/prd.md>"
---

# /qa:design

## 入口说明

从 PRD markdown 直接生成结构化 `test-cases.md`（按等价类 / 边界值 / 异常路径组织），是 `test-case-design` preset 的起稿入口，填补 "PRD → spec.md" 之间的空白。

## 何时用

- 需求评审完毕，要给这个 feature 起第一版测试用例
- 已有 `test-cases.md` 过时，按新 PRD 整段重写
- 下游衔接 `/qa:draft-e2e`（从 test-cases.md 再生成 spec.ts）

**不适合**：
- 压测场景起草 → `/qa:draft-perf`
- spec.ts 起草 → `/qa:draft-e2e`

## 步骤

1. IDE LLM 收到 `/qa:design <prd.md>`，加载 skill `qa-design-test-cases` 的 rubric。
2. LLM 读 PRD AC，组装 `{ prdPath, feature, productVersion, jira }`。
3. LLM 主动调 MCP tool **`qa.designTestCases`**，拿回完整测试用例 md 文本（类型 3 协议：**不走 dry-run + apply 两步**）。
4. LLM 用原生 Write tool 落盘：单模块 → `qa-design/cases/<feature>.md`（扁平）；多模块才拆 `qa-design/cases/<feature>/{module}.md`。**禁止** 写到 `specs/<feature>/test-cases.md`（老嵌套路径，下游 xmind wizard 扫不到）。
5. `markdown-schema` + `annotation-schema` gate 由 `/qa:review-coverage` 或 CI 跑，不在本入口里。

## 联动

- **Skill**：`qa-design-test-cases`（rubric + 三类组织方式）
- **MCP tool**：`qa.designTestCases`
- **下游**：`/qa:review-coverage`（审覆盖率）+ `/qa:draft-e2e`（生成 spec.ts）
- **相关 rule**：`qa-preset-types`（类型 3 preset 行为）

## 降级

- 无 MCP 环境：LLM 按 skill references 手工组装 markdown，交给用户粘贴；失去 `annotation-schema` 即时校验。

真源：`docs/presets/test-case-design.md` §4 工作流
