---
name: qa:test
description: Run Playwright tests (or active preset runner) with optional grep / project filter; surfaces Allure + blob reporter links.
argument-hint: "[path|--grep <pattern>] [--project <name>] [--headed] [--preset <name>]"
---

# /qa:test

## 入口说明

统一的测试入口，按**文件路径 / 显式 flag** 推断 preset，然后挑 runner：
`web-e2e` → Playwright / `k6-perf` → k6 / `test-case-design` → 无 runner 仅跑 validate。

## 何时用

- 跑全量 / 指定 grep 用例（冒烟、单 feature、单 tag）
- 跑一个压测 scenario（指向 `.k6.ts`）
- 作为 `/qa:heal` 前的"先复现一次失败"

## Preset 推断规则（按优先级）

1. **显式 `--preset <name>` flag**：直接用，跳过推断
2. **参数含文件路径**：
   - `.k6.ts` / `.k6.js`（含 `qa-perf/scenarios/**`）→ `presetName: 'k6-perf'`
   - `.spec.ts` / `.spec.tsx`（含 `qa-e2e/tests/**`）→ `presetName: 'web-e2e'`
3. **参数是 grep pattern 或为空**：看 `.zmx-tools-config.json#qaKit.presets`：
   - 只含 `web-e2e` → `web-e2e`
   - 只含 `k6-perf` → `k6-perf`
   - 同时含两个 → 默认 `web-e2e`（最常见）+ 要求用户指定歧义
4. **永远显式把 `presetName` 传给 MCP tool**，不依赖 MCP 服务端推断（当前 `qa.runTest` / `qa.runK6` 签名都是 `presetName: required`）

## 步骤

1. LLM 应用上面的推断规则，得到 `presetName`
2. 按 preset 调对应 MCP tool：
   - `web-e2e` → **`qa.runTest`** 入参 `{ grep?, testPath?, presetName: 'web-e2e', headed?, runId }`
   - `k6-perf` → **`qa.runK6`** 入参 `{ scenarioPath, presetName: 'k6-perf' }`
3. 返回 reporter 摘要（pass / fail 计数 / trace 链接 / summary.json 路径）

## 联动

- **MCP tool**：`qa.runTest`（类型 1 / Playwright）或 `qa.runK6`（类型 2 / k6）
- **CLI 等价**：`qa-kit test run --preset <name> [args]`（无 MCP 环境兜底，同样需要显式 preset）
- **相关 rule**：`qa-runner-web` / `qa-runner-k6`

## 降级

- 无 MCP：LLM 走 Bash 调 `qa-kit test run --preset <推断值>`，stdout 作为结果；失去结构化 reporter 摘要
- 推断不了（路径模糊且配了多 preset）：先问用户"`web-e2e` 还是 `k6-perf`？"，不要盲猜

## 反模式

- ❌ 看到 `.k6.ts` 还传 `presetName: 'web-e2e'` —— spawn 的是 playwright，一定跑不起来
- ❌ 从 MCP 返回的错误里才发现 preset 错 —— 浪费一次往返；靠前面的推断就该对

真源：`docs/runners/web.md` / `docs/runners/k6.md` / `docs/distribution/COMPONENTS.md`
