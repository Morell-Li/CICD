# @zmx/aibundle — AI Skills Guide

> This file is consumed by AI coding tools (Claude / Cursor / Copilot / etc.) to help developers use `@zmx/aibundle` correctly.

## Overview

`@zmx/aibundle` is an AI best-practice compiler. `.aibundle/` in the project is the single source of truth — define components once (Markdown + YAML frontmatter), and aibundle compiles them into each tool's native format via semantic adapters. User-authored configuration is preserved.

**Core capabilities**: 8 component kinds across 2 tiers (content + harness) · 6 tool adapters · capability matrix · 5-layer AI collaboration model · 3-level validation · declarative Meta-Spec · JSON/TOML merge-patch with drift detection.

## Workflow

```
Component definitions (Markdown + YAML frontmatter in .aibundle/)
  -> merge (standalone or optional global inheritance)
  -> buildArtifacts:
      filter -> dedupe -> validate -> capability matrix
        -> Pass 1: content-tier (markdown + sentinel)
        -> Pass 2: harness-tier (JSON/TOML merge-patch + sidecar files)
        -> degradation detection
  -> runSync:
      change detection -> backup
        -> coalesceMergePatches (strip prev managed keys, drift detection, apply chain)
        -> stale cleanup (per file kind)
        -> atomic write
        -> registry v3 tracking (managedMergeKeys + keyHashes)
```

## CLI Quick Reference

### Sync & Diagnostics

```bash
aibundle init                             # Initialize project .aibundle/ (default)
aibundle init --global                    # Initialize global overrides (optional)
aibundle sync                             # Compile to configured tools
aibundle sync --all                       # Sync to all 6 tools
aibundle sync --tool cursor,claude        # Sync to specific tools
aibundle sync --scope team                # Use team scope (Cursor team rules)
aibundle diff                             # Preview changes
aibundle doctor                           # Health check
aibundle discover                         # Scan for package skills
aibundle history                          # Sync history
aibundle rollback                         # Rollback last sync
```

### Validation

```bash
aibundle validate                         # Validate all components
aibundle validate --kind hooks            # Validate hooks only (or settings, agents, ...)
aibundle validate --level info            # Show all (including info hints)
aibundle validate --strict                # CI mode (warn -> error)
aibundle validate --report report.md      # Markdown report
```

### Component Scaffolding

```bash
aibundle create-meta hooks lint-on-edit   # Generate hook component template
aibundle create-meta settings safety      # Generate settings component template
aibundle create-meta skills my-skill      # Generate skill (folder mode)
aibundle create-meta agents reviewer --mode minimal
aibundle create-meta rules ts-strict --mode split
aibundle create-meta mcp my-server        # MCP server template
```

### Documentation Generation

```bash
aibundle docs-matrix                              # Full field matrix
aibundle docs-matrix --kind hooks                 # Hooks only
aibundle docs-matrix --degradation --out fields.md  # With degradation summary
```

### Build Preview

```bash
aibundle build --format json              # Preview rendered artifacts (JSON)
aibundle build --format table             # Table format
```

## AI Collaboration Model (5-Layer Semantic + Harness)

The 8 component kinds map to a higher-level semantic model:

| Semantic Layer | Meaning | aibundle Mapping |
|---|---|---|
| Global Rules | Always-loaded instructions | rules (`alwaysApply: true` or `ruleType: always`) |
| Scoped Rules | File/directory-triggered context | rules (with `globs` patterns) |
| Tool-Native Config | Tool-specific runtime settings | **harness-tier**: `hooks` + `settings` |
| Reference Docs | Background knowledge, docs index | `prompts` + skill `references/` |
| Callable Capabilities | Invocable agents, skills, commands | `agents`, `skills`, `commands`, `workflows` |

Use `inferSemanticCategory(kind, frontmatter)` from the Library API to classify a component programmatically.

## Component Kinds (8 across 2 tiers)

### Content tier (6) — markdown emit

| Kind | Purpose | Native Tool Support |
|---|---|---|
| prompts | System / project prompts | Copilot, Codex (AGENTS.md) |
| rules | Behavior rules and constraints | Cursor, Claude, Copilot, Codex (AGENTS.md) |
| agents | Agent role definitions (incl. Copilot chatmode variant) | Cursor, Claude, Copilot, Codex (AGENTS.md) |
| skills | Skill definitions (folder mode) | Cursor, Claude, Copilot, Gemini, Codex (AGENTS.md) |
| commands | Single-step slash commands | Claude, Cursor, Copilot, Codex (AGENTS.md) |
| workflows | Multi-step orchestration | Claude, Cursor, Copilot, Codex (AGENTS.md) |

### Harness tier (2) — JSON/TOML merge-patch

| Kind | Purpose | Native Tool Support |
|---|---|---|
| **hooks** | Lifecycle hooks (9 events) | Claude (full + HTTP), Cursor (.sh sidecar + settings.json), Gemini (hooks.json), Codex (notify, stop only) |
| **settings** | Runtime config shards (permissions / env / model / sandbox / Codex profile) | Claude (settings.json), Codex (config.toml + profiles), Gemini (settings.json) |

> **Codex now has 3 outputs**: `AGENTS.md` (content-tier bundle) + `~/.codex/config.toml` top-level/profiles (settings) + `config.toml notify` (stop hooks).

## Authoring Components

### Common Frontmatter

```yaml
---
name: my-component           # Required, unique identifier
description: What it does     # Recommended
priority: 10                 # Optional (default 100, lower = higher priority)
tools: [cursor, claude]      # Optional (empty = sync to all tools)
---

Component body content...
```

### Hooks (harness-tier)

```yaml
---
name: lint-on-edit
event: postToolUse           # 9 events: sessionStart/userPromptSubmit/preToolUse/postToolUse/subagentStart/subagentStop/preCompact/stop/custom
matcher: Edit                # Tool-name glob (preToolUse/postToolUse only)
command: prettier --write    # XOR with http-url
http-url: https://...        # Claude only
timeout: 30
allowed-env-vars: [USER]     # Claude HTTP only
profile: review              # Codex only
---

# Multi-line shell body — Cursor writes to .sh sidecar; Claude embeds inline
prettier --write "$@"
```

### Settings (harness-tier)

```yaml
---
name: safety
permissions:
  allow: ['Bash(git:*)']
  deny: ['Bash(rm:*)']
env:
  AIBUNDLE_PROJECT: 'my-app'
model: claude-opus-4-7
sandbox: read-only             # Codex only
additional-directories: [../shared-libs]   # Claude only
auto-mode: true                # Claude only (recommend pairing with deny list)
profile: review                # Codex only — writes [profiles.review]; omit -> top-level
---
```

### Skills Fields

```yaml
---
name: my-skill
description: "Skill description + trigger phrases"   # max 1024 chars
allowed-tools: "Bash(git:*) WebFetch Read"
model: claude-sonnet-4-6
disable-model-invocation: false
user-invocable: true
context: codebase
agent: code-reviewer
argument-hint: "file path to review"
hooks:
  preToolExecution:
    command: lint
metadata:
  author: Your Name
  version: 1.0.0
  category: productivity
  tags: [automation]
---
```

Folder mode: `skills/<name>/SKILL.md` + `scripts/` + `references/` + `assets/`. All linked files copied verbatim.

### Rules Fields

```yaml
---
name: security
description: Security rules
globs: "src/**/*.ts"
rule-type: always              # always | auto | agent-requested | manual
alwaysApply: true
category: global               # global | scoped | reference (semantic hint)
exclude-agent: test-agent      # Copilot only
---
```

`rule-type` takes precedence over `alwaysApply`: `always` -> true, `manual`/`agent-requested` -> false.

### Agents Fields (incl. Copilot chatmode variant)

```yaml
---
name: reviewer
description: 'Code reviewer focused on safety'
target: chatmode               # routes to .github/chatmodes/{name}.chatmode.md (Copilot only)
tools: "Read,Grep,Bash"        # string = Claude/Cursor allowlist; array = AI tool selection
model: gpt-4o
permission-mode: acceptEdits   # default | acceptEdits | dontAsk | bypassPermissions | plan
max-turns: 20
skills: [code-review]
memory: project                # user | project | local
isolation: worktree
---
```

Note: the `tools` field has dual semantics — string = tool allowlist for the agent, array = which AI tools this component targets.

### Commands (slash command, fans out)

```yaml
---
name: deploy
description: 'Trigger production deploy'
---

Run `pnpm deploy:prod` and watch logs.
```

Per-tool emission:
- Claude → `.claude/commands/deploy.md`
- Cursor → `.cursor/commands/deploy.md`
- Copilot → `.github/prompts/deploy.prompt.md`
- Codex → AGENTS.md section
- Gemini → bundle markdown (degraded)

### Prompts Fields

```yaml
---
name: plan
description: Planning prompt
agent: agent                   # Copilot: ask | edit | agent | plan
model: gpt-4o
prompt-tools: [githubRepo]
argument-hint: search query
---
```

### Workflows Fields

```yaml
---
name: test-and-fix
description: Run tests and fix
steps:
  - { name: run-tests, instruction: Run the test suite }
  - { name: fix, instruction: Fix failures }
---
```

### MCP Server Configuration

MCP YAML files live in `.aibundle/mcp/*.yaml`. The loader auto-detects two shapes:

**Flat** (one server per file — what `aibundle create-meta mcp <name>` generates):

```yaml
# .aibundle/mcp/local-db.yaml
name: local-db          # optional; falls back to file basename
command: npx
args: ["-y", "@local/db-mcp"]
env: { API_KEY: "..." }
```

**Mapped** (one or more servers per file, same shape as `mcp.inline` / final `mcp.json`):

```yaml
# .aibundle/mcp/servers.yaml
my-stdio-server:
  command: npx
  args: ["-y", "@mcp/server"]
  env: { API_KEY: "..." }

my-http-server:
  transport: streamable-http
  url: https://api.example.com/mcp
  headers: { Authorization: "Bearer ..." }
```

Detection: top-level containing `name` / `command` / `url` / `transport` / `args` / `env` / `headers` / `tools` / `description` → flat; otherwise every top-level key becomes a server name.

**Output schema** (`.cursor/mcp.json`, `.claude/mcp.json`, `.gemini/settings.json`) follows the native convention: `transport: stdio` is the default and never emitted (inferred from `command`); only non-default transports (`sse`, `streamable-http`) and HTTP fields (`url`, `headers`) are passed through. Empty `args: []` / `env: {}` are also omitted.

MCP has no nested output. Subdirectories under `.aibundle/mcp/` are organization-only — server identity comes from the YAML `name` field or top-level key, and duplicate server names produce a warning.

Validation: stdio requires `command`, HTTP requires `url`.

## Conflict Resolution & Drift Detection (harness-tier)

Each sync writes to merge targets like `.claude/settings.json` and `~/.codex/config.toml`. The flow:

1. Strip the previous sync's managed keys (from `registry.managedMergeKeys`)
2. Apply patches in `(priority asc, name asc)` order
3. Compute new `keyHashes`, store in registry
4. **Drift detection**: if any previously-managed key's current hash differs from the registry snapshot, the user hand-edited a managed key — emit warning, overwrite per default `prefer-core` policy

User-authored keys (those NOT in `managedKeys`) are never touched.

## 3-Level Validation

| Level | Meaning | Examples |
|---|---|---|
| error | Must fix | Missing name; hook with both `command` AND `http-url` |
| warn | Should fix | `auto-mode: true` without `permissions.deny`; `matcher` on a non-tool-use event |
| info | Best practice hint | `sandbox` on a non-Codex tool; no model specified |

CI recommendation: `aibundle validate --strict --fail-on-warn`

## Configuration Hierarchy

```
.aibundle/config.yaml                   # Project source of truth (default: extends: false)

# Optional global inheritance (extends: true):
~/.config/ai-config/bundle.yaml         # Global defaults
  -> profiles/coding.yaml               # Profile inheritance chain
    -> .aibundle/config.yaml            # Project-level overrides
```

## Library API (representative)

Full list grouped by purpose: see `docs/api.md`.

```ts
import {
  // Pipeline runtime
  buildMergedConfig, loadAdapterConfig, buildArtifacts, runSync,
  DEFAULT_ADAPTERS,
  // Meta-Spec
  KIND_SPECS, KIND_TIER, getKindSpec, SKILL_METADATA_FIELDS,
  // Validation
  specValidateComponent, validateMcpServer, validateComponent,
  // Capability matrix
  getKindEmit, hasFeature, getFeatures,
  // Renderers
  resolveRenderer, registerRenderer,
  // Templates & degradation
  generateTemplate, generateMcpTemplate,
  generateFieldMatrixMd, getDegradationSummary,
  // Semantic classification
  inferSemanticCategory,
} from "@zmx/aibundle/lib";

import type { SemanticCategory, ComponentTier, HookSpec, SettingsSpec, HarnessMergePatch } from "@zmx/aibundle/lib";
```

## FAQ

### How to sync to specific tools only
Use `aibundle sync --tool cursor,claude` or set `tools: [cursor, claude]` in component frontmatter.

### Are info-level issues considered errors
No. Info issues are best-practice hints only. `--strict` promotes warn to error; info is unaffected.

### How to add skills to an npm package
Place `SKILLS.md` (flat mode) or `skills/<name>/SKILL.md` (folder mode) at the package root and include it in `package.json` `files`. aibundle's package discovery scans `node_modules/@zmx/*/SKILLS.md` automatically.

### Will aibundle overwrite my hand-edited `.claude/settings.json`?
No, except for keys it explicitly manages (those listed in `registry.managedMergeKeys[file].keys`). Hand-editing a managed key triggers a drift warning and prefer-core overwrite by default.

### What does `target: chatmode` on an agent do?
Copilot adapter routes that agent to `.github/chatmodes/{name}.chatmode.md` instead of `.agent.md`, using a chatmode-shaped renderer (no `name:` in frontmatter, just description + tools + model + body). Other adapters ignore the target and emit as a normal agent.

### How to extend Meta-Spec with new fields
Add a FieldSpec to `src/meta/specs.ts`. Validation, template generation, and documentation update automatically. Complex fields (nested objects, dual-semantics) may need a post-hook in `component-loader.ts`.
