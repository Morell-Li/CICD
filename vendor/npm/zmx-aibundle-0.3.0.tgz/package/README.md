# @zmx/aibundle

AI 最佳实践编译器 — 定义一次,同步到所有 AI 工具。

`.aibundle/` 是唯一真相源。工具目录(`.cursor/`、`.claude/`、`AGENTS.md`、`.github/`、`~/.codex/config.toml` 等)是派生产物,由 aibundle 生成和管理。

## 为什么需要 aibundle

每个 AI 编码工具都有自己的配置面:

| 工具 | 主要配置位置 |
|---|---|
| Cursor | `.cursor/rules/*.mdc`, `.cursor/agents/*.md`, `.cursor/commands/*.md`, `.cursor/hooks/*.sh`, `.cursor/settings.json` |
| Claude Code | `CLAUDE.md`, `.claude/rules/*.md`, `.claude/agents/*.md`, `.claude/commands/*.md`, `.claude/skills/<name>/SKILL.md`, `.claude/settings.json` |
| Codex | `AGENTS.md`, `~/.codex/config.toml`(profiles + notify) |
| Copilot | `.github/copilot-instructions.md`, `.github/instructions/*.md`, `.github/prompts/*.md`, `.github/agents/*.md`, `.github/chatmodes/*.md` |
| Gemini | `.gemini/settings.json`, `.gemini/hooks/hooks.json`, `.gemini/skills/<name>/SKILL.md` |

分别维护这些配置会导致**漂移**、**重复**、**不一致**。Cursor 的规则改了,得记得同步 Claude — 而且格式还不一样。

aibundle 解决这个问题:用 Markdown + YAML frontmatter 写一次组件,通过语义适配编译为各工具的原生格式;用户手配的内容永远不被覆盖。

## 30 秒上手

```bash
pnpm add @zmx/aibundle        # 或: npm install / bun add

aibundle init                  # 初始化 .aibundle/
# 编辑 .aibundle/rules/, .aibundle/skills/, .aibundle/hooks/ 等
aibundle diff                  # 预览变更
aibundle sync                  # 编译/同步到各工具目录
```

## 工作原理

```
.aibundle/                              aibundle sync                  原生输出
├── rules/                                                       .cursor/rules/*.mdc
├── agents/                ─────────────────────────────────→    .claude/agents/*.md
├── skills/                                                      .github/agents/*.agent.md  +  *.chatmode.md
├── commands/                                                    .claude/commands/*.md  /  .github/prompts/*.md
├── prompts/                                                     .github/prompts/*.prompt.md
├── workflows/                                                   CLAUDE.md / AGENTS.md (sentinel block)
├── hooks/        ⚙️                                              .claude/settings.json (merge)
├── settings/     ⚙️                                              ~/.codex/config.toml (merge)
├── mcp/                                                         .cursor/mcp.json
└── config.yaml                                                  .gemini/settings.json (merge)
```

每个工具获得**原生格式**输出。⚙️ 标记的是 **harness 层**(详见下文)。

## 核心概念

### 8 种组件,跨 2 个 Tier

aibundle 把组件分两层。

**组件层 (content-tier) — 6 种**:输出 markdown,负责注入提示词或定义可调用能力。

| Kind | 用途 | 示例 |
|---|---|---|
| `prompts` | 系统/项目 prompt 模板 | "工程师助手"系统提示 |
| `rules` | 编码规范、约定 | "TS 文件用 unknown 不用 any" |
| `agents` | 子代理角色 | 架构师、审查员 |
| `skills` | 可调用能力(folder + scripts) | `/code-review`、`/lint-fix` |
| `commands` | slash 命令(单步) | `/deploy`、`/release` |
| `workflows` | 多步骤编排 | "test-and-fix" 流水线 |

**Harness 层 (harness-tier) — 2 种**:输出 JSON/TOML 键级合并,控制 AI 工具的运行时行为。用户手配键 100% 保留。

| Kind | 用途 | 示例 |
|---|---|---|
| `hooks` | 生命周期钩子(9 种事件) | `Edit` 后自动 prettier;`stop` 时通知 |
| `settings` | 配置碎片(权限/环境/模型/sandbox) | 拒绝 `Bash(rm:*)`;Codex `[profiles.review]` 只读 |

> **Harness** = AI 工具的运行时承载(Claude Code 是 Claude 的 harness;Cursor 是其内置 LLM 的 harness)。Harness 层组件控制运行时行为,而不注入提示词。

### 4 种 Scope

| Scope | 写入位置 | 典型场景 |
|---|---|---|
| `workspace` | 项目根 | 大多数项目 |
| `user` | `~/.claude/`、`~/.codex/` 等 | 个人配置 |
| `team` | 项目根的 team 子目录 | 仓库内团队共享(Cursor team rules) |
| `managed` | 平台 MDM 路径 | 企业 IT 锁定设置 |
| `both` | = `[workspace, user]` | 向后兼容别名 |

`both` 不包含 team / managed(显式请求才生效,避免误污染)。

### 项目优先架构

`extends: false` 是默认值。每个项目完全自描述,不依赖全局配置。

- **可移植** — 克隆仓库即可工作,无需全局安装
- **CI 兼容** — 不依赖用户特定路径或 home 目录
- **团队友好** — 所有人看到相同规则,无"在我机器上能跑"问题

如需跨项目共享个人配置,设置 `extends: true` 并 `aibundle init --global` 创建全局层。

### AI 协作模型

8 种组件向上映射为 6 个语义层(组件层 5 + harness 层 1),帮你决定**应该把什么放在哪**。完整指南见[协作模型](./docs/collaboration-model.md)。

### 能力矩阵速览

各工具 8 种 kind 的原生输出:

| Kind | Cursor | Claude | Copilot | Codex | Gemini | Antigravity |
|---|---|---|---|---|---|---|
| prompts | bundle | bundle | `.prompt.md` | bundle | bundle | bundle |
| rules | `.mdc` | `.md` | `.instructions.md` | bundle | bundle | bundle |
| agents | `.md` | `.md` | `.agent.md` + `.chatmode.md` | bundle | bundle | bundle |
| skills | folder | folder | folder | bundle | folder | bundle |
| commands | `.md` | `.md` | `.prompt.md` | bundle | bundle | bundle |
| workflows | `.md` | `.md` | `.prompt.md` | bundle | bundle | bundle |
| **hooks** | `settings.json` + `.sh` | `settings.json` | bundle | `config.toml notify`(stop 仅) | `hooks.json` | bundle |
| **settings** | bundle | `settings.json` | bundle | `config.toml`(顶层 + profiles) | `settings.json` | bundle |
| MCP | `.cursor/mcp.json` | `.claude/mcp.json` | — | — | `.gemini/settings.json` | — |

> Codex 现在有 3 路输出:`AGENTS.md`(组件层)、`~/.codex/config.toml`(顶层 settings + `[profiles.<name>]`)、`config.toml notify`(stop hook)。详见[能力矩阵](./docs/capability-matrix.md)。

## 使用场景

### 新项目

```bash
cd my-project
aibundle init                    # 创建 .aibundle/,分发基础组件
# 编辑 config.yaml:设置目标工具 + scope
# 在 .aibundle/ 中编写 rules / skills / hooks / settings
aibundle sync                    # 生成各工具原生格式文件
```

可选:工具目录加入 `.gitignore`(派生产物):

```gitignore
.cursor/rules/
.claude/rules/
.claude/commands/
.claude/skills/
.claude/settings.json
.cursor/hooks/
.cursor/settings.json
.gemini/hooks/
.gemini/settings.json
```

### 已有项目迁移

参见[迁移指南](./docs/migration.md)。简版:

1. `aibundle init` — 在已有配置旁创建 `.aibundle/`
2. 把规则迁移到 `.aibundle/rules/`,补充 frontmatter
3. `aibundle diff` — 验证输出与已有配置一致
4. `aibundle sync` — 让 aibundle 接管管理
5. `aibundle doctor` — 健康检查

### 升级 aibundle 后

参见 [CHANGELOG](./CHANGELOG.md) 看版本变更,[升级指南](./docs/upgrading.md) 看迁移步骤。

```bash
pnpm update @zmx/aibundle
aibundle diff
aibundle sync
aibundle validate
```

## 配置

最小 `config.yaml`:

```yaml
extends: false
sync:
  tools: [cursor, claude, codex]
  scope: workspace
```

完整参考:[配置文档](./docs/config.md)

## CLI 命令速查

| 命令 | 说明 |
|---|---|
| `aibundle init` | 初始化 `.aibundle/` |
| `aibundle sync` | 编译并同步到各工具目录 |
| `aibundle build` | 预览渲染输出(支持 `--format json`) |
| `aibundle diff` | 预览变更(不写入文件) |
| `aibundle doctor` | 健康检查 |
| `aibundle validate` | 校验所有组件(`--strict` 用于 CI) |
| `aibundle create-meta <kind> <name>` | 从 spec 脚手架生成新组件 |
| `aibundle docs-matrix` | 输出字段支持矩阵 Markdown |
| `aibundle discover` | 扫描 node_modules 中的包技能 |
| `aibundle history` | 显示同步历史 |
| `aibundle rollback` | 回滚上次同步 |

完整参考:[命令文档](./docs/commands.md)

## 文档导航

| 文档 | 说明 |
|---|---|
| [快速开始](./docs/getting-started.md) | 安装、初始化、首次同步 |
| [组件编写](./docs/components.md) | 8 种组件 / 2 个 tier 的 frontmatter 规范 |
| [工具适配器](./docs/adapters.md) | 各工具路径、emit 配置、merge-patch |
| [能力矩阵](./docs/capability-matrix.md) | 各工具字段原生/降级支持 |
| [协作模型](./docs/collaboration-model.md) | 语义模型,"应该把什么放在哪" |
| [配置参考](./docs/config.md) | config.yaml 完整参考、profile、合并规则 |
| [命令参考](./docs/commands.md) | 所有 CLI 命令及选项 |
| [架构设计](./docs/design.md) | 内部设计、sync 流程、registry v3 |
| [Meta-Spec 架构](./docs/meta-spec.md) | 声明式字段规格、KindSpec |
| [校验引擎](./docs/validation.md) | 三级校验、CI 集成 |
| [迁移指南](./docs/migration.md) | 从已有 .cursor/.claude 配置迁移 |
| [升级指南](./docs/upgrading.md) | 升级步骤(CHANGELOG 看具体变更) |
| [Library API](./docs/api.md) | 编程消费 `@zmx/aibundle/lib` 的完整导出 |
| [包技能发现](./docs/discovery.md) | 自动发现 node_modules 中的技能 |

## Library API(代表性)

完整列表 + 分组:[Library API 文档](./docs/api.md)

```typescript
import {
  // Pipeline 运行时
  buildMergedConfig, loadAdapterConfig, buildArtifacts, runSync,

  // Meta-Spec
  KIND_SPECS, KIND_TIER, getKindSpec,

  // 校验
  specValidateComponent, validateMcpServer,

  // 渲染器注册
  resolveRenderer, registerRenderer,

  // 模板与降级
  generateTemplate, generateDegradationSummaryMd,
} from "@zmx/aibundle/lib";
```

## 开发(仅贡献者)

> 仓库内开发流程。**终端用户不需要跑这些命令**,用 `aibundle diff` / `aibundle build --format json` 即可预览 sync 产物。

```bash
pnpm install
pnpm run build
pnpm run test          # 完整套件,540+ 用例覆盖 KindSpec / 校验 / 渲染器 / 引擎 / sync
pnpm run typecheck
pnpm run ci            # 测试 + 类型检查 + 构建
```

仓库根目录另有内部 smoke 脚本(`libs/aibundle/scripts/smoke.mjs`)用于全流程验证,仅在 monorepo 内使用,不随 npm 包分发。
