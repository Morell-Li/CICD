# Changelog

记录 `@zmx/aibundle` 的版本变更。格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [Unreleased]

### Fixed

- **MCP YAML mapped shape (P0)**:`.aibundle/mcp/*.yaml` 使用 "server-name 作顶层 key" 的 mapped 形状时,loader 错把整个 map 视作一个 server,导致 `mcp.json` 输出丢失 `command`、`args` 被清空。新增 dual-shape 检测:顶层含 `name` / `command` / `url` / `transport` / `args` / `env` / `headers` / `tools` / `description` 任一 → 扁平(1 文件 1 server,`name` 缺省回退为 basename);否则每个顶层 key 视为 server 名展开(1 文件多 server)。
- **Native MCP schema cleanup**:`.cursor/mcp.json` / `.claude/mcp.json` / `.gemini/settings.json` 不再写入硬编码的 `transport: "stdio"`(默认值,从 `command` 存在推断);空 `args: []` / `env: {}` / `headers: {}` 也一并省略。仅非默认传输(`sse`、`streamable-http`)与 HTTP 字段(`url`、`headers`)显式输出。

### Added

- **Subdirectory namespaces for content components**:`.aibundle/{commands,rules,agents,skills,workflows,prompts}/<subdir>/<file>.md` 现在保留嵌套路径到支持的工具(Claude / Cursor → `.claude/commands/qa/write.md`),不支持嵌套的工具(Copilot / Gemini)以 `-` flatten(`qa-write.prompt.md`)。`_` 前缀段静默隐藏,用作共享 partials。MCP 无嵌套输出:子目录只作组织用途,server 身份来自 YAML `name` 或顶层 key。
- **MCP dual-shape docs**:[docs/config.md](./docs/config.md) 新增 "MCP YAML 文件形状" 章节,`SKILLS.md` 扩展 MCP 示例覆盖 flat + mapped 两种形状及 basename fallback。
- **Mcp renderer tests**:新增 `tests/mcp-yaml-shapes.test.ts`(8 用例)覆盖扁平/映射单多 server、basename 回退、transport 省略、空 args/env 省略。

### Changed

- **`McpServerDefinition.command` 改为 optional**(HTTP 传输只需 `url`);新增可选 `url` / `headers` 字段
- **Cursor / Copilot 规则文件名**:移除了硬编码的 `aibundle-` 前缀,直接用组件 `name`
- **`aibundle init` 默认**:写入 `discovery.packages: true`,默认启用 `node_modules` 包技能扫描

---

## [0.3.0] — 2026-04-20 — Harness Tier

第一个引入 **Harness 层**的版本。新增 `hooks` 和 `settings` 两种组件类型,把 AI 工具的运行时行为(权限、生命周期钩子、模型默认值、Codex profiles)纳入 SSOT。

### Added

#### Harness 层(全新概念)

- **新 ComponentTier 类型**:`content` / `harness`,以及 `KIND_TIER` 映射
- **新组件 kind**:
  - `hooks` — 9 种生命周期事件(`sessionStart` / `userPromptSubmit` / `preToolUse` / `postToolUse` / `subagentStart` / `subagentStop` / `preCompact` / `stop` / `custom`)
  - `settings` — `permissions` / `env` / `model` / `sandbox` / `additionalDirectories` / `autoMode` / `profile` 字段
- **新 Adapter emit 模式**:`merge-patch`(JSON/TOML 键级合并),含 `mergeFormat` / `mergePath` / `profileAware` / `variants` 字段
- **新 Scope 值**:`team`(项目级团队共享)+ `managed`(企业 MDM)。`both` 仍 = `[workspace, user]`,**不**自动包含新两者
- **新渲染器**:
  - `renderClaudeHookPatch` / `renderClaudeSettingsPatch`
  - `renderCursorHookPatch`(emits sidecar `.sh` + settings.json patch)
  - `renderGeminiHookPatch` / `renderGeminiSettingsPatch`
  - `renderCodexHookPatch` / `renderCodexSettingsPatch`(profile-aware TOML)
  - `renderCopilotChatmodeMd`(agent variant)

#### 跨工具能力增强

- **Slash 命令统一**:`commands` kind 现在跨 4 工具原生
  - Cursor → `.cursor/commands/{name}.md`
  - Copilot → `.github/prompts/{name}.prompt.md`
  - Codex → AGENTS.md bundle
  - Claude → 保持 `.claude/commands/{name}.md`
- **Copilot Chatmodes**:agents 加 `target: chatmode` → 路由到 `.github/chatmodes/{name}.chatmode.md`,通过新的 `emit.<kind>.variants` 机制
- **Codex 升级**:不再仅 `AGENTS.md`。新增 `~/.codex/config.toml` 输出(顶层 settings + `[profiles.<name>]` + `notify` hook)
- **TOML 支持**:新增 `smol-toml` 依赖,Codex `config.toml` 完整 round-trip(顶层注释保留)

#### Registry v3

- **新字段**:每个 project record 新增 `managedMergeKeys`(per-file dotted-path tracking)+ `keyHashes`(漂移检测基线)+ `registrySchemaVersion`
- **自动迁移**:`loadRegistry` 自动从 v2 升级,幂等、加法式、未知未来版本透传(forward-compat)
- **漂移检测**:每次 sync 比对 live key hash 与 registry 基线,不一致 → warning + prefer-core 覆盖

#### 工程基础设施

- **新 `src/renderers/harness/` 目录**:`merge.ts`(JSON/TOML 合并工具)+ `claude.ts` / `cursor.ts` / `gemini.ts` / `codex.ts`
- **新 Library API 导出**:`buildMergedConfig` / `loadAdapterConfig` / `buildArtifacts` / `runSync` / `DEFAULT_ADAPTERS` / `KIND_TIER` / `ComponentTier` / `AdapterPathKey` / 全部 harness 类型
- **新 smoke 脚本**:`libs/aibundle/scripts/smoke.mjs` — scratch project 全流程验证(支持 `--apply` / `--keep`)
- **新 CHANGELOG.md** + 重写的 [docs/upgrading.md](./docs/upgrading.md)

### Changed

- **ComponentKind 枚举**从 6 → 8:加 `hooks` + `settings`
- **`AdapterPathKey`** 从私有变为导出,新增 `settingsJson` / `settingsToml` / `hooks` / `chatmodes` / `plugin` / `extension` 等键
- **`AdapterConfig.paths`** 新增 `team` / `managed` scope 块
- **`AdapterEmitConfig`** 新增 `mode: "merge-patch"` 选项 + 配套字段
- **`RenderedArtifacts`** 新增 `hookFiles` / `outputStyleFiles` / `statuslineFiles` / `mergePatches`(均可选)
- **`config.yaml` `sync.scope`** 校验放宽接受 `team` / `managed`
- **`engine.buildArtifacts`** 新增第二轮 emit pass 处理 harness kinds + 处理 emit variants
- **`sync-service.runSync`** 新增 `coalesceMergePatches`(优先级排序、漂移检测、剥离 prev keys)+ harness 文件 stale cleanup
- **测试套件**:从 440 → 540+ 用例(新增 harness-merge / harness-specs / harness-claude / harness-cursor-gemini-codex / harness-e2e / phase3 / registry-v3-migration 等套件)

### Fixed

- **Re-sync 重复累积**:`coalesceMergePatches` 现在在应用新 patch 前剥离 registry 里上次的 managed keys。修复前每次 sync 会让 `hooks.<event>` 数组、`permissions.allow/deny` 等翻倍累积。
- **Adapter snapshots**:刷新以匹配新增 feature flags

### Migration

从 0.2.x 升级:

1. `pnpm update @zmx/aibundle && aibundle sync` — registry 自动从 v2 迁移到 v3
2. 不需要修改任何现有 `.aibundle/` 内容,所有现有组件继续工作
3. 想用新功能:`aibundle create-meta hooks <name>` / `create-meta settings <name>`
4. 注意:首次 sync 后,如果你之前手改过 `.claude/settings.json` 等文件(并且这些键正好是 aibundle 即将管理的),会触发 drift warning 并被覆盖。可在 `config.yaml` 配 `conflictPolicy.overrides[]` 转 prefer-local

详见 [docs/upgrading.md](./docs/upgrading.md)。

---

## [0.2.0] 之前

历史版本不在本 CHANGELOG 中追溯。如果你从 0.2.x 升级,等同于"全新升级"流程,因为本版本是引入 harness tier 的分水岭。
